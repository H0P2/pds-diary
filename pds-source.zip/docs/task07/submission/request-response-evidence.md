# 요청·응답 검증 근거

출처: `task06/site/scripts/test-auth.mjs` 실행 및 `task07/qa/auth-route-results.json`. 2026-10-09 15개 검사 통과. 아래는 스크립트의 실제 요청 형태와 단언한 결과를 읽기 쉽게 요약한 것이다. 운영 HTTP 원문 캡처가 아니다. 실제 API 코드를 실행하되 DB는 메모리 SQLite, 인증 공급자 응답은 모의다. A/B는 합성 검사 계정이며 실사용 실적으로 사용하지 않는다. 아래 모든 쿠키·비밀번호·토큰은 마스킹했다.

| 요청 요약 | 응답 및 검사 결과 | 범위 |
| --- | --- | --- |
| `GET /api/pds`, 쿠키 없음 | 401; POST의 자료 삭제도 401 | 모의 DB |
| A의 `GET /api/pds?owner_id=B`, `x-user-id:B`, `x-owner-id:B`, `Cookie:<masked-A>` | 200, 여섯 목록에 각각 A 자료만 1개; B에서도 반대로 동일 | 모의 DB |
| A의 `POST /api/pds`, `{action:"delete",id:"task-qa-owner-b",owner_id:"qa-owner-b",user_id:"qa-owner-b"}` | 403/404 단언 통과; 여섯 자료 테이블 모두 전후 동일 | 모의 DB |
| A/B가 서로의 계획·할 일 수정, 보관·복원·완료·취소·실행·돌아보기·다음계획 참조 | 양방향 총 20건 403/404; 각 시도 후 전체 자료 불변 | 모의 DB |
| A의 `POST /api/pds`, `{action:"plan",owner_id:B,user_id:B,…}` | 200, DB의 신규 계획 owner_id는 A | 모의 DB |
| 본인 계획 수정 및 실행 45초 저장 | 200, 계획 version=2, 실제 시간 0.75분; 같은 실행 키 재전송은 중복 추가 없음 | 모의 DB |
| `POST /api/auth`, `{action:"login",email:A,password:"<masked>",user_id:B,owner_id:B}` | 200, 응답 user.id=A, HttpOnly 세션 쿠키 발급 | 모의 공급자 |
| 위 로그인에서 공급자가 미확인 이메일 반환 | 401 | 모의 공급자 |
| 틀린 비밀번호 / 없는 이메일 로그인 | 둘 다 401, 동일 JSON `{error:"이메일 또는 비밀번호를 확인하세요."}` | 모의 공급자 |
| `POST /api/auth`, `{action:"signup",email:" Signup@Example.test ",password:"<masked>",role:"admin"}` | 200; 감사 기록 이메일 소문자 정규화 및 합성 계정 ID·성공 저장; 비밀번호 원문은 모든 감사 행에 없음 | 모의 공급자; 중복가입 검증 아님 |
| `POST /api/auth`, `{action:"password_change",email:A,password:"<masked>",new_password:"<masked>"}` | 공급자 확인 ID가 다른 계정이면 403 및 기존 세션 유지; 본인이면 200 및 이전 앱 세션 두 개 모두 인증 불가 | 모의 공급자 |
| 같은 `GET /api/pds`, 같은 `Cookie:<masked-A>` → 로그아웃 POST → 같은 GET | 200 → 200 → 401; 로그아웃 뒤 기존 값 거절 | 모의 DB |
| `authenticate()`에 expiresAt-1 / expiresAt 전달 및 DB에 지난 만료 설정 후 GET | 유효 / null / 401 | 모의 DB |
| 다른 Origin으로 본인 자료 삭제 POST | 403, 여섯 테이블 전후 동일 | 모의 DB |
| 피드백의 타인 삭제 / 회원의 관리자 범위 조회·수정 | 404 / 403, 상대 자료 불변 | 모의 DB |
| `GET /api/account`, 본인 쿠키 | 200, 본인 여섯 목록·피드백·화면설정·변경이력만 포함(현재 소스는 실사용 연구표·일자도 포함); 관리자 감사 조회는 회원에 403 | 모의 DB |
| `DELETE /api/account`, `{confirmation:"wrong"}` → `{confirmation:"삭제",user_id:B}` | 400 및 전체 불변 → 200 및 A 자료·이메일·세션 삭제, 삭제 상태 설정 및 재로그인 403, 이전 A 쿠키 401, B 내보내기 전후 동일 | 모의 DB; Supabase 계정 삭제 아님 |
| 화면 자동 개선의 켜기·끄기·초기화 및 반복 의견 | A의 허용된 설정만 변경, B 불변, 동일 적용 중복 이력 없음 | 모의 DB |
| 소셜 로그인 외부 Origin·미지원·비활성 공급자·위조/만료 상태 | 403·400·503 또는 오류 리다이렉트; 앱 세션 발급 없음 | 모의 공급자 |
| PKCE 쿠키와 일치하는 소셜 콜백 | 검증된 공급자 사용자에게 303 및 앱 세션 발급, 최종 URL query 제거 | 모의 공급자 |

## 운영 증거 대기
실제 이메일 도착·확인, 중복 가입, 실제 두 계정의 양방향 접근 거절, 실제 bcrypt salt/hash 차이, 실제 비밀번호 변경 후 이전 쿠키 거절, T06 실제 자료 이관을 아직 관찰하지 않았다. 비밀번호·인증 토큰·세션 쿠키·비밀키를 증거에 넣지 않는다. 동일 비밀번호 실험은 실험 전용 두 계정에서 사용자 직접 입력으로 수행하고 관리자 확인 결과는 알고리즘·salt가 다른지·hash가 다른지만 남긴다. 실제 5일 사용은 사용자가 기록한다.

## 운영 익명 요청 — 실제 확인
2026-10-09T13:10:51Z, 쿠키·인증 헤더 없이 GET https://pds-diary-hope-20261008.mo990025.chatgpt.site/api/pds → HTTP 401, {"error":"로그인이 필요합니다."}. 운영 실패 요청 한 가지이며, 실제 두 계정 성공·거절 쌍을 대신하지 않는다. 응답 쿠키 값은 증거에 포함하지 않았다.
