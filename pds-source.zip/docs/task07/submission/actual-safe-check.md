# 실제 인증 프로젝트의 안전한 확인 — 2026-10-09

상위 작업에서 로그인한 Supabase 관리 화면(H0P2)의 `jeaajqoysjqygpqmwuvx` 프로젝트에 읽기 전용 집계 조회를 실행하고 아래 결과를 관찰했다. `auth.users.encrypted_password`의 비어 있지 않은 비밀번호 계정만 대상으로 개수·서로 다른 해시/소금 개수·bcrypt 형식 여부를 집계했다. 이메일, 비밀번호, 해시 원문, salt 원문, 키·토큰은 출력하거나 이 문서에 저장하지 않는다. 여기에는 관찰 결과만 기록하며 실행 SQL 원문이나 아직 없는 사용자 데이터를 지어 넣지 않는다.

| 관찰한 집계 필드 | 값 |
| --- | --- |
| password_accounts | 0 |
| distinct_hashes | 0 |
| distinct_salts | 0 |
| all_bcrypt_format | false |

비밀번호 계정이 0개이므로 이 프로젝트의 실제 앱 비밀번호 가입은 아직 없다. `all_bcrypt_format=false`를 bcrypt 구현 실패로 해석하지 않는다. 실제 두 계정과 같은 비밀번호의 서로 다른 salt/hash는 검증할 계정이 없어 미완료다. 공식 bcrypt 문서는 설계 근거이며 이 집계는 해시 적용 완료 증거가 아니다.

다음 필요한 단계는 SMTP/발신자 구성, 사용자 직접 비밀번호 입력·실제 가입·메일 확인, 실험용 두 계정의 비밀값 없는 해시/salt 차이 집계와 운영 양방향 소유권 검사다. 계정과 기록을 대신 생성해 실제 사용자 사용으로 제출하지 않는다.

## 2026-10-10 운영 재점검
위0건은2026-10-09의과거관찰값이다. 최신관리화면읽기전용집계: password_accounts2,confirmed_accounts2,distinct_hashes2,distinct_salts2,all_bcrypt_format true. 사용자제공 주/네이버주소 각각인증완료1. 실제같은비밀번호를사용했는지는검증하지않았으므로해당조건완료로표시하지않는다. SMTP 비활성. 비밀값원문미수집.
