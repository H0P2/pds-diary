# 실제 인증·자료 확인 — 2026-10-10

현재 배포22(source `8471e308949d899ddb7ce18c215fc1e7f410c604`) 성공. 공개 GitHub `aa73595c6e851afa610c51e3b092286fa35e5d28` 업로드·T06 조상 확인(ahead11/behind0) 완료. 아래 실제 확인은 각 증거의 수행 시점 기준이다.

| 실제 관찰 | 마스킹된 결과 |
| --- | --- |
| 인증 프로젝트 안전 집계 | 비밀번호계정2·인증완료2·서로 다른 hash2/salt2·모두bcrypt |
| 저장 모양 | 두 계정 `$2a$10$[salt/hash masked]`·길이60·confirmed=true |
| T06 귀속 | 계획1·할 일7·회고1 본인 귀속, 실행0·기존 owner NULL0 |
| 두 계정 소유권 | A 계획2/할 일8/회고1, B 계획1/할 일1. 각각 타인6요청404, URL/헤더 위조 시 본인 목록 동일, 전후 개수/digest 불변 |
| 미로그인 보호 | 보호 API6곳401 |
| 로그인 실패 화면 | 틀린 비밀번호·없는 아이디 동일 안내 |
| 전체 내보내기 | API200·6종 개수/digest 본인 목록 일치. B 실제 파일 plans1/tasks1·루트 credential 필드false |
| 실제 로그아웃 | B 서버 내부 동일 요청·실세션 전200/후401·same_request=true. 외부 쿠키 추출/재전송 아님 |

증거: `task07/qa/bcrypt-masked-storage.png`, `two-account-live-results.json`, `chrome-live-final-results.json`, `live-operational-status.md`. 이메일·ID·본문·비밀번호·hash/salt·키·토큰 원문을 제출 증거에 넣지 않는다.

같은 입력 비밀번호인지는 미확인이다. 서로 다른 hash/salt 집계를 같은 비밀번호 실험의 완료로 표시하지 않는다. 일반 SMTP 신규가입·수신·중복가입, 실제 만료·비밀번호 변경·사용자 확인 후 검증 계정 삭제는 미검증이다. 실제5일 기록·사용자 판단2줄도 작성·검토가 필요하다. 합성29개·타입·빌드 통과는 이 미완료 항목을 대신하지 않는다. 최종 제출하지 않았다.
