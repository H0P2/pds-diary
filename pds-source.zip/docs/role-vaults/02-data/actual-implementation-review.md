# 실제 구현 읽기 검토

확인 파일은 `site/db/schema.ts`, `site/app/api/pds/route.ts`, `site/app/page.tsx`다. 사이트 파일은 수정하지 않았다. 최종 계약은 같은 폴더의 `actual-schema-contract.json`이며, 기존 `schema-proposal.json`보다 이 계약을 우선한다.

## 확인한 설계 변경

실행은 할 일마다 여러 세션을 누적하고 request_key UNIQUE로 재전송 중복을 막는다. 초기 제안의 executions.task_id UNIQUE는 실제 요구에 불필요한 제한이므로 채택하지 않는다. 완료 상태는 tasks.status, 완료 이력은 completion_events에 분리한다. 완료 배치는 현재 todo 상태와 generation을 함께 검사하고 UNIQUE(task_id,generation)를 적용하므로 동일 완료를 연속 요청해도 같은 세대의 완료 이력은 한 건이다. 완료 집계는 현재 tasks.status를 세므로 완료 이력 개수에 따라 증가하지 않는다.

기간은 선택 계획의 활성 할 일 중 due_date가 범위에 포함되는 항목을 대상으로 한다. UI가 '마감일 기준'이라고 설명하고 서버 리뷰도 같은 조건을 사용하여 일치한다. 실제 시간은 대상 할 일의 모든 실행 세션을 합한다. 막힘은 이유가 있는 실행 세션 수가 아니라 할 일 수를 세므로 중복 집계되지 않는다. 삭제는 소프트 삭제이며 복원 시 예전 실행 기록을 다시 포함한다.

계획 수정은 이전 plans 행 전체를 버전별로 보존한다. 최초 생성 시 버전 이력 행을 만들지 않고 첫 수정 때 이전 버전 1이 생긴다. 스냅샷은 할 일 목록을 포함하지 않는다. 따라서 '이전 계획 필드 보존'은 충족하지만 '할 일 수정 이력 보존'을 구현했다고 표현하면 안 된다. 과제 BRIEF에는 후자 요구가 없어 현재 범위와 맞는다.

## 수정 권장

1. **P2, route.ts 25행:** reopen은 현재 done 상태만 검사한다. 오래 지연된 완료취소 요청이 도착하기 전에 사용자가 취소→재완료하면, 옛 요청이 새 완료까지 취소할 수 있다. 요청의 generation으로 `AND generation=?` 조건을 추가한다. UI는 이미 generation을 전송한다.
2. **P2, route.ts 15행:** 계획 수정 전 SELECT의 버전 검사와 batch 사이에 다른 수정이 끼어들면 CAS UPDATE가 0행인데 API는 성공으로 응답한다. batch의 UPDATE 결과 `meta.changes`가 0이면 409를 반환하여 수정 유실을 알린다. 이력 INSERT OR IGNORE 자체는 UNIQUE(plan_id,version) 덕분에 중복되지 않는다.
3. **P3, route.ts 32행:** 기존 request_key와 다른 실행 내용이 들어와도 INSERT OR IGNORE 뒤 성공 응답을 보낸다. 동일 payload의 재전송은 기존 기록을 반환하고, 다른 payload면 409를 보내는 편이 명확하다. 현재 UI는 저장 성공 뒤 새 키를 발급하므로 정상 사용 시 영향은 작다.
4. **P3, route.ts 8행:** 내보내기용 GET은 테이블을 순차 조회한다. 동시에 다른 사용자가 저장하면 한 파일의 테이블별 기준 시점이 다를 수 있다. 원자적 export snapshot이 필요하면 여러 SELECT를 D1 batch로 묶는다.

그 밖에 reviews.metrics는 차이값을 저장하지 않으며 UI에서 actual-estimated로 계산한다. source_review_id는 삽입 시 존재 여부를 검사하지만 DB 외래키나 UNIQUE 제약은 없어 한 회고에서 여러 다음 계획을 만들 수 있다. 이 두 사실을 최종 계약에 그대로 기록했다. 검토는 코드에 대한 정적 검토이며 실제 배포 DB 제약 적용 여부나 경쟁 요청 실행 검증은 별도로 필요하다.
