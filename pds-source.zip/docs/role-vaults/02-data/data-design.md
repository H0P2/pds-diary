# 과제 6 데이터 설계 제안

task06/BRIEF.md의 확인된 카드 1~5 조건을 반영한 최종 제안이다. 계획 작성 → 계획 수정 이력 → 실행 기록 → 계획/실제 비교 → 회고와 다음 계획을 실제 서버 DB로 연결한다. 실제 자료는 빈 상태에서 사용자가 직접 입력하며 AI가 실행 실적을 만들지 않는다.

## 관계와 역할

- `plans`: 특정 한국 날짜의 계획. 같은 날짜에 여러 계획을 허용한다. 날짜 UNIQUE는 두지 않는다.
- `plan_versions`: 계획 저장 당시 제목·목표·전체 할 일을 JSON으로 보존하는 불변 스냅샷. 같은 계획의 버전은 UNIQUE다.
- `tasks`: 현재 편집 가능한 할 일. 이름을 바꾸어도 ID를 유지하여 실행 기록이 끊기지 않는다.
- `executions`: 할 일마다 최대 한 개의 현재 실행 상태·실제 소요 시간·메모. UNIQUE(task_id)가 완료 버튼 재클릭으로 행이 늘어나는 것을 막는다.
- `reviews`: 계획마다 한 회고. 잘된 점, 어려운 점, 다음 행동을 저장한다.

별도 버전별 tasks를 만들면 계획을 수정할 때마다 실행 기록 연결이 깨질 수 있다. 현재 목록은 tasks로 관리하고, 예전 계획은 plan_versions.snapshot_json으로 보관한다. 과거 버전의 task ID와 실제 실행을 연결할 수 있어야 하므로 삭제는 기본적으로 소프트 삭제한다.

## 날짜와 시간

`plan_date`는 Asia/Seoul 기준 달력 날짜이며 `YYYY-MM-DD` 문자열이다. `new Date().toISOString().slice(0,10)`은 UTC 날짜이므로 한국 새벽에 잘못된 날짜를 만든다. 브라우저/서버 모두 Intl.DateTimeFormat에 `timeZone: 'Asia/Seoul'`을 명시하고 연·월·일을 조립한다. 생성·수정·완료 시각은 UTC ISO 문자열이다. 계획/실제 소요 시간은 정수 분이며 음수·소수·NaN을 서버에서 거절한다. 실제 시간 NULL은 미기록이며 0분과 구분한다.

## 계획 수정과 중복 방지

클라이언트는 저장할 때 `expectedVersion`을 보낸다. 서버는 `UPDATE plans ... WHERE id=? AND current_version=? AND deleted_at IS NULL`의 변경 행 수를 확인한다. 0이면 409로 최신 데이터를 다시 불러오게 한다. 계획/할 일 수정, 버전 증가, 스냅샷 추가는 하나의 D1 atomic batch에 포함한다. 단, 변경 행 수만으로 이후 문장을 안전하게 조건부 실행할 수 없는 구조라면 뒤따르는 INSERT/UPDATE에도 동일한 버전 조건을 걸어야 한다. 드라이버 트랜잭션 API가 D1에서 지원되는지 확인 없이 interactive transaction을 가정하지 않는다.

완료 버튼은 `POST toggle` 대신 절대값을 보내는 `PUT execution`으로 구현한다. pending/in_progress/completed/skipped 상태 중 목표 상태를 보낸다. 기존 값과 완전히 같은 요청은 아무 변경 없이 같은 데이터를 반환한다. 변경할 때는 expectedRevision으로 compare-and-swap한다. 완료에 처음 진입할 때만 completed_at을 기록하고, 동일 완료 재요청은 그 시각을 보존한다. 완료 해제 시 completed_at만 NULL로 되돌리고 실제 시간은 사용자가 직접 비우기 전까지 보존한다. 완료 여부와 실제 시간 입력 여부를 서로 강제 결합하지 않는다.

최초 execution INSERT는 `ON CONFLICT(task_id) DO NOTHING`을 사용하고 저장 결과를 다시 읽는다. 실제 소요 시간을 누적 증가시키는 API는 재전송 시 중복 집계가 발생하므로 MVP에서는 사용하지 않는다. 이후 타이머 이벤트를 넣는다면 별도 event_id UNIQUE 원장이 필요하다.

## 현재 집계 SQL

시간 미기록을 보존하고, 실행 기록이 없는 할 일도 분모에 포함한다. task 한 건당 execution 최대 한 건이므로 중복 합산되지 않는다.

```sql
SELECT p.id, p.plan_date,
       COUNT(t.id) AS task_count,
       SUM(CASE WHEN e.status = 'completed' THEN 1 ELSE 0 END) AS completed_count,
       COALESCE(SUM(t.planned_minutes), 0) AS planned_minutes,
       COALESCE(SUM(e.actual_minutes), 0) AS actual_minutes,
       COUNT(e.actual_minutes) AS actual_recorded_count
FROM plans p
LEFT JOIN tasks t ON t.plan_id = p.id AND t.deleted_at IS NULL
LEFT JOIN executions e ON e.task_id = t.id
WHERE p.deleted_at IS NULL AND p.start_date <= ? AND p.end_date >= ?
GROUP BY p.id, p.plan_date;
```

완료율 = task_count가 0이면 0%, 그 외 completed_count / task_count × 100. skipped는 분모에 포함하고 완료에 포함하지 않는다. 개별 실제 시간이 NULL이면 미기록이며, C32에 따라 집계에서는 빈값을 0으로 처리한다. plannedMinutes 대비 actualMinutes 차이를 '총 계획 대비 차이'로 표시할 수 있으나, 미기록이 있으면 비교가 불완전함을 알려야 한다. 기록된 항목끼리 정확히 비교할 때는 아래 집계를 사용한다.

```sql
SELECT SUM(t.planned_minutes) AS recorded_planned_minutes,
       SUM(e.actual_minutes) AS recorded_actual_minutes,
       SUM(e.actual_minutes - t.planned_minutes) AS recorded_delta_minutes
FROM tasks t
JOIN plans p ON p.id = t.plan_id AND p.deleted_at IS NULL
JOIN executions e ON e.task_id = t.id
WHERE t.deleted_at IS NULL AND p.id = ? AND e.actual_minutes IS NOT NULL;
```

이력 버전 비교에서는 현재 tasks.planned_minutes를 사용하면 안 된다. 스냅샷을 파싱하거나 SQLite json_each(snapshot_json, '$.tasks')에서 당시 시간을 읽어 stable task ID로 executions에 연결한다. 삭제한 할 일도 당시 계획에 있으면 그 버전의 비교에 남긴다. 현재 대시보드는 삭제한 할 일을 제외한다. 이 둘의 차이를 화면 문구로 드러낸다.

## 삭제

기본 삭제는 plans.deleted_at 또는 tasks.deleted_at을 설정한다. 계획 삭제 시 자식 기록은 남지만 모든 일반 조회는 부모 deleted_at을 검사한다. 할 일 삭제도 이력 보존을 위해 execution을 지우지 않는다. 물리 삭제를 별도로 제공한다면 plans → plan_versions/tasks/reviews, tasks → executions의 ON DELETE CASCADE를 적용한다. reviews 삭제 시 다음 계획의 source_review_id는 SET NULL로 하여 다음 계획을 삭제하지 않는다. 모든 삭제 API는 이미 삭제된 ID에 재요청해도 성공 상태를 반환하도록 한다.

## 회고에서 다음 계획으로

사용자가 다음 날짜와 넘길 할 일을 선택한다. 새 계획의 source_review_id는 이전 회고 ID를 저장하며 UNIQUE여서 더블 클릭/재시도로 계획 두 개가 만들어지지 않는다. 새 계획과 새 tasks 및 버전 1을 atomic batch로 생성한다. 선택된 할 일의 제목·계획 시간은 복사하고 ID는 새로 발급한다. 실행 상태·실제 시간·완료 시각은 복사하지 않는다. 회고의 next_action은 새 계획의 목표 또는 첫 할 일로 넣되 사용자가 수정 가능하게 한다. 생성 완료 후 원래 계획과 다음 계획을 서로 찾아갈 수 있도록 source_review_id → reviews.plan_id 관계를 조회한다.

## 구현 전 확인할 제한

JSON은 API에서 snapshotShape를 검증한다. SQLite json_valid만으로 필드 타입과 필수 항목은 검증되지 않는다. 문자열 최대 길이·할 일 개수·분 상한은 카드 원문/제품 정책에 맞춰 서버와 폼에 동일하게 설정한다. 과제는 로그인 없는 공개 앱이다. 필수 문구를 첫 화면에 그대로 노출한다: 지금은 로그인이 없어 링크를 아는 사람은 누구나 볼 수 있습니다. 남이 봐도 괜찮은 내용만 넣으세요. 추후 비공개 다중 사용자 앱으로 전환하면 owner_id와 모든 쿼리의 소유권 검증이 필수다. FK 활성 상태와 D1 batch 원자성을 실제 연결 환경에서 확인한다. 마감일, 우선순위, 태그, 시간, 상태를 새로고침 후 재조회하여 ID·값·단위가 유지되는지 확인한다.


## 카드별 추가 필드와 조회 계약

C04~C08: plans에 start_date/end_date(기간), priority, success_criteria, estimated_minutes를 추가한다. 계획 자체 예상 시간과 할 일 예상 시간 합은 서로 다른 값이다. 카드4 C32의 예상은 반드시 대상 할 일의 planned_minutes 합이다. 스냅샷에는 이 계획 필드와 당시 할 일의 마감일·우선순위·태그·예상 시간을 모두 담는다.

C14~C20: tasks에는 due_date, priority, tags_json이 필수다. 기본 정렬은 **마감일 빠른 순 → 높은 우선순위 → 생성시각 빠른 순 → ID 오름차순**으로 UI에도 표시한다. 검색은 제목/태그 대상이며 서버 LIKE 매개변수 바인딩을 사용한다. 상태·우선순위·태그·기한 필터를 WHERE에 일관되게 적용한다. 검색 문자열의 `%`/`_`를 문자 그대로 취급할지 와일드카드로 취급할지 정하고 UI와 일치시킨다.

C23~C27: executions에 started_at, ended_at, actual_minutes, blocked_reason을 저장한다. 시작/종료 시각은 사용자가 입력한 한국 시각을 UTC로 변환한다. 종료는 시작 이후여야 하며 실제 시간은 별도 명시 입력값으로 저장할 수 있다. 버튼 완료가 계획 시간을 실제 시간으로 자동 복사해서는 안 된다. 실제 시간 계산 보조를 제공한다면 사용자가 채택하는 시점에만 기록한다. 계획 원본은 executions 변경으로 갱신하지 않는다.

기간별 집계 기본 포함 기준은 **선택 기간과 날짜 범위가 겹치는 미삭제 계획의 모든 미삭제 할 일**이다. `start_date <= periodEnd AND end_date >= periodStart`를 사용하며 이 기준을 화면에 표시한다. 날짜를 plan_date로 단순 필터링하는 구현을 선택한다면 사용자에게 다른 기준임을 명확히 알리고 계약도 수정한다. 서버 파라미터 바인딩 순서는 periodEnd, periodStart다.

```sql
SELECT COUNT(t.id) AS planned_count,
       COALESCE(SUM(CASE WHEN e.status = 'completed' THEN 1 ELSE 0 END), 0) AS completed_count,
       COALESCE(SUM(CASE WHEN COALESCE(e.status, 'pending') <> 'completed'
                         AND t.due_date < ? THEN 1 ELSE 0 END), 0) AS overdue_count,
       COALESCE(SUM(CASE WHEN LENGTH(TRIM(COALESCE(e.blocked_reason, ''))) > 0
                         THEN 1 ELSE 0 END), 0) AS blocked_count,
       COALESCE(SUM(t.planned_minutes), 0) AS estimated_minutes,
       COALESCE(SUM(e.actual_minutes), 0) AS actual_minutes,
       COALESCE(SUM(e.actual_minutes), 0) - COALESCE(SUM(t.planned_minutes), 0) AS delta_minutes
FROM tasks t
JOIN plans p ON p.id = t.plan_id
LEFT JOIN executions e ON e.task_id = t.id
WHERE p.deleted_at IS NULL AND t.deleted_at IS NULL
  AND p.start_date <= ? AND p.end_date >= ?;
```

첫 파라미터는 서울 오늘, 다음은 periodEnd, periodStart다. C30에 맞춰 skipped도 '미완료'에 포함한다. C31은 공백만 있는 막힌 이유는 제외하고 한 할 일을 최대 한 번 센다. C83은 각 숫자를 클릭하면 동일한 WHERE 기준으로 계획/할 일/실행 근거 목록을 보여 준다. 예상·실제·차이 클릭도 대상 할 일과 시간을 나란히 보여 주어 추적 가능하게 한다.

C33은 리뷰의 next_action 중 최소 한 고칠 점을 새 계획의 goal 또는 첫 할 일에 전달하고 source_review_id로 출처를 보존한다. C36은 `schemaVersion`, `timezone`, `exportedAt`, 5개 테이블 배열을 포함한 JSON 파일 하나로 내보낸다. 일관된 스냅샷을 위해 관련 SELECT를 한 D1 batch로 묶는 구현을 고려한다. 내보내기는 원래 UTC 시각과 서울 날짜를 변환 없이 보존하며 분 단위라는 메타데이터를 포함한다.

C78~C81 검증은 사용자 입력 후 활성 계획 ≥1, 활성 할 일 ≥5, 실행 행 ≥3을 DB 조회로 확인한다. 현재 집계가 모두 0이 아닌지도 확인하되 이 조건을 채우려고 실적을 자동 생성하지 않는다. C57을 위해 출력은 텍스트 이스케이프 기본 렌더링을 유지하고 스크립트 모양 입력을 HTML로 삽입하지 않는다.
