import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { OperationalVerificationPanel } from "@/components/operational-verification-panel";

export default async function VerificationPage() {
  const values = await headers();
  let user: { id: string };
  try {
    user = await requireUser(new Request("https://internal.invalid/verification", { headers: { cookie: values.get("cookie") || "" } }));
  } catch (error) {
    if (error instanceof Response && error.status === 401) redirect("/");
    throw error;
  }
  return <OperationalVerificationPanel userId={user.id}/>;
}
