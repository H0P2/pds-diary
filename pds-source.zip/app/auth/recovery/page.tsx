"use client";
import {useEffect,useState,useRef,type FormEvent} from 'react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {notifySessionChanged} from '@/lib/session-events';
import {SpatialScene} from '@/components/spatial-scene';
type Result={ready?:boolean;error?:string;message?:string;restart?:boolean};
async function api(body?:object):Promise<Result>{
 const r=await fetch('/api/auth/recovery',{method:body?'POST':'GET',cache:'no-store',headers:body?{'Content-Type':'application/json'}:undefined,body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(15000)});
 const data=await r.json() as Result;
 if(!r.ok)return {...data,error:data.error||'잠시 후 다시 시도하세요.'};return data;
}
export default function RecoveryPage(){
 const preparation=useRef<Promise<Result>|null>(null);
 const [ready,setReady]=useState(false),[checking,setChecking]=useState(true),[password,setPassword]=useState(''),[confirm,setConfirm]=useState(''),[error,setError]=useState(''),[message,setMessage]=useState(''),[busy,setBusy]=useState(false);
 useEffect(()=>{
  if(!preparation.current){const url=new URL(window.location.href),code=url.searchParams.get('code'),flowId=url.searchParams.get('sb_flow_id');
   window.history.replaceState(window.history.state,'','/auth/recovery');
   preparation.current=url.searchParams.has('error')?Promise.resolve({error:'링크가 만료되었거나 유효하지 않습니다. 새 링크를 요청해주세요.'}):api(code?{action:'prepare',code,flow_id:flowId||undefined}:undefined);
  }
  let active=true;
  preparation.current.then(data=>{if(active){setReady(data.ready===true);setError(data.error||(data.ready?'':'로그인 화면에서 재설정 링크를 요청한 뒤 같은 브라우저에서 열어주세요.'));setChecking(false);}}).catch(()=>{if(active){setError('링크를 확인하지 못했습니다. 연결을 확인하고 새로고침해주세요.');setChecking(false);}});
  return()=>{active=false;};
 },[]);
 async function submit(e:FormEvent){e.preventDefault();if(busy||!ready)return;if(password!==confirm){setError('두 비밀번호가 일치하지 않습니다.');return;}setBusy(true);setError('');
  try{const data=await api({action:'reset',new_password:password});if(data.error){setError(data.error);if(data.restart){setReady(false);setPassword('');setConfirm('');}return;}notifySessionChanged();setPassword('');setConfirm('');setReady(false);setMessage(data.message||'비밀번호를 변경했습니다. 새 비밀번호로 로그인해주세요.');}
  catch{setError('응답을 확인하지 못했습니다. 새 비밀번호로 로그인을 확인한 뒤 필요한 경우 다시 요청해주세요.');}finally{setBusy(false);}
 }
 return <main className="auth-page auth-recovery-page"><SpatialScene/><section className="auth-card auth-recovery-card" aria-labelledby="recovery-title"><div className="auth-card-heading"><span className="auth-card-kicker">PLAN · DO · SEE</span><h1 id="recovery-title">새 비밀번호 설정</h1><p>내 기록을 위한 안전한 새 비밀번호.</p></div>{checking&&<p role="status">재설정 링크를 확인하고 있어요…</p>}{ready&&!message&&<form onSubmit={submit} className="grid gap-4" aria-busy={busy}><label className="auth-field">새 비밀번호<Input type="password" autoComplete="new-password" minLength={8} maxLength={128} required value={password} onChange={e=>setPassword(e.target.value)}/></label><label className="auth-field">새 비밀번호 확인<Input type="password" autoComplete="new-password" minLength={8} maxLength={128} required value={confirm} onChange={e=>setConfirm(e.target.value)}/></label><small>8~128자. 기존 비밀번호와 다르게 설정해주세요.</small><Button disabled={busy}>{busy?'변경 중…':'비밀번호 재설정'}</Button></form>}{error&&<p role="alert" className="error">{error}</p>}{message&&<p role="status" className="success">{message}</p>}<nav aria-label="계정 화면 이동" className="mt-6"><a href="/" className="auth-switch">로그인 화면으로 돌아가기</a>{!message&&!checking&&!ready&&<a href="/?auth=recovery" className="auth-switch">새 재설정 링크 요청하기</a>}</nav></section></main>;
}
