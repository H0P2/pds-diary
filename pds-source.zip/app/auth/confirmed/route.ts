// Email verification is performed by Supabase. This callback never exchanges
// authorization codes or creates a session; the user signs in with a password.
export async function GET(request:Request) {
  return new Response(null,{status:303,headers:{Location:new URL('/',request.url).href,'Cache-Control':'no-store','Referrer-Policy':'no-referrer'}});
}
