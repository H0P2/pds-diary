import { oauthProvider } from '@/lib/supabase';
import { signedIn } from '@/lib/login-session';
import { cookie, memoryStorage, readFlow } from '@/lib/oauth-flow';
export async function GET(request:Request){const target=new URL('/',request.url),headers=new Headers({'Cache-Control':'no-store','Referrer-Policy':'no-referrer'});headers.append('Set-Cookie',cookie('',0));try{
 const url=new URL(request.url),flow=readFlow(request),code=url.searchParams.get('code');
 if(url.searchParams.has('error'))throw new Error('Consent denied');
 if(!flow||flow.state!==url.searchParams.get('attempt')||!code||code.length>2048)throw new Error('Invalid callback');
 const client=oauthProvider(memoryStorage(flow.verifiers));const result=await client.auth.exchangeCodeForSession(code);
 if(result.error||!result.data.session)throw new Error('Code exchange failed');
 try{const verified=await client.auth.getUser(result.data.session.access_token);if(verified.error||!verified.data.user)throw new Error('User verification failed');
 const response=await signedIn(verified.data.user,true);const sessionCookie=response.headers.get('Set-Cookie');if(!sessionCookie)throw new Error('Session missing');headers.append('Set-Cookie',sessionCookie);
 }finally{await client.auth.signOut({scope:'local'});}
 }catch{target.searchParams.set('social_error','1');}
 headers.set('Location',target.href);return new Response(null,{status:303,headers});}
