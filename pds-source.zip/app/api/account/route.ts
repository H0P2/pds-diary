import { database } from '@/db/raw';
import { requireUser, requireOrigin, ownedSnapshot, revokeAllSessions, revokeCurrentSession, audit } from '@/lib/auth';
const headers={'Cache-Control':'private, no-store'};
function caught(error:unknown){return error instanceof Response?error:Response.json({error:'계정 자료를 처리하지 못했습니다.'},{status:503,headers});}
export async function GET(request:Request){try{
 const user=await requireUser(request),db=database();
 if(new URL(request.url).searchParams.get('audit')==='1'){
  if(user.role!=='admin')return Response.json({error:'관리자만 접속 기록을 볼 수 있습니다.'},{status:403,headers});
  const events=(await db.prepare('SELECT id,account_id,email,event,success,created_at FROM diary_audit ORDER BY created_at DESC LIMIT 100').all()).results;
  return Response.json({events},{headers});
 }
 const snapshot=await ownedSnapshot(db,request);if(snapshot.status!==200)return Response.json({error:'로그인이 필요합니다.'},{status:401,headers});
 const feedback=(await db.prepare('SELECT * FROM feedback WHERE user_id=?').bind(user.id).all()).results;
 const feedbackEvents=(await db.prepare('SELECT e.* FROM feedback_events e JOIN feedback f ON f.id=e.feedback_id WHERE f.user_id=?').bind(user.id).all()).results;
 const experience=(await db.prepare('SELECT preferences,automatic,version,updated_at FROM ui_preferences WHERE user_id=?').bind(user.id).all()).results;
 const securityActivity=(await db.prepare('SELECT event,success,created_at FROM diary_audit WHERE account_id=? ORDER BY created_at').bind(user.id).all()).results;
 const studyProtocols=(await db.prepare('SELECT * FROM study_protocols WHERE user_id=?').bind(user.id).all()).results;
 const studyDays=(await db.prepare('SELECT d.* FROM study_days d JOIN study_protocols p ON p.id=d.protocol_id WHERE p.user_id=? ORDER BY d.day_number').bind(user.id).all()).results;
 const changes=(await db.prepare('SELECT id,feedback_id,before_json,after_json,created_at FROM ui_changes WHERE user_id=?').bind(user.id).all()).results;
 const profile=await db.prepare('SELECT username,display_name,bio FROM diary_profiles WHERE user_id=?').bind(user.id).first();
 const communityPosts=(await db.prepare('SELECT id,title,body,plan_snapshot,created_at FROM community_posts WHERE author_id=? AND deleted_at IS NULL').bind(user.id).all()).results;
 const communityComments=(await db.prepare('SELECT id,post_id,body,created_at FROM community_comments WHERE author_id=? AND deleted_at IS NULL').bind(user.id).all()).results;
 return Response.json({profile,community_posts:communityPosts,community_comments:communityComments,...snapshot.data,account:{email:user.email,role:user.role},security_activity:securityActivity,study_protocols:studyProtocols,study_days:studyDays,feedback,feedback_events:feedbackEvents,experience,experience_changes:changes,exported_at:new Date().toISOString(),timezone:'Asia/Seoul',time_unit:'minutes',time_precision:'seconds',month_days:30},{headers});
 }catch(e){return caught(e);}}
export async function DELETE(request:Request){try{
 requireOrigin(request);const user=await requireUser(request),db=database();
 if(Number(request.headers.get('content-length')||0)>512)return Response.json({error:'입력이 너무 깁니다.'},{status:413,headers});
 const input=await request.json();if(!input||typeof input!=='object'||!('confirmation' in input)||input.confirmation!=='삭제')return Response.json({error:'삭제 확인 문구를 입력하세요.'},{status:400,headers});
 const ownedPlans='SELECT id FROM plans WHERE owner_id=?';
 const ownedTasks=`SELECT id FROM tasks WHERE plan_id IN (${ownedPlans})`;
 await db.batch([
  db.prepare('DELETE FROM community_comments WHERE author_id=? OR post_id IN (SELECT id FROM community_posts WHERE author_id=?)').bind(user.id,user.id),
  db.prepare('DELETE FROM community_posts WHERE author_id=?').bind(user.id),
  db.prepare('DELETE FROM diary_profiles WHERE user_id=?').bind(user.id),
  db.prepare(`DELETE FROM completion_events WHERE task_id IN (${ownedTasks})`).bind(user.id),
  db.prepare(`DELETE FROM executions WHERE task_id IN (${ownedTasks})`).bind(user.id),
  db.prepare(`DELETE FROM tasks WHERE plan_id IN (${ownedPlans})`).bind(user.id),
  db.prepare(`DELETE FROM plan_versions WHERE plan_id IN (${ownedPlans})`).bind(user.id),
  db.prepare(`DELETE FROM reviews WHERE plan_id IN (${ownedPlans})`).bind(user.id),
  db.prepare('DELETE FROM plans WHERE owner_id=?').bind(user.id),
  db.prepare('DELETE FROM ui_changes WHERE user_id=?').bind(user.id),
  db.prepare('DELETE FROM ui_preferences WHERE user_id=?').bind(user.id),
  db.prepare('DELETE FROM feedback_events WHERE feedback_id IN (SELECT id FROM feedback WHERE user_id=?)').bind(user.id),
  db.prepare('DELETE FROM feedback WHERE user_id=?').bind(user.id),
  db.prepare('DELETE FROM study_days WHERE protocol_id IN (SELECT id FROM study_protocols WHERE user_id=?)').bind(user.id),
  db.prepare('DELETE FROM study_protocols WHERE user_id=?').bind(user.id),
  db.prepare('DELETE FROM diary_audit WHERE account_id=? OR email=?').bind(user.id,user.email),
  db.prepare('DELETE FROM diary_sessions WHERE user_id=?').bind(user.id),
  db.prepare("UPDATE diary_accounts SET email=NULL,role='member',deleted_at=?,auth_version=auth_version+1 WHERE id=?").bind(Date.now(),user.id),
 ]);
 await revokeAllSessions(db,user.id);const cookie=await revokeCurrentSession(db,request);
 await audit(db,'account_delete',true,null);
 return Response.json({ok:true,message:'다이어리 계정과 자료를 삭제하고 모든 접속을 종료했습니다. 이 계정으로 다이어리에 다시 로그인할 수 없습니다. Supabase 인증 서비스의 계정은 남아 있으며 삭제는 별도 관리가 필요합니다.'},{headers:{...headers,'Set-Cookie':cookie}});
 }catch(e){return caught(e);}}
