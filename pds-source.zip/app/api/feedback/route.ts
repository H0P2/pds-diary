import { database } from '@/db/raw';
import { requireUser, requireOrigin } from '@/lib/auth';
import { preferenceSuggestions, preferenceSql, preferencesFrom, experienceLabels, type ExperienceKey } from '@/lib/ux-policy';

const categories = ['design','ux','feature','bug'] as const;
const priorities = ['urgent','high','normal','low'] as const;
type Feedback = { id:string;user_id:string;category:string;screen:string;problem:string;suggestion:string;status:string;priority:string;group_key:string;reason:string;created_at:string;updated_at:string };
const headers = { 'Cache-Control':'private, no-store' };
function fail(message:string,status=400):never { throw Response.json({error:message},{status,headers}); }
function caught(error:unknown) { return error instanceof Response ? error : Response.json({error:'의견을 처리할 수 없습니다. 잠시 후 다시 시도해 주세요.'},{status:500,headers}); }
function field(value:unknown,max:number,required=true):string { if(typeof value!=='string'||value.length>max)fail('입력 길이와 내용을 확인해 주세요.');const result=value.trim();if(required&&!result)fail('필수 항목을 작성해 주세요.');return result; }
async function body(request:Request):Promise<Record<string,unknown>> {
 if(!request.headers.get('content-type')?.startsWith('application/json'))fail('JSON 형식이 필요합니다.',415);
 const reader=request.body?.getReader();if(!reader)fail('입력 내용을 확인해 주세요.');let size=0;const chunks:Uint8Array[]=[];
 while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>16384){await reader.cancel();fail('입력 내용이 너무 깁니다.',413);}chunks.push(value);}
 const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
 try{const value=JSON.parse(new TextDecoder().decode(bytes));if(!value||Array.isArray(value)||typeof value!=='object')fail('입력 내용을 확인해 주세요.');return value;}catch(e){if(e instanceof Response)throw e;fail('입력 내용을 확인해 주세요.');}
}
async function classify(category:string,screen:string,problem:string) {
 const content=(screen+' '+problem).toLowerCase();
 const urgent=/저장.{0,8}(실패|안|불가)|로그인.{0,15}(못|안|불가)|데이터.{0,8}(사라|유실)/.test(content);
 const accessible=/모바일|작은 화면|가려|대비|읽기 어려|버튼.{0,8}(찾|안 보)/.test(content);
 const issue=urgent?'진행 차단':accessible?'화면 접근성':problem.toLowerCase().replace(/\s+/g,' ').trim();
 const input=new TextEncoder().encode([category,screen.toLowerCase().replace(/\s+/g,' ').trim(),issue].join('|'));
 const key=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',input))).map(x=>x.toString(16).padStart(2,'0')).join('');
 return {priority:urgent?'urgent':accessible?'high':category==='design'?'low':'normal',key,reason:urgent?'저장·로그인 진행 차단 표현 감지':accessible?'모바일·가독성·버튼 접근 표현 감지':category==='design'?'화면 디자인 의견':'기능·사용 흐름 의견'};
}
function proposal(items:Feedback[]) {
 const content=items.map(item=>item.screen+' '+item.problem).join(' ').toLowerCase();
 let change='반복되는 작업 흐름을 단계별로 정리하고 불필요한 입력과 이동을 줄이는 화면 초안을 준비합니다.';
 let verification='원문 의견의 작업을 처음부터 끝까지 수행하며 단계 수와 막히는 지점을 비교합니다.';
 if(/저장.{0,8}(실패|안|불가)|로그인.{0,15}(못|안|불가)|데이터.{0,8}(사라|유실)/.test(content)) {
  change='저장·로그인 실패를 재현하고 민감 정보가 없는 오류 코드와 처리 결과를 확인한 뒤, 실패 안내와 재시도 동선을 설계합니다.';
  verification='별도 테스트 계정에서 실패와 복구를 재현하고 본인 자료만 저장·조회되는지 확인합니다. 개인 다이어리 원문은 검토에 첨부하지 않습니다.';
 } else if(/모바일|작은 화면|가려/.test(content)) {
  change='작은 화면에서 가려지는 주요 버튼과 입력 영역을 찾고 줄바꿈, 간격, 스크롤 범위를 조정하는 초안을 준비합니다.';
  verification='320px와 390px 폭, 확대 보기에서 버튼 접근과 입력 완료를 확인합니다.';
 } else if(/대비|읽기 어려/.test(content)) {
  change='본문과 안내 문구의 색 대비를 점검하고 글자 크기와 색상 조정안을 준비합니다.';
  verification='본문 대비 4.5:1 기준과 확대 보기에서 읽기 쉬운지 확인합니다.';
 } else if(/버튼.{0,8}(찾|안 보)/.test(content)) {
  change='주요 버튼의 이름과 위치를 명확히 하고 작업 순서에 맞춰 배치하는 초안을 준비합니다.';
  verification='사용자가 화면 안내만 보고 다음 행동을 찾고 키보드로 버튼을 실행하는지 확인합니다.';
 } else if(items[0]?.category==='feature') {
  change='요청한 기능의 목적, 입력·결과, 계정별 자료 범위를 정리하고 기존 흐름에 넣을 위치를 제안합니다.';
  verification='대표 작업과 오류 상황을 검토하고 개인정보·권한·비용 영향을 별도로 확인합니다.';
 } else if(items[0]?.category==='design') {
  change='해당 화면의 문구, 간격과 시각적 우선순위를 비교할 변경 전·후 초안을 준비합니다.';
  verification='작은 화면과 확대 보기에서 정보 순서와 조작 영역을 비교합니다.';
 } else if(items[0]?.category==='bug') {
  change='원문 의견의 화면과 재현 단계를 확인하고 실패 안내 및 복구 흐름의 수정 초안을 준비합니다.';
  verification='별도 테스트 계정에서 문제 재현과 정상 동작을 비교합니다.';
 }
 return {label:'로컬 규칙 기반 개선안 초안',origin:'외부 AI 호출 없이 화면·의견 표현을 고정 규칙에 대입',change,verification,review:'구현·배포 전 사용자 검토가 필요합니다. 초안 생성은 상태를 변경하거나 코드를 실행하지 않습니다.'};
}
export async function GET(request:Request) {try{
 const user=await requireUser(request),admin=new URL(request.url).searchParams.get('scope')==='admin';
 if(admin&&user.role!=='admin')fail('관리자만 개선 보관함을 볼 수 있습니다.',403);
 const db=database();const result=admin?await db.prepare('SELECT id,category,screen,problem,suggestion,status,priority,group_key,reason,created_at,updated_at FROM feedback WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT 201').all<Feedback>():await db.prepare('SELECT id,category,screen,problem,suggestion,status,priority,group_key,reason,created_at,updated_at FROM feedback WHERE user_id=? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 201').bind(user.id).all<Feedback>();
 const items=result.results.slice(0,200);const grouped=new Map<string,{key:string;screen:string;category:string;count:number;feedback_ids:string[];priority:string}>();
 for(const item of items){const group=grouped.get(item.group_key)||{key:item.group_key,screen:item.screen,category:item.category,count:0,feedback_ids:[],priority:item.priority};group.count++;group.feedback_ids.push(item.id);if(priorities.indexOf(item.priority as typeof priorities[number])<priorities.indexOf(group.priority as typeof priorities[number]))group.priority=item.priority;grouped.set(item.group_key,group);}
 const groups=Array.from(grouped.values()).map(g=>({...g,priority:g.count>=3&&['normal','low'].includes(g.priority)?'high':g.priority,basis:g.count>=3?'조회 범위 안에서 3건 이상 반복':'화면·종류·감지 표현 또는 동일 원문 기준',proposal:proposal(items.filter(item=>item.group_key===g.key))})).sort((a,b)=>priorities.indexOf(a.priority as typeof priorities[number])-priorities.indexOf(b.priority as typeof priorities[number])||b.count-a.count);
 return Response.json({items,groups,has_more:result.results.length>200,admin,analysis:'AI 분석 연결 준비 중',method:'로컬 규칙으로 우선순위, 반복 의견과 개선안 초안을 제안합니다. 전체 사용자의 의견을 대표하지 않습니다.'},{headers});
 }catch(e){return caught(e);}}
export async function POST(request:Request) {try{
 requireOrigin(request);const user=await requireUser(request);const input=await body(request);
 const category=field(input.category,20);if(!categories.includes(category as typeof categories[number]))fail('의견 종류를 선택해 주세요.');
 const screen=field(input.screen,100),problem=field(input.problem,2000),suggestion=field(input.suggestion??'',2000,false);
 const db=database();const count=await db.prepare("SELECT COUNT(*) AS count FROM feedback WHERE user_id=? AND created_at>=?").bind(user.id,new Date(Date.now()-86400000).toISOString()).first<{count:number}>();if((count?.count??0)>=20)fail('하루에 최대 20건의 의견을 보낼 수 있습니다.',429);
 const rule=await classify(category,screen,problem),id=crypto.randomUUID(),now=new Date().toISOString();
 const keys=preferenceSuggestions(problem+' '+suggestion),changeId=crypto.randomUUID();
 const statements=[db.prepare('INSERT INTO feedback(id,user_id,category,screen,problem,suggestion,priority,group_key,reason,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)').bind(id,user.id,category,screen,problem,suggestion,rule.priority,rule.key,rule.reason,now,now),db.prepare("INSERT INTO ui_preferences(user_id,preferences,automatic,version,updated_at) VALUES(?,'{}',1,1,?) ON CONFLICT(user_id) DO NOTHING").bind(user.id,now)];
 if(keys.length){
  const after=preferenceSql(keys),changed=keys.map(key=>`COALESCE(json_extract(preferences,'$.${key}'),0)=0`).join(' OR ');
  statements.push(db.prepare(`INSERT INTO ui_changes(id,user_id,feedback_id,before_json,after_json,created_at) SELECT ?,user_id,?,preferences,${after},? FROM ui_preferences WHERE user_id=? AND automatic=1 AND (${changed})`).bind(changeId,id,now,user.id));
  statements.push(db.prepare(`UPDATE ui_preferences SET preferences=${after},version=version+1,updated_at=? WHERE user_id=? AND automatic=1 AND (${changed})`).bind(now,user.id));
 }
 await db.batch(statements);
 const preference=await db.prepare('SELECT preferences FROM ui_preferences WHERE user_id=?').bind(user.id).first<{preferences:string}>();
 const history=await db.prepare('SELECT before_json,after_json FROM ui_changes WHERE id=? AND user_id=?').bind(changeId,user.id).first<{before_json:string;after_json:string}>();
 const before=preferencesFrom(history?.before_json),after=preferencesFrom(history?.after_json);
 const applied=history?(Object.keys(experienceLabels) as ExperienceKey[]).filter(key=>!before[key]&&after[key]).map(key=>experienceLabels[key]):[];
 return Response.json({id,status:'received',experience:preferencesFrom(preference?.preferences),applied},{status:201,headers});
 }catch(e){return caught(e);}}
export async function PATCH(request:Request) {try{
 requireOrigin(request);const user=await requireUser(request);if(user.role!=='admin')fail('관리자만 검토 상태를 변경할 수 있습니다.',403);
 const input=await body(request),id=field(input.id,36),status=field(input.status,20),priority=field(input.priority,20),reason=field(input.reason,1000);
 if(!['reviewing','proposed','deferred'].includes(status)||!priorities.includes(priority as typeof priorities[number]))fail('검토 상태와 우선순위를 확인해 주세요.');
 const db=database();if(!await db.prepare('SELECT id FROM feedback WHERE id=? AND deleted_at IS NULL').bind(id).first())fail('의견을 찾을 수 없습니다.',404);
 const now=new Date().toISOString();await db.batch([db.prepare('UPDATE feedback SET status=?,priority=?,reason=?,updated_at=? WHERE id=? AND deleted_at IS NULL').bind(status,priority,reason,now,id),db.prepare('INSERT INTO feedback_events(id,feedback_id,actor_id,action,reason,created_at) VALUES(?,?,?,?,?,?)').bind(crypto.randomUUID(),id,user.id,`review_updated:${status}:${priority}`,reason,now)]);
 return Response.json({ok:true},{headers});
 }catch(e){return caught(e);}}
export async function DELETE(request:Request) {try{
 requireOrigin(request);const user=await requireUser(request),input=await body(request),id=field(input.id,36),now=new Date().toISOString();
 const result=await database().prepare('UPDATE feedback SET deleted_at=?,updated_at=? WHERE id=? AND user_id=? AND deleted_at IS NULL').bind(now,now,id,user.id).run();if(!result.meta.changes)fail('의견을 찾을 수 없습니다.',404);
 return Response.json({ok:true},{headers});
 }catch(e){return caught(e);}}
