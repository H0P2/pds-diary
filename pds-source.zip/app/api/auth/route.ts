import { database } from '@/db/raw';
import { provider, ownerEmail } from '@/lib/supabase';
import { authenticate, revokeCurrentSession, revokeAllSessions, requireOrigin, requireUser, audit, digestToken } from '@/lib/auth';
import { signedIn } from '@/lib/login-session';
const headers = {'Cache-Control':'private, no-store'};
function fail(message:string,status=400):never { throw Response.json({error:message},{status,headers}); }
async function providerCleanup(client:ReturnType<typeof provider>,scope:'local'|'global'){
  let timer:ReturnType<typeof setTimeout>|undefined;
  try{await Promise.race([client.auth.signOut({scope}),new Promise<never>((_resolve,reject)=>{timer=setTimeout(()=>reject(new Error('Cleanup timeout')),5000);})]);}
  catch{/* App authentication and revocation determine the result; provider cleanup is bounded. */}
  finally{if(timer!==undefined)clearTimeout(timer);}
}
async function body(request:Request) {
  const reader=request.body?.getReader();if(!reader)fail('입력을 확인하세요.');
  const chunks:Uint8Array[]=[];let size=0;
  while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>8192){await reader.cancel();fail('입력이 너무 깁니다.',413);}chunks.push(value);}
  const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
  try { const data=JSON.parse(new TextDecoder().decode(bytes));if(!data||Array.isArray(data)||typeof data!=='object')fail('입력을 확인하세요.');return data; }
  catch { fail('입력을 확인하세요.'); }
}
async function rateLimit(request:Request, action:string, email:string) {
  const db=database(),window=Math.floor(Date.now()/600000)*600000;
  const ip=request.headers.get('cf-connecting-ip')||'local';
  const keys=[await digestToken(`ip:${action}:${ip}`),await digestToken(`email:${action}:${email}`)];
  for(const key of keys){await db.prepare('INSERT INTO auth_rate_limits(key_hash,window_start,attempts) VALUES(?,?,1) ON CONFLICT(key_hash,window_start) DO UPDATE SET attempts=attempts+1').bind(key,window).run();const row=await db.prepare('SELECT attempts FROM auth_rate_limits WHERE key_hash=? AND window_start=?').bind(key,window).first<{attempts:number}>();if((row?.attempts||0)>20)fail('시도가 많습니다. 10분 뒤 다시 시도하세요.',429);}
  await db.prepare('DELETE FROM auth_rate_limits WHERE window_start<?').bind(window-86400000).run();
}
export async function GET(request:Request) {
  try { const session=await authenticate(database(),request);if(!session)return Response.json({user:null},{headers});const user=await requireUser(request);const profile=await database().prepare('SELECT username,display_name FROM diary_profiles WHERE user_id=?').bind(user.id).first<{username:string;display_name:string}>();return Response.json({user:{...user,username:profile?.username||null,display_name:profile?.display_name||''}},{headers}); }
  catch { return Response.json({error:'로그인 상태를 확인하지 못했습니다.'},{status:503,headers}); }
}
export async function POST(request:Request) {
  try {
    requireOrigin(request);const input=await body(request),db=database();
    if(input.action==='logout'){const session=await authenticate(db,request);const cookie=await revokeCurrentSession(db,request);if(session)await audit(db,'logout',true,session.user_id);return Response.json({ok:true},{headers:{...headers,'Set-Cookie':cookie}});}
    if(!['login','signup','verify','password_change'].includes(input.action))fail('요청을 확인하세요.');
    const identifier=typeof input.identifier==='string'?input.identifier.trim().toLowerCase():typeof input.email==='string'?input.email.trim().toLowerCase():'';
    if(!identifier||identifier.length>254)fail(input.action==='login'?'이메일 또는 아이디와 비밀번호를 확인하세요.':'이메일 주소를 확인하세요.',input.action==='login'?401:400);
    await rateLimit(request,input.action,identifier);
    let email=identifier;
    if(input.action==='login'&&!identifier.includes('@')){
      if(!/^[a-z0-9_]{3,20}$/.test(identifier))fail('이메일 또는 아이디와 비밀번호를 확인하세요.',401);
      const account=await db.prepare('SELECT a.email FROM diary_profiles p JOIN diary_accounts a ON a.id=p.user_id WHERE p.username=? AND a.deleted_at IS NULL').bind(identifier).first<{email:string}>();
      if(!account?.email){await audit(db,'login',false);fail('이메일 또는 아이디와 비밀번호를 확인하세요.',401);}
      email=account.email;
    }
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))fail(input.action==='login'?'이메일 또는 아이디와 비밀번호를 확인하세요.':'이메일 주소를 확인하세요.',input.action==='login'?401:400);
    const client=provider();
    if(input.action==='signup') {
      if(typeof input.password!=='string'||input.password.length<8||input.password.length>128)fail('비밀번호는 8~128자로 입력하세요.');
      const result=await client.auth.signUp({email,password:input.password,options:{emailRedirectTo:new URL('/auth/confirmed',request.url).href}});
      await audit(db,'signup',!result.error,result.data.user?.id||null,Date.now(),email);
      if(result.data.session)await providerCleanup(client,'local');
      if(result.error&&!['user_already_exists','email_exists'].includes(result.error.code||''))fail('가입 요청을 완료하지 못했습니다. 인증 메일 발송 연결 상태를 확인하고 다시 시도하세요.',503);
      return Response.json({message:'가입 가능한 이메일이면 인증 안내가 발송됩니다. 메일의 인증 링크를 누른 뒤 이메일과 비밀번호로 로그인하세요. 도착하지 않으면 스팸함을 확인해 주세요.'},{headers});
    }
    if(input.action==='verify') {
      if(typeof input.token!=='string'||!/^\d{6}$/.test(input.token))fail('메일의 인증 코드 6자리를 입력하세요.');
      const result=await client.auth.verifyOtp({email,token:input.token,type:'email'});
      if(result.error||!result.data.user)fail('인증 코드와 유효 시간을 확인하세요.',401);
      const response=await signedIn(result.data.user);await providerCleanup(client,'local');return response;
    }
    if(typeof input.password!=='string'||!input.password||input.password.length>128)fail('이메일 또는 아이디와 비밀번호를 확인하세요.',401);
    const result=await client.auth.signInWithPassword({email,password:input.password});
    if(result.error||!result.data.session){await audit(db,'login',false);fail('이메일 또는 아이디와 비밀번호를 확인하세요.',401);}
    const checked=await client.auth.getUser(result.data.session.access_token);
    if(checked.error||!checked.data.user)fail('이메일 또는 아이디와 비밀번호를 확인하세요.',401);
    if(input.action==='password_change') {
      const current=await requireUser(request);if(current.id!==checked.data.user.id)fail('본인 계정 정보를 확인하세요.',403);
      if(typeof input.new_password!=='string'||input.new_password.length<8||input.new_password.length>128)fail('새 비밀번호는 8~128자로 입력하세요.');
      const changed=await client.auth.updateUser({password:input.new_password});if(changed.error)fail('비밀번호를 변경하지 못했습니다.');
      await revokeAllSessions(db,current.id);await audit(db,'password_change',true,current.id);await providerCleanup(client,'global');
      const cookie=await revokeCurrentSession(db,request);return Response.json({ok:true,message:'비밀번호를 변경했습니다. 다시 로그인하세요.'},{headers:{...headers,'Set-Cookie':cookie}});
    }
    const response=await signedIn(checked.data.user);await providerCleanup(client,'local');return response;
  } catch(error) { return error instanceof Response?error:Response.json({error:'인증 서비스를 이용할 수 없습니다. 잠시 후 다시 시도하세요.'},{status:503,headers}); }
}
