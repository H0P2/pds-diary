import { socialAvailability, oauthProvider, providerOrigin } from '@/lib/supabase';
import { requireOrigin } from '@/lib/auth';
import { cookie, memoryStorage, verifierSlots } from '@/lib/oauth-flow';
const headers={'Cache-Control':'no-store'};
export async function GET(){try{return Response.json(await socialAvailability(),{headers});}catch{return Response.json({google:false,kakao:false,unavailable:true},{status:503,headers});}}
export async function POST(request:Request){try{
 requireOrigin(request);if(Number(request.headers.get('content-length')||0)>128)return Response.json({error:'요청을 확인하세요.'},{status:400,headers});
 const input:any=await request.json();const name=input.provider;if(!['google','kakao'].includes(name))return Response.json({error:'지원하지 않는 로그인입니다.'},{status:400,headers});
 const available=await socialAvailability();if(!available[name as keyof typeof available])return Response.json({error:`${name==='google'?'Google':'카카오'} 로그인 연결 준비 중입니다.`},{status:503,headers});
 const storage=memoryStorage(),state=crypto.randomUUID(),client=oauthProvider(storage);const callback=new URL('/auth/social/callback',request.url);callback.searchParams.set('attempt',state);
 const result=await client.auth.signInWithOAuth({provider:name,options:{redirectTo:callback.href,skipBrowserRedirect:true,...(name==='kakao'?{scopes:'account_email'}:{})}});
 if(result.error||!result.data.url)throw new Error('OAuth start failed');
 const target=new URL(result.data.url);if(target.origin!==providerOrigin()||target.pathname!=='/auth/v1/authorize')throw new Error('Invalid OAuth target');
 const verifiers=verifierSlots(storage.values);if(!Object.keys(verifiers).length)throw new Error('Missing verifier');
 const flow=JSON.stringify({state,provider:name,created:Date.now(),verifiers});if(flow.length>3500)throw new Error('Verifier too large');
 return Response.json({url:target.href},{headers:{...headers,'Set-Cookie':cookie(flow)}});
 }catch(e){return e instanceof Response?e:Response.json({error:'소셜 로그인을 시작하지 못했습니다. 잠시 후 다시 시도하세요.'},{status:503,headers});}}
