import { database } from '@/db/raw';
import { oauthProvider } from '@/lib/supabase';
import { memoryStorage,verifierSlots } from '@/lib/oauth-flow';
import { recoveryCookie,readRecovery } from '@/lib/recovery-flow';
import {readRecoverySession,sealRecoverySession,recoverySessionCookie,recoverySessionLifetime,ensureRecoverySessionConfigured,type RecoverySession} from '@/lib/recovery-session';
import { requireOrigin,digestToken,revokeAllSessions,clearCookie,audit } from '@/lib/auth';
const headers={'Cache-Control':'private, no-store','Referrer-Policy':'no-referrer'};
const invalid='재설정 링크가 만료되었거나 유효하지 않습니다. 같은 브라우저에서 새 링크를 요청하세요.';
function fail(message:string,status=400,flags:Record<string,boolean>={}):never{throw Response.json({error:message,...flags},{status,headers});}
async function verifiedUser(client:ReturnType<typeof oauthProvider>,token:string,expected?:string){
 const checked=await client.auth.getUser(token);const user=checked.data.user;
 if(checked.error||!user?.email_confirmed_at||!user.email||user.is_anonymous||(expected&&user.id!==expected))fail(invalid,401,{restart:true});
 const existing=await database().prepare('SELECT deleted_at FROM diary_accounts WHERE id=?').bind(user.id).first<{deleted_at:number|null}>();
 if(existing?.deleted_at)fail(invalid,401,{restart:true});return user;
}
function deliveryHeaders(flowCookie:string){const out=new Headers(headers);out.append('Set-Cookie',flowCookie);out.append('Set-Cookie',recoverySessionCookie('',0));return out;}
async function state(session:RecoverySession){return database().prepare('SELECT attempts FROM auth_rate_limits WHERE key_hash=? AND window_start=?').bind(await digestToken('recovery-session:'+session.nonce),session.created).first<{attempts:number}>();}
export async function GET(request:Request){try{const session=await readRecoverySession(request);return Response.json({ready:!!session&&(await state(session))?.attempts===0,...(session?{expires_at:session.created+recoverySessionLifetime}:{})},{headers});}catch{return Response.json({error:'재설정 서비스를 이용할 수 없습니다. 잠시 후 다시 시도하세요.'},{status:503,headers});}}
async function readInput(request:Request){const reader=request.body?.getReader();if(!reader)fail('입력을 확인하세요.');let text='',size=0;const decoder=new TextDecoder();while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>8192){await reader.cancel();fail('입력이 너무 깁니다.',413);}text+=decoder.decode(value,{stream:true});}text+=decoder.decode();try{const data=JSON.parse(text);if(!data||typeof data!=='object'||Array.isArray(data))fail('입력을 확인하세요.');return data;}catch{fail('입력을 확인하세요.');}}
export async function POST(request:Request){try{
 requireOrigin(request);const input=await readInput(request),db=database();
 if(input.action==='request'){
 const email=typeof input.email==='string'?input.email.trim().toLowerCase():'';if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254)fail('이메일 주소를 확인하세요.');
 const window=Math.floor(Date.now()/600000)*600000;
 for(const key of [await digestToken('recovery-ip:'+(request.headers.get('cf-connecting-ip')||'local')),await digestToken('recovery-email:'+email)]){
 await db.prepare('INSERT INTO auth_rate_limits(key_hash,window_start,attempts) VALUES(?,?,1) ON CONFLICT(key_hash,window_start) DO UPDATE SET attempts=attempts+1').bind(key,window).run();const row=await db.prepare('SELECT attempts FROM auth_rate_limits WHERE key_hash=? AND window_start=?').bind(key,window).first<{attempts:number}>();if((row?.attempts||0)>5)fail('요청이 많습니다. 10분 뒤 다시 시도하세요.',429);}
 const previous=await readRecoverySession(request);if(previous)await db.prepare('UPDATE auth_rate_limits SET attempts=2 WHERE key_hash=? AND window_start=? AND attempts=0').bind(await digestToken('recovery-session:'+previous.nonce),previous.created).run();
 const storage=memoryStorage(),client=oauthProvider(storage),created=Date.now(),nonce=crypto.randomUUID();
 const result=await client.auth.resetPasswordForEmail(email,{redirectTo:new URL('/auth/recovery',request.url).href});
 // Never reveal whether an email is registered, including provider failure details.
 const verifiers=verifierSlots(storage.values);const flow={nonce,created,verifiers};
 const value=JSON.stringify(flow);if(!readRecovery(new Request(request.url,{headers:{cookie:recoveryCookie(value).split(';')[0]}})))return Response.json({message:'등록된 이메일이면 재설정 안내를 받을 수 있습니다. 링크를 요청한 브라우저에서 30분 안에 열어주세요. 도착하지 않으면 스팸함과 메일 발송 연결 상태를 확인하세요.'},{headers:deliveryHeaders(recoveryCookie('',0))});
 if(!result.error)await db.prepare('INSERT INTO auth_rate_limits(key_hash,window_start,attempts) VALUES(?,?,0)').bind(await digestToken('recovery-flow:'+nonce),created).run();
 await db.prepare('DELETE FROM auth_rate_limits WHERE window_start<?').bind(Date.now()-86400000).run();
 return Response.json({message:'등록된 이메일이면 재설정 안내를 받을 수 있습니다. 링크를 요청한 브라우저에서 30분 안에 열어주세요. 도착하지 않으면 스팸함과 메일 발송 연결 상태를 확인하세요.'},{headers:deliveryHeaders(recoveryCookie(result.error?'':value,result.error?0:1800))});
 }
 if(input.action==='prepare'){
 await ensureRecoverySessionConfigured();
 const already=await readRecoverySession(request);if(already&&(await state(already))?.attempts===0)return Response.json({ready:true,expires_at:already.created+recoverySessionLifetime},{headers});
 const flow=readRecovery(request);const flowId=input.flow_id;
 if(!flow||typeof input.code!=='string'||!input.code||input.code.length>2048)fail(invalid,401,{restart:true});
 if(flowId!==undefined){
  if(typeof flowId!=='string'||! /^[a-zA-Z0-9_-]{8,64}$/.test(flowId)||!Object.entries(flow.verifiers).some(([k,v])=>k.endsWith('-flow-'+flowId+'-code-verifier')&&typeof JSON.parse(v)==='string'&&JSON.parse(v).endsWith('/recovery')))fail(invalid,401,{restart:true});
 }
 const claim=await db.prepare('UPDATE auth_rate_limits SET attempts=1 WHERE key_hash=? AND window_start=? AND attempts=0 RETURNING key_hash').bind(await digestToken('recovery-flow:'+flow.nonce),flow.created).first();if(!claim)fail(invalid,401,{restart:true});
 const client=oauthProvider(memoryStorage(flow.verifiers));const result=await client.auth.exchangeCodeForSession(input.code,flowId?{flowId}:undefined);
 if(result.error||!result.data.session?.access_token||!result.data.session.refresh_token)fail(invalid,401,{restart:true});
 const user=await verifiedUser(client,result.data.session.access_token);
 const session:RecoverySession={nonce:crypto.randomUUID(),created:Date.now(),user_id:user.id,access_token:result.data.session.access_token,refresh_token:result.data.session.refresh_token};
 const sealed=await sealRecoverySession(session);
 await db.prepare('INSERT INTO auth_rate_limits(key_hash,window_start,attempts) VALUES(?,?,0)').bind(await digestToken('recovery-session:'+session.nonce),session.created).run();
 const out=new Headers(headers);out.append('Set-Cookie',recoveryCookie('',0));out.append('Set-Cookie',recoverySessionCookie(sealed));
 return Response.json({ready:true,expires_at:session.created+recoverySessionLifetime},{headers:out});
 }
 if(input.action!=='reset')fail('요청을 확인하세요.');
 if(typeof input.new_password!=='string'||input.new_password.length<8||input.new_password.length>128)fail('새 비밀번호는 8~128자로 입력하세요.',400,{retryable:true});
 const session=await readRecoverySession(request);if(!session)fail(invalid,401,{restart:true});
 const keyHash=await digestToken('recovery-session:'+session.nonce);
 const claim=await db.prepare('UPDATE auth_rate_limits SET attempts=1 WHERE key_hash=? AND window_start=? AND attempts=0 RETURNING key_hash').bind(keyHash,session.created).first();
 if(!claim){if((await state(session))?.attempts===1)fail('이미 변경 요청을 처리하고 있습니다. 잠시 후 확인하세요.',409,{retryable:true});fail(invalid,401,{restart:true});}
 const client=oauthProvider(memoryStorage());let changed=false;
 try{
  const restored=await client.auth.setSession({access_token:session.access_token,refresh_token:session.refresh_token});
  if(restored.error||!restored.data.session)fail(invalid,401,{restart:true});
  session.access_token=restored.data.session.access_token;session.refresh_token=restored.data.session.refresh_token;
  const user=await verifiedUser(client,session.access_token,session.user_id);
  const result=await client.auth.updateUser({password:input.new_password});
  if(result.error){
   if(['same_password','weak_password'].includes(result.error.code||'')){
    const sealed=await sealRecoverySession(session);
    await db.prepare('UPDATE auth_rate_limits SET attempts=0 WHERE key_hash=? AND window_start=? AND attempts=1').bind(keyHash,session.created).run();
    const out=new Headers(headers);out.append('Set-Cookie',recoverySessionCookie(sealed,Math.max(1,Math.floor((recoverySessionLifetime-(Date.now()-session.created))/1000))));
    return Response.json({error:result.error.code==='same_password'?'이전과 다른 비밀번호를 입력하세요.':'더 안전한 비밀번호를 입력하세요. 영문 대소문자, 숫자, 특수문자를 조합해보세요.',retryable:true},{status:400,headers:out});
   }
   fail('변경하지 못했습니다. 새 링크를 요청해 다시 시도하세요.',400,{restart:true});
  }
  changed=true;
  await db.prepare('UPDATE auth_rate_limits SET attempts=2 WHERE key_hash=? AND window_start=? AND attempts=1').bind(keyHash,session.created).run();
  await revokeAllSessions(db,user.id);await audit(db,'password_change',true,user.id);
  const out=new Headers(headers);out.append('Set-Cookie',recoveryCookie('',0));out.append('Set-Cookie',recoverySessionCookie('',0));out.append('Set-Cookie',clearCookie());
  return Response.json({message:'비밀번호를 재설정했습니다. 새 비밀번호로 다시 로그인하세요.'},{headers:out});
 }catch(error){
  await db.prepare('UPDATE auth_rate_limits SET attempts=2 WHERE key_hash=? AND window_start=? AND attempts=1').bind(keyHash,session.created).run();
  throw error;
 }finally{if(changed){try{await client.auth.signOut({scope:'global'});}catch{/* Provider cleanup must not replace the password-change result. */}}}
 }catch(error){return error instanceof Response?error:Response.json({error:'재설정 서비스를 이용할 수 없습니다. 잠시 후 새 링크를 요청하세요.',restart:true},{status:503,headers});}}
