import { database } from '@/db/raw';
import { oauthProvider } from '@/lib/supabase';
import { memoryStorage,verifierSlots } from '@/lib/oauth-flow';
import { recoveryCookie,readRecovery } from '@/lib/recovery-flow';
import { requireOrigin,digestToken,revokeAllSessions,clearCookie,audit } from '@/lib/auth';
const headers={'Cache-Control':'private, no-store','Referrer-Policy':'no-referrer'};
const invalid='재설정 링크가 만료되었거나 유효하지 않습니다. 같은 브라우저에서 새 링크를 요청하세요.';
function fail(message:string,status=400):never{throw Response.json({error:message},{status,headers});}
async function readInput(request:Request){const reader=request.body?.getReader();if(!reader)fail('입력을 확인하세요.');let text='',size=0;const decoder=new TextDecoder();while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>8192){await reader.cancel();fail('입력이 너무 깁니다.',413);}text+=decoder.decode(value,{stream:true});}text+=decoder.decode();try{const data=JSON.parse(text);if(!data||typeof data!=='object'||Array.isArray(data))fail('입력을 확인하세요.');return data;}catch{fail('입력을 확인하세요.');}}
export async function POST(request:Request){try{
 requireOrigin(request);const input=await readInput(request),db=database();
 if(input.action==='request'){
 const email=typeof input.email==='string'?input.email.trim().toLowerCase():'';if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254)fail('이메일 주소를 확인하세요.');
 const window=Math.floor(Date.now()/600000)*600000;
 for(const key of [await digestToken('recovery-ip:'+(request.headers.get('cf-connecting-ip')||'local')),await digestToken('recovery-email:'+email)]){
 await db.prepare('INSERT INTO auth_rate_limits(key_hash,window_start,attempts) VALUES(?,?,1) ON CONFLICT(key_hash,window_start) DO UPDATE SET attempts=attempts+1').bind(key,window).run();const row=await db.prepare('SELECT attempts FROM auth_rate_limits WHERE key_hash=? AND window_start=?').bind(key,window).first<{attempts:number}>();if((row?.attempts||0)>5)fail('요청이 많습니다. 10분 뒤 다시 시도하세요.',429);}
 const storage=memoryStorage(),client=oauthProvider(storage),created=Date.now(),nonce=crypto.randomUUID();
 const result=await client.auth.resetPasswordForEmail(email,{redirectTo:new URL('/auth/recovery',request.url).href});
 // Never reveal whether an email is registered, including provider failure details.
 const verifiers=verifierSlots(storage.values);const flow={nonce,created,verifiers};
 const value=JSON.stringify(flow);if(!readRecovery(new Request(request.url,{headers:{cookie:recoveryCookie(value).split(';')[0]}})))return Response.json({message:'등록된 이메일이면 재설정 안내를 받을 수 있습니다. 링크를 요청한 브라우저에서 30분 안에 열어주세요. 도착하지 않으면 스팸함과 메일 발송 연결 상태를 확인하세요.'},{headers:{...headers,'Set-Cookie':recoveryCookie('',0)}});
 if(!result.error)await db.prepare('INSERT INTO auth_rate_limits(key_hash,window_start,attempts) VALUES(?,?,0)').bind(await digestToken('recovery-flow:'+nonce),created).run();
 await db.prepare('DELETE FROM auth_rate_limits WHERE window_start<?').bind(Date.now()-86400000).run();
 return Response.json({message:'등록된 이메일이면 재설정 안내를 받을 수 있습니다. 링크를 요청한 브라우저에서 30분 안에 열어주세요. 도착하지 않으면 스팸함과 메일 발송 연결 상태를 확인하세요.'},{headers:{...headers,'Set-Cookie':recoveryCookie(result.error?'':value,result.error?0:1800)}});
 }
 if(input.action!=='reset')fail('요청을 확인하세요.');
 if(typeof input.new_password!=='string'||input.new_password.length<8||input.new_password.length>128)fail('새 비밀번호는 8~128자로 입력하세요.');
 const flow=readRecovery(request);if(!flow||typeof input.code!=='string'||!input.code||input.code.length>2048||input.flow_id&& (typeof input.flow_id!=='string'||! /^[a-zA-Z0-9_-]{1,100}$/.test(input.flow_id)))fail(invalid,401);
 const claim=await db.prepare('UPDATE auth_rate_limits SET attempts=1 WHERE key_hash=? AND window_start=? AND attempts=0 RETURNING key_hash').bind(await digestToken('recovery-flow:'+flow.nonce),flow.created).first();if(!claim)fail(invalid,401);
 const client=oauthProvider(memoryStorage(flow.verifiers));const result=await client.auth.exchangeCodeForSession(input.code,input.flow_id?{flowId:input.flow_id}:undefined);
 try{
 if(result.error||!result.data.session)fail(invalid,401);
 const checked=await client.auth.getUser(result.data.session.access_token);if(checked.error||!checked.data.user?.email_confirmed_at||!checked.data.user.email||checked.data.user.is_anonymous)fail(invalid,401);
 const existing=await db.prepare('SELECT deleted_at FROM diary_accounts WHERE id=?').bind(checked.data.user.id).first<{deleted_at:number|null}>();if(existing?.deleted_at)fail(invalid,401);
 const changed=await client.auth.updateUser({password:input.new_password});if(changed.error)fail('변경하지 못했습니다. 새 링크를 요청해 다른 비밀번호로 다시 시도하세요.');
 await revokeAllSessions(db,checked.data.user.id);await audit(db,'password_change',true,checked.data.user.id);
 const out=new Headers(headers);out.append('Set-Cookie',recoveryCookie('',0));out.append('Set-Cookie',clearCookie());
 return Response.json({message:'비밀번호를 재설정했습니다. 새 비밀번호로 다시 로그인하세요.'},{headers:out});
 }finally{if(result.data.session)await client.auth.signOut({scope:'global'});}
 }catch(error){return error instanceof Response?error:Response.json({error:'재설정 서비스를 이용할 수 없습니다. 잠시 후 다시 시도하세요.'},{status:503,headers});}}
