import {database} from '@/db/raw';
import {requireOrigin,requireUser} from '@/lib/auth';
import {preferencesFrom} from '@/lib/ux-policy';
const headers={'Cache-Control':'private, no-store'};
function caught(error:unknown){return error instanceof Response?error:Response.json({error:'화면 설정을 처리할 수 없습니다.'},{status:500,headers});}
async function current(userId:string){const row=await database().prepare('SELECT preferences,automatic,version FROM ui_preferences WHERE user_id=?').bind(userId).first<{preferences:string;automatic:number;version:number}>();return {preferences:preferencesFrom(row?.preferences),automatic:row?.automatic!==0,version:row?.version??1};}
export async function GET(request:Request){try{const user=await requireUser(request);return Response.json(await current(user.id),{headers});}catch(e){return caught(e);}}
export async function POST(request:Request){try{
 requireOrigin(request);const user=await requireUser(request);
 if(!request.headers.get('content-type')?.startsWith('application/json'))return Response.json({error:'JSON 형식이 필요합니다.'},{status:415,headers});
 const reader=request.body?.getReader();if(!reader)return Response.json({error:'설정을 확인해 주세요.'},{status:400,headers});let raw='',size=0;const decoder=new TextDecoder();while(true){const chunk=await reader.read();if(chunk.done)break;size+=chunk.value.byteLength;if(size>1024){await reader.cancel();return Response.json({error:'요청이 너무 큽니다.'},{status:413,headers});}raw+=decoder.decode(chunk.value,{stream:true});}raw+=decoder.decode();
 let input:{action?:unknown;enabled?:unknown};try{input=JSON.parse(raw);}catch{return Response.json({error:'설정을 확인해 주세요.'},{status:400,headers});}
 if(!input||!['reset','automatic'].includes(String(input.action))||(input.action==='automatic'&&typeof input.enabled!=='boolean'))return Response.json({error:'설정을 확인해 주세요.'},{status:400,headers});
 const db=database(),now=new Date().toISOString();const statements=[db.prepare("INSERT INTO ui_preferences(user_id,preferences,automatic,version,updated_at) VALUES(?,'{}',1,1,?) ON CONFLICT(user_id) DO NOTHING").bind(user.id,now)];
 if(input.action==='reset'){
  statements.push(db.prepare("INSERT INTO ui_changes(id,user_id,feedback_id,before_json,after_json,created_at) SELECT ?,user_id,NULL,preferences,'{}',? FROM ui_preferences WHERE user_id=? AND preferences<>'{}'").bind(crypto.randomUUID(),now,user.id));
  statements.push(db.prepare("UPDATE ui_preferences SET preferences='{}',automatic=0,version=version+1,updated_at=? WHERE user_id=?").bind(now,user.id));
 }else statements.push(db.prepare('UPDATE ui_preferences SET automatic=?,version=version+1,updated_at=? WHERE user_id=?').bind(input.enabled?1:0,now,user.id));
 await db.batch(statements);return Response.json(await current(user.id),{headers});
 }catch(e){return caught(e);}}
