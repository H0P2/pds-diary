import {database} from '@/db/raw';
import {requireOrigin,requireUser} from '@/lib/auth';
const headers={'Cache-Control':'private, no-store'};
function fail(error:string,status=400):never{throw Response.json({error},{status,headers});}
async function profile(userId:string){return await database().prepare('SELECT user_id,username,display_name,bio FROM diary_profiles WHERE user_id=?').bind(userId).first()||{user_id:userId,username:null,display_name:'',bio:''};}
export async function GET(request:Request){try{const user=await requireUser(request);return Response.json({profile:await profile(user.id)},{headers});}catch(error){return error instanceof Response?error:Response.json({error:'프로필을 불러오지 못했습니다.'},{status:503,headers});}}
async function body(request:Request){
 const reader=request.body?.getReader();if(!reader)fail('입력을 확인하세요.');let size=0,text='';const decoder=new TextDecoder();
 while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>4096){await reader.cancel();fail('입력이 너무 깁니다.',413);}text+=decoder.decode(value,{stream:true});}
 try{const value=JSON.parse(text+decoder.decode());if(!value||typeof value!=='object'||Array.isArray(value))fail('입력을 확인하세요.');return value;}catch{fail('입력을 확인하세요.');}
}
export async function POST(request:Request){try{
 requireOrigin(request);const user=await requireUser(request),input=await body(request);
 const username=typeof input.username==='string'?input.username.trim().toLowerCase():'';
 const displayName=typeof input.display_name==='string'?input.display_name.trim():'';
 const bio=typeof input.bio==='string'?input.bio.trim():null;
 if(!/^[a-z0-9_]{3,20}$/.test(username))fail('아이디는 영문 소문자, 숫자, 밑줄로 3~20자 입력하세요.');
 if(!displayName||Array.from(displayName).length>30)fail('표시 이름을 1~30자로 입력하세요.');
 if(bio===null||Array.from(bio).length>200)fail('소개는 200자 이내로 입력하세요.');
 const db=database();const duplicate=await db.prepare('SELECT user_id FROM diary_profiles WHERE username=? AND user_id<>?').bind(username,user.id).first();if(duplicate)fail('이미 사용 중인 아이디입니다.',409);
 try{await db.prepare('INSERT INTO diary_profiles(user_id,username,display_name,bio) VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET username=excluded.username,display_name=excluded.display_name,bio=excluded.bio').bind(user.id,username,displayName,bio).run();}
 catch(error){if(/unique/i.test(error instanceof Error?error.message:String(error)))fail('이미 사용 중인 아이디입니다.',409);throw error;}
 return Response.json({profile:await profile(user.id)},{headers});
 }catch(error){return error instanceof Response?error:Response.json({error:'프로필을 저장하지 못했습니다. 잠시 후 다시 시도하세요.'},{status:503,headers});}}
