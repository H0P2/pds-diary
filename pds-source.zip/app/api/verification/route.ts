import { requireOrigin, requireUser, revokeCurrentSession, audit } from "@/lib/auth";
import { database } from "@/db/raw";
import { GET as readPds } from "@/app/api/pds/route";

const privateHeaders = { "Cache-Control": "private, no-store", "Referrer-Policy": "no-referrer" };

/** Uses the current real session only in server memory. Never returns request headers. */
export async function POST(request: Request) {
  let clearedCookie: string | undefined;
  try {
    requireOrigin(request);
    const user = await requireUser(request);
    if (!request.headers.get("content-type")?.startsWith("application/json")) return Response.json({ error: "JSON 형식이 필요합니다." }, { status: 415, headers: privateHeaders });
    const reader = request.body?.getReader();
    if (!reader) return Response.json({ error: "입력을 확인하세요." }, { status: 400, headers: privateHeaders });
    let size = 0, text = "";
    const decoder = new TextDecoder();
    while (true) {
      const chunk = await reader.read(); if (chunk.done) break;
      size += chunk.value.byteLength;
      if (size > 128) { await reader.cancel(); return Response.json({ error: "입력이 너무 깁니다." }, { status: 413, headers: privateHeaders }); }
      text += decoder.decode(chunk.value, { stream: true });
    }
    let input: unknown;
    try { input = JSON.parse(text + decoder.decode()); }
    catch { return Response.json({ error: "입력을 확인하세요." }, { status: 400, headers: privateHeaders }); }
    if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).length !== 1 || !("action" in input) || input.action !== "logout_check") return Response.json({ error: "검증 작업을 확인하세요." }, { status: 400, headers: privateHeaders });
    const url = new URL("/api/pds", request.url).href;
    const sameRequest = new Request(url, { method: "GET", headers: { cookie: request.headers.get("cookie") || "" } });
    const before = await readPds(sameRequest);
    await before.body?.cancel();
    if (before.status !== 200) return Response.json({ url, method: "GET", before_status: before.status, after_status: null, same_request: true, scope: "server-internal same-request session check", checked_at: new Date().toISOString() }, { headers: privateHeaders });
    clearedCookie = await revokeCurrentSession(database(), request);
    await audit(database(), "logout", true, user.id);
    const after = await readPds(sameRequest);
    await after.body?.cancel();
    return Response.json({ url, method: "GET", before_status: before.status, after_status: after.status, same_request: true, scope: "server-internal same-request session check", checked_at: new Date().toISOString() }, { headers: { ...privateHeaders, "Set-Cookie": clearedCookie } });
  } catch (error) {
    if (error instanceof Response) return error;
    return Response.json({ error: "로그아웃 검증을 완료하지 못했습니다." }, { status: 503, headers: { ...privateHeaders, ...(clearedCookie ? { "Set-Cookie": clearedCookie } : {}) } });
  }
}
