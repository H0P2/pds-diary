import { database } from '@/db/raw';
import { requireUser } from '@/lib/auth';
import { activityScanLimit, studyActivity } from '@/lib/study-activity';
import { type StudyProtocol, type StudyDay } from '@/lib/study';

const headers = { 'Cache-Control': 'private, no-store' };
export async function GET(request: Request) {
 try {
  const user = await requireUser(request), db = database(), now = Date.now();
  // Do not compare timestamp text: valid offsets and fractional precision have different lexical ordering.
  // Ownership is enforced even for administrators; only this account's linked tasks are read.
  const entries = (await db.prepare(`SELECT e.started_at,e.ended_at FROM executions e
   JOIN tasks t ON t.id=e.task_id JOIN plans p ON p.id=t.plan_id
   WHERE p.owner_id=? ORDER BY e.created_at DESC,e.id DESC LIMIT ?`).bind(user.id, activityScanLimit).all<{started_at:string;ended_at:string}>()).results;
  const protocol = await db.prepare('SELECT * FROM study_protocols WHERE user_id=?').bind(user.id).first<StudyProtocol>();
  const days = protocol ? (await db.prepare(`SELECT d.* FROM study_days d JOIN study_protocols p ON p.id=d.protocol_id
   WHERE p.user_id=? AND d.protocol_id=? ORDER BY d.day_number`).bind(user.id, protocol.id).all<StudyDay>()).results : [];
  return Response.json(studyActivity(entries, now, protocol, days), { headers });
 } catch (error) {
  if (error instanceof Response) { error.headers.set('Cache-Control', headers['Cache-Control']); return error; }
  return Response.json({error:'실제 실행 기록 초안을 불러올 수 없습니다. 잠시 후 다시 시도해 주세요.'}, {status:500, headers});
 }
}
