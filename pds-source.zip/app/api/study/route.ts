import { database } from '@/db/raw';
import { requireUser, requireOrigin } from '@/lib/auth';
import { studyQuestion, studyRules, seoulDate, sessionMinutes, studySummary, type StudyProtocol, type StudyDay } from '@/lib/study';
const headers={'Cache-Control':'private, no-store'};
function fail(error:string,status=400):never{throw Response.json({error},{status,headers});}
function caught(error:unknown){if(error instanceof Error&&/UNIQUE constraint failed: study_(protocols\.user_id|days\.protocol_id)/.test(error.message))return Response.json({error:'같은 계정·날짜 기록이 이미 저장되었습니다. 새로고침해 주세요.'},{status:409,headers});return error instanceof Response?error:Response.json({error:'실사용 기록을 처리할 수 없습니다. 잠시 후 다시 시도해 주세요.'},{status:500,headers});}
function field(value:unknown,max=1000){if(typeof value!=='string'||!value.trim()||value.length>max)fail('필수 항목과 입력 길이를 확인해 주세요.');return value.trim();}
async function snapshot(userId:string){const db=database();const protocol=await db.prepare('SELECT * FROM study_protocols WHERE user_id=?').bind(userId).first<StudyProtocol>();const days=protocol?(await db.prepare('SELECT * FROM study_days WHERE protocol_id=? ORDER BY day_number').bind(protocol.id).all<StudyDay>()).results:[];return {protocol,days,summary:studySummary(days),today:seoulDate(Date.now()),question:studyQuestion,rules:studyRules};}
export async function GET(request:Request){try{const user=await requireUser(request);return Response.json(await snapshot(user.id),{headers});}catch(error){return caught(error);}}
export async function POST(request:Request){try{
 requireOrigin(request);const user=await requireUser(request);
 if(!request.headers.get('content-type')?.startsWith('application/json'))fail('JSON 형식이 필요합니다.',415);
 const reader=request.body?.getReader();if(!reader)fail('입력 내용을 확인해 주세요.');const chunks:Uint8Array[]=[];let size=0;
 while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>8192){await reader.cancel();fail('입력 내용이 너무 깁니다.',413);}chunks.push(value);}
 const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}const raw=new TextDecoder().decode(bytes);
 let input:Record<string,unknown>;try{input=JSON.parse(raw);}catch{fail('입력 내용을 확인해 주세요.');}
 if(!input||typeof input!=='object'||Array.isArray(input))fail('입력 내용을 확인해 주세요.');
 // Reject all client clocks, owner selectors and unsupported fields, including backdating.
 const allowed=input.action==='start'?['action','baseline_rule','sessions','note']:input.action==='change'?['action','changed_rule','reason']:input.action==='record'?['action','sessions','note']:input.action==='verify'?['action','before_total','before_mean','after_total','after_mean']:[];
 if(!allowed.length||Object.keys(input).some(key=>!allowed.includes(key)))fail('허용되지 않는 입력 항목입니다. 날짜와 계정은 서버에서 정합니다.');
 const current=await snapshot(user.id),db=database(),now=Date.now(),instant=new Date(now).toISOString(),today=seoulDate(now),protocol=current.protocol;
 if(input.action==='change'){
  if(!protocol||current.days.length!==2||protocol.changed_at)fail('2일차 기록 뒤, 3일차 기록 전에 규칙을 한 번만 바꿀 수 있습니다.',409);
  const changed=field(input.changed_rule),reason=field(input.reason);if(changed===protocol.baseline_rule)fail('기존과 다른 작업 시작 규칙 한 가지를 입력해 주세요.');
  const result=await db.prepare(`UPDATE study_protocols SET changed_rule=?,change_reason=?,change_refs=?,changed_at=? WHERE id=? AND user_id=? AND changed_at IS NULL AND (SELECT COUNT(*) FROM study_days WHERE protocol_id=study_protocols.id)=2`).bind(changed,reason,JSON.stringify(current.days.map(day=>({id:day.id,date:day.seoul_date,total_minutes:day.total_minutes}))),instant,protocol.id,user.id).run();
  if(!result.meta.changes)fail('기록 상태가 바뀌었습니다. 새로고침해 주세요.',409);
 }else if(input.action==='verify'){
  if(!protocol||!current.summary.complete)fail('실제 5일 기록을 완료한 뒤 손계산을 대조할 수 있습니다.',409);
  const expected={before_total:current.summary.before.total,before_mean:current.summary.before.mean,after_total:current.summary.after.total,after_mean:current.summary.after.mean};
  if(Object.entries(expected).some(([key,value])=>typeof input[key]!=='number'||input[key]!==value))fail('손계산 값이 기록 합계·평균과 다릅니다. 소수 둘째 자리 반올림 규칙을 확인해 주세요.');
  await db.prepare('UPDATE study_protocols SET manual_check_json=?,manual_checked_at=? WHERE id=? AND user_id=?').bind(JSON.stringify(expected),instant,protocol.id,user.id).run();
 }else{
  let sessions:number[];try{sessions=sessionMinutes(input.sessions);}catch(error){fail(error instanceof Error?error.message:'작업 구간을 확인해 주세요.');}
  const note=input.note===undefined||input.note===''?'':field(input.note),total=sessions.reduce((sum,item)=>sum+Math.round(item*60),0)/60,dayId=crypto.randomUUID();
  if(input.action==='start'){
   if(protocol)fail('이미 시작한 실사용 기록이 있습니다.',409);
   const id=crypto.randomUUID(),baseline=field(input.baseline_rule);
   await db.batch([db.prepare('INSERT INTO study_protocols(id,user_id,question,rules_json,baseline_rule,created_at) VALUES(?,?,?,?,?,?)').bind(id,user.id,studyQuestion,JSON.stringify(studyRules),baseline,instant),db.prepare('INSERT INTO study_days(id,protocol_id,day_number,seoul_date,sessions_json,total_minutes,note,created_at) VALUES(?,?,1,?,?,?,?,?)').bind(dayId,id,today,JSON.stringify(sessions),total,note,instant)]);
  }else{
   if(!protocol||current.days.length>=5)fail('시작한 기록이 없거나 실제 5일 기록이 완료되었습니다.',409);
   if(current.days.at(-1)!.seoul_date>=today)fail('다음 실제 서울 날짜에 기록해 주세요. 같은 날짜 중복 기록은 허용하지 않습니다.',409);
   if(current.days.length>=2&&(!protocol.changed_at||protocol.changed_at>=instant))fail('3일차 전에 작업 시작 규칙 한 가지를 바꾸고 이유를 기록해 주세요.',409);
   const number=current.days.length+1;
   const result=await db.prepare(`INSERT INTO study_days(id,protocol_id,day_number,seoul_date,sessions_json,total_minutes,note,created_at) SELECT ?,id,?,?,?,?,?,? FROM study_protocols WHERE id=? AND user_id=? AND (SELECT COUNT(*) FROM study_days WHERE protocol_id=study_protocols.id)=? AND NOT EXISTS(SELECT 1 FROM study_days WHERE protocol_id=study_protocols.id AND seoul_date>=?) AND (?<=2 OR changed_at<?)`).bind(dayId,number,today,JSON.stringify(sessions),total,note,instant,protocol.id,user.id,number-1,today,number,instant).run();
   if(!result.meta.changes)fail('기록 상태가 바뀌었습니다. 새로고침해 주세요.',409);
  }
 }
 return Response.json(await snapshot(user.id),{status:201,headers});
}catch(error){return caught(error);}}
