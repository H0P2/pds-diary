import { database } from "@/db/raw";
import { requireUser, requireOrigin, ownedSnapshot } from "@/lib/auth";
const missing=()=>Response.json({error:"자료를 찾지 못했습니다."},{status:404});
const now=()=>new Date().toISOString();
const id=()=>crypto.randomUUID();
const date=(v:any)=>{if(typeof v!=="string"||!/^\d{4}-\d{2}-\d{2}$/.test(v)||new Date(v+"T00:00:00Z").toISOString().slice(0,10)!==v)throw Error("날짜를 확인하세요.");return v;};
const str=(v:any,max=2000)=>{if(typeof v!=="string"||!v.trim()||v.length>max)throw Error("입력한 글자 수와 필수 항목을 확인하세요.");return v.trim();};
const min=(v:any)=>{const n=Number(v);if(!Number.isInteger(n)||n<0||n>100000)throw Error("완료 기록 번호를 확인하세요.");return n;};
const durationMinutes=(v:any)=>{const n=Number(v),seconds=Math.round(n*60);if(!Number.isFinite(n)||n<0||n>5256000||Math.abs(n*60-seconds)>0.00001)throw Error("시간은 0 이상, 최대 10년 범위에서 초 단위로 입력하세요.");return seconds/60;};
const priority=(v:any)=>{const n=Number(v);if(![1,2,3].includes(n))throw Error("우선순위를 선택하세요.");return n;};
// Fixed queries keep request input out of table names and apply ownership through the plan.
const ownedRecordQueries={
 plans:"SELECT p.* FROM plans p WHERE p.id=? AND p.owner_id=?",
 tasks:"SELECT t.* FROM tasks t JOIN plans p ON p.id=t.plan_id WHERE t.id=? AND p.owner_id=?",
 executions:"SELECT e.* FROM executions e JOIN tasks t ON t.id=e.task_id JOIN plans p ON p.id=t.plan_id WHERE e.id=? AND p.owner_id=?",
 reviews:"SELECT r.* FROM reviews r JOIN plans p ON p.id=r.plan_id WHERE r.id=? AND p.owner_id=?",
 plan_versions:"SELECT v.* FROM plan_versions v JOIN plans p ON p.id=v.plan_id WHERE v.id=? AND p.owner_id=?",
 completion_events:"SELECT e.* FROM completion_events e JOIN tasks t ON t.id=e.task_id JOIN plans p ON p.id=t.plan_id WHERE e.id=? AND p.owner_id=?",
};
export async function GET(request:Request){try{
 const params=new URL(request.url).searchParams;
 if(params.has("entity")||params.has("id")){
  const user=await requireUser(request);
  const entity=params.get("entity"),recordId=params.get("id");
  if(params.getAll("entity").length!==1||params.getAll("id").length!==1||!entity||!Object.hasOwn(ownedRecordQueries,entity)||!recordId||!/^[A-Za-z0-9_-]{1,100}$/.test(recordId))return Response.json({error:"조회 종류와 기록 번호를 확인하세요."},{status:400,headers:{"Cache-Control":"no-store"}});
  const row=await database().prepare(ownedRecordQueries[entity as keyof typeof ownedRecordQueries]).bind(recordId,user.id).first();
  return row?Response.json(row,{headers:{"Cache-Control":"no-store"}}):missing();
 }
 const result=await ownedSnapshot(database(),request);return Response.json(result.data||{error:result.error},{status:result.status,headers:{"Cache-Control":"no-store"}});
 }catch(e){if(e instanceof Response)return e;return Response.json({error:"자료를 불러오지 못했습니다."},{status:503});}}
export async function POST(request:Request){try{
 const user=await requireUser(request);requireOrigin(request);
 if(Number(request.headers.get("content-length")||0)>20000)return Response.json({error:"입력 크기가 너무 큽니다."},{status:413});
 const b:any=await request.json(); const db=database(), at=now();let createdId:string|undefined;
 if(b.action==="plan"){
 const title=str(b.title,200),start=date(b.start_date),end=date(b.end_date);if(end<start)throw Error("종료일은 시작일보다 빠를 수 없습니다.");
 const values=[title,start,end,priority(b.priority),str(b.success),durationMinutes(b.estimated_minutes)];
 if(b.id){const old:any=await db.prepare("SELECT * FROM plans WHERE id=? AND owner_id=?").bind(b.id,user.id).first();if(!old)throw missing();if(old.version!==b.version) return Response.json({error:"다른 변경이 있습니다. 새로고침 후 다시 수정하세요."},{status:409});
 const updated=await db.batch([db.prepare("INSERT OR IGNORE INTO plan_versions (id,plan_id,version,snapshot,created_at) VALUES (?,?,?,?,?)").bind(id(),old.id,old.version,JSON.stringify(old),at),db.prepare("UPDATE plans SET title=?,start_date=?,end_date=?,priority=?,success=?,estimated_minutes=?,version=version+1 WHERE id=? AND version=?").bind(...values,old.id,old.version)]);if(!updated[1].meta.changes)return Response.json({error:"다른 변경이 있습니다. 새로고침 후 다시 수정하세요."},{status:409});
 }else{let source:any=null;if(b.source_review_id){source=await db.prepare("SELECT r.* FROM reviews r JOIN plans p ON p.id=r.plan_id WHERE r.id=? AND p.owner_id=?").bind(b.source_review_id,user.id).first();if(!source)throw missing();}createdId=id();const statements=[db.prepare("INSERT INTO plans (id,title,start_date,end_date,priority,success,estimated_minutes,improvement,source_review_id,version,created_at,owner_id) VALUES (?,?,?,?,?,?,?,?,?,1,?,?)").bind(createdId,...values,source?.improvement||"",source?.id||null,at,user.id)];
 if(b.starter_tasks===true&&!source){for(const [taskTitle,minutes] of [["과제 안내와 조건 정리",60],["데이터 저장 구조 설계",90],["계획·실행·돌아보기 화면 구현",240],["실제 기록 입력과 저장 확인",90],["검증 증빙과 제출문 정리",60]] as const){statements.push(db.prepare("INSERT INTO tasks (id,plan_id,title,due_date,priority,tags,estimated_minutes,status,generation,created_at) VALUES (?,?,?,?,?,?,?,'todo',0,?)").bind(id(),createdId,taskTitle,end,2,"ALEPH T06",minutes,at));}}
 await db.batch(statements);}
 }else if(b.action==="task"){
 const parent=await db.prepare("SELECT id FROM plans WHERE id=? AND owner_id=?").bind(b.plan_id,user.id).first();if(!parent)throw missing();
 const values=[str(b.title,200),date(b.due_date),priority(b.priority),typeof b.tags==="string"?b.tags.slice(0,500):"",durationMinutes(b.estimated_minutes)];
 if(b.id){const changed=await db.prepare("UPDATE tasks SET title=?,due_date=?,priority=?,tags=?,estimated_minutes=? WHERE id=? AND plan_id=? AND deleted_at IS NULL").bind(...values,b.id,b.plan_id).run();if(!changed.meta.changes)throw missing();}
 else await db.prepare("INSERT INTO tasks (id,plan_id,title,due_date,priority,tags,estimated_minutes,status,generation,created_at) VALUES (?,?,?,?,?,?,?,'todo',0,?)").bind(id(),b.plan_id,...values,at).run();
 }else if(["complete","reopen","delete","restore"].includes(b.action)){
 const task:any=await db.prepare("SELECT t.* FROM tasks t JOIN plans p ON p.id=t.plan_id WHERE t.id=? AND p.owner_id=?").bind(str(b.id,100),user.id).first();if(!task)throw missing();
 if(b.action==="complete"&&!task.deleted_at){const generation=min(b.generation);await db.batch([db.prepare("INSERT OR IGNORE INTO completion_events (id,task_id,generation,created_at) SELECT ?,id,generation,? FROM tasks WHERE id=? AND status='todo' AND generation=? AND deleted_at IS NULL").bind(id(),at,task.id,generation),db.prepare("UPDATE tasks SET status='done' WHERE id=? AND status='todo' AND generation=? AND deleted_at IS NULL").bind(task.id,generation)]);}
 if(b.action==="reopen")await db.prepare("UPDATE tasks SET status='todo',generation=generation+1 WHERE id=? AND status='done' AND generation=? AND deleted_at IS NULL").bind(task.id,min(b.generation)).run();
 if(b.action==="delete")await db.prepare("UPDATE tasks SET deleted_at=? WHERE id=?").bind(at,task.id).run();
 if(b.action==="restore")await db.prepare("UPDATE tasks SET deleted_at=NULL WHERE id=?").bind(task.id).run();
 }else if(b.action==="execution"){
 const task=await db.prepare("SELECT t.id FROM tasks t JOIN plans p ON p.id=t.plan_id WHERE t.id=? AND t.deleted_at IS NULL AND p.owner_id=?").bind(b.task_id,user.id).first();if(!task)throw missing();
 const start=new Date(b.started_at),end=new Date(b.ended_at);if(!Number.isFinite(+start)||!Number.isFinite(+end)||+end<+start)throw Error("실제 시작·종료 시각을 확인하세요.");
 const duration=Math.round((+end-+start)/1000)/60;if(duration>5256000)throw Error("실행 시간이 너무 깁니다.");
 await db.prepare("INSERT OR IGNORE INTO executions (id,task_id,started_at,ended_at,actual_minutes,blocked_reason,request_key,created_at) VALUES (?,?,?,?,?,?,?,?)").bind(id(),b.task_id,start.toISOString(),end.toISOString(),duration,typeof b.blocked_reason==="string"?b.blocked_reason.slice(0,2000):"",user.id+":"+b.task_id+":"+str(b.request_key,100),at).run();
 }else if(b.action==="review"){
 const from=date(b.from_date),to=date(b.to_date);if(to<from)throw Error("기간을 확인하세요.");
 const parent=await db.prepare("SELECT id FROM plans WHERE id=? AND owner_id=?").bind(b.plan_id,user.id).first();if(!parent)throw missing();
 const tasks:any[]=(await db.prepare("SELECT * FROM tasks WHERE plan_id=? AND deleted_at IS NULL AND due_date>=? AND due_date<=?").bind(b.plan_id,from,to).all()).results;
 const executions:any[]=(await db.prepare("SELECT e.* FROM executions e JOIN tasks t ON t.id=e.task_id WHERE t.plan_id=? AND t.deleted_at IS NULL AND t.due_date>=? AND t.due_date<=?").bind(b.plan_id,from,to).all()).results;
 const today=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul'}).format(new Date());
 const metrics={planned:tasks.length,done:tasks.filter(t=>t.status==='done').length,delayed:tasks.filter(t=>t.status!=='done'&&t.due_date<today).length,blocked:tasks.filter(t=>executions.some(e=>e.task_id===t.id&&e.blocked_reason.trim())).length,estimated:tasks.reduce((n,t)=>n+t.estimated_minutes,0),actual:executions.reduce((n,e)=>n+e.actual_minutes,0)};
 await db.prepare("INSERT INTO reviews (id,plan_id,from_date,to_date,improvement,metrics,created_at) VALUES (?,?,?,?,?,?,?)").bind(id(),b.plan_id,from,to,str(b.improvement),JSON.stringify(metrics),at).run();
 }else throw Error("요청을 확인하세요.");
 return Response.json({ok:true,id:createdId});
 }catch(e){if(e instanceof Response)return e;return Response.json({error:e instanceof Error?e.message:"저장하지 못했습니다."},{status:400});}}
