import { database } from "@/db/raw";
const now=()=>new Date().toISOString();
const id=()=>crypto.randomUUID();
const date=(v:any)=>{if(typeof v!=="string"||!/^\d{4}-\d{2}-\d{2}$/.test(v)||new Date(v+"T00:00:00Z").toISOString().slice(0,10)!==v)throw Error("날짜를 확인하세요.");return v;};
const str=(v:any,max=2000)=>{if(typeof v!=="string"||!v.trim()||v.length>max)throw Error("입력한 글자 수와 필수 항목을 확인하세요.");return v.trim();};
const min=(v:any)=>{const n=Number(v);if(!Number.isInteger(n)||n<0||n>100000)throw Error("완료 기록 번호를 확인하세요.");return n;};
const durationMinutes=(v:any)=>{const n=Number(v),seconds=Math.round(n*60);if(!Number.isFinite(n)||n<0||n>5256000||Math.abs(n*60-seconds)>0.00001)throw Error("시간은 0 이상, 최대 10년 범위에서 초 단위로 입력하세요.");return seconds/60;};
const priority=(v:any)=>{const n=Number(v);if(![1,2,3].includes(n))throw Error("우선순위를 선택하세요.");return n;};
export async function GET(){try{const db=database();const names=["plans","plan_versions","tasks","executions","completion_events","reviews"];const data:any={};const snapshot=await db.batch(names.map(name=>db.prepare(`SELECT * FROM ${name}`)));names.forEach((name,i)=>{data[name]=snapshot[i].results;});return Response.json(data,{headers:{"Cache-Control":"no-store"}});}catch{return Response.json({error:"자료를 불러오지 못했습니다. 잠시 뒤 다시 시도하세요."},{status:503});}}
export async function POST(request:Request){try{
 const b:any=await request.json(); const db=database(), at=now();let createdId:string|undefined;
 if(b.action==="plan"){
 const title=str(b.title,200),start=date(b.start_date),end=date(b.end_date);if(end<start)throw Error("종료일은 시작일보다 빠를 수 없습니다.");
 const values=[title,start,end,priority(b.priority),str(b.success),durationMinutes(b.estimated_minutes)];
 if(b.id){const old:any=await db.prepare("SELECT * FROM plans WHERE id=?").bind(b.id).first();if(!old)throw Error("계획이 없습니다.");if(old.version!==b.version) return Response.json({error:"다른 변경이 있습니다. 새로고침 후 다시 수정하세요."},{status:409});
 const updated=await db.batch([db.prepare("INSERT OR IGNORE INTO plan_versions (id,plan_id,version,snapshot,created_at) VALUES (?,?,?,?,?)").bind(id(),old.id,old.version,JSON.stringify(old),at),db.prepare("UPDATE plans SET title=?,start_date=?,end_date=?,priority=?,success=?,estimated_minutes=?,version=version+1 WHERE id=? AND version=?").bind(...values,old.id,old.version)]);if(!updated[1].meta.changes)return Response.json({error:"다른 변경이 있습니다. 새로고침 후 다시 수정하세요."},{status:409});
 }else{let source:any=null;if(b.source_review_id){source=await db.prepare("SELECT * FROM reviews WHERE id=?").bind(b.source_review_id).first();if(!source)throw Error("돌아보기가 없습니다.");}createdId=id();const statements=[db.prepare("INSERT INTO plans (id,title,start_date,end_date,priority,success,estimated_minutes,improvement,source_review_id,version,created_at) VALUES (?,?,?,?,?,?,?,?,?,1,?)").bind(createdId,...values,source?.improvement||"",source?.id||null,at)];
 if(b.starter_tasks===true&&!source){for(const [taskTitle,minutes] of [["과제 안내와 조건 정리",60],["데이터 저장 구조 설계",90],["계획·실행·돌아보기 화면 구현",240],["실제 기록 입력과 저장 확인",90],["검증 증빙과 제출문 정리",60]] as const){statements.push(db.prepare("INSERT INTO tasks (id,plan_id,title,due_date,priority,tags,estimated_minutes,status,generation,created_at) VALUES (?,?,?,?,?,?,?,'todo',0,?)").bind(id(),createdId,taskTitle,end,2,"ALEPH T06",minutes,at));}}
 await db.batch(statements);}
 }else if(b.action==="task"){
 const parent=await db.prepare("SELECT id FROM plans WHERE id=?").bind(b.plan_id).first();if(!parent)throw Error("먼저 계획을 선택하세요.");
 const values=[str(b.title,200),date(b.due_date),priority(b.priority),typeof b.tags==="string"?b.tags.slice(0,500):"",durationMinutes(b.estimated_minutes)];
 if(b.id){const changed=await db.prepare("UPDATE tasks SET title=?,due_date=?,priority=?,tags=?,estimated_minutes=? WHERE id=? AND plan_id=? AND deleted_at IS NULL").bind(...values,b.id,b.plan_id).run();if(!changed.meta.changes)throw Error("수정할 할 일을 찾지 못했습니다. 다시 선택하세요.");}
 else await db.prepare("INSERT INTO tasks (id,plan_id,title,due_date,priority,tags,estimated_minutes,status,generation,created_at) VALUES (?,?,?,?,?,?,?,'todo',0,?)").bind(id(),b.plan_id,...values,at).run();
 }else if(["complete","reopen","delete","restore"].includes(b.action)){
 const task:any=await db.prepare("SELECT * FROM tasks WHERE id=?").bind(str(b.id,100)).first();if(!task)throw Error("할 일이 없습니다.");
 if(b.action==="complete"&&!task.deleted_at){const generation=min(b.generation);await db.batch([db.prepare("INSERT OR IGNORE INTO completion_events (id,task_id,generation,created_at) SELECT ?,id,generation,? FROM tasks WHERE id=? AND status='todo' AND generation=? AND deleted_at IS NULL").bind(id(),at,task.id,generation),db.prepare("UPDATE tasks SET status='done' WHERE id=? AND status='todo' AND generation=? AND deleted_at IS NULL").bind(task.id,generation)]);}
 if(b.action==="reopen")await db.prepare("UPDATE tasks SET status='todo',generation=generation+1 WHERE id=? AND status='done' AND generation=? AND deleted_at IS NULL").bind(task.id,min(b.generation)).run();
 if(b.action==="delete")await db.prepare("UPDATE tasks SET deleted_at=? WHERE id=?").bind(at,task.id).run();
 if(b.action==="restore")await db.prepare("UPDATE tasks SET deleted_at=NULL WHERE id=?").bind(task.id).run();
 }else if(b.action==="execution"){
 const task=await db.prepare("SELECT id FROM tasks WHERE id=? AND deleted_at IS NULL").bind(b.task_id).first();if(!task)throw Error("할 일을 선택하세요.");
 const start=new Date(b.started_at),end=new Date(b.ended_at);if(!Number.isFinite(+start)||!Number.isFinite(+end)||+end<+start)throw Error("실제 시작·종료 시각을 확인하세요.");
 const duration=Math.round((+end-+start)/1000)/60;if(duration>5256000)throw Error("실행 시간이 너무 깁니다.");
 await db.prepare("INSERT OR IGNORE INTO executions (id,task_id,started_at,ended_at,actual_minutes,blocked_reason,request_key,created_at) VALUES (?,?,?,?,?,?,?,?)").bind(id(),b.task_id,start.toISOString(),end.toISOString(),duration,typeof b.blocked_reason==="string"?b.blocked_reason.slice(0,2000):"",str(b.request_key,100),at).run();
 }else if(b.action==="review"){
 const from=date(b.from_date),to=date(b.to_date);if(to<from)throw Error("기간을 확인하세요.");
 const parent=await db.prepare("SELECT id FROM plans WHERE id=?").bind(b.plan_id).first();if(!parent)throw Error("계획을 선택하세요.");
 const tasks:any[]=(await db.prepare("SELECT * FROM tasks WHERE plan_id=? AND deleted_at IS NULL AND due_date>=? AND due_date<=?").bind(b.plan_id,from,to).all()).results;
 const executions:any[]=(await db.prepare("SELECT e.* FROM executions e JOIN tasks t ON t.id=e.task_id WHERE t.plan_id=? AND t.deleted_at IS NULL AND t.due_date>=? AND t.due_date<=?").bind(b.plan_id,from,to).all()).results;
 const today=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul'}).format(new Date());
 const metrics={planned:tasks.length,done:tasks.filter(t=>t.status==='done').length,delayed:tasks.filter(t=>t.status!=='done'&&t.due_date<today).length,blocked:tasks.filter(t=>executions.some(e=>e.task_id===t.id&&e.blocked_reason.trim())).length,estimated:tasks.reduce((n,t)=>n+t.estimated_minutes,0),actual:executions.reduce((n,e)=>n+e.actual_minutes,0)};
 await db.prepare("INSERT INTO reviews (id,plan_id,from_date,to_date,improvement,metrics,created_at) VALUES (?,?,?,?,?,?,?)").bind(id(),b.plan_id,from,to,str(b.improvement),JSON.stringify(metrics),at).run();
 }else throw Error("요청을 확인하세요.");
 return Response.json({ok:true,id:createdId});
 }catch(e){return Response.json({error:e instanceof Error?e.message:"저장하지 못했습니다."},{status:400});}}
