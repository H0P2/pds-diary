import type { Metadata } from "next";
import "./globals.css";
import "./studio-design.css";
import "./auth-design.css";
import "./motion-design.css";
import "./spatial-design.css";

export const metadata: Metadata = {
  title: "플랜두씨 다이어리",
  description: "계획, 실제 실행, 돌아보기를 연결하는 나의 작업 노트",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ko">
      <body className="antialiased">{children}</body>
    </html>
  );
}
