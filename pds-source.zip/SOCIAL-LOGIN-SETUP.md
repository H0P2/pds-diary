# Google / Kakao login

UI and server PKCE flow are implemented. Live Google and Kakao providers remain disabled until the owner supplies application credentials through the Supabase dashboard. No fake social session is issued.

Supabase project: jeaajqoysjqygpqmwuvx.

Provider callback (register in Google Cloud and Kakao Developers):
`https://jeaajqoysjqygpqmwuvx.supabase.co/auth/v1/callback`

Site origin:
`https://pds-diary-hope-20261008.mo990025.chatgpt.site`

Supabase redirect allowlist:
`https://pds-diary-hope-20261008.mo990025.chatgpt.site/auth/social/callback?attempt=*`

Google: create a Web OAuth client with this site origin and provider callback; enter its Client ID and Client Secret in Supabase Google provider settings. Choose the intended audience and test users in Google Cloud.

Kakao: create/configure an application, enable Kakao Login, register the provider callback, enable account_email consent, create a client secret, and enter REST API key + client secret in Supabase Kakao provider settings. Users without a verified email cannot receive a diary session.

Secrets belong only in provider settings, never in Git, public assets, chat, or logs. Each service login happens on its own website; the diary does not receive its password.

The UI reads the live provider status. Each configured provider becomes available on the next page load. Real provider consent/login still requires owner configuration and a real-user end-to-end check.

Validation: actual protected-route tests with synthetic provider responses cover disabled provider rejection, origin checks, missing/expired/wrong flow cookies, code exchange, provider getUser verification and HttpOnly app session. Pinned Supabase SDK was also checked offline to generate S256 PKCE and only verifier storage slots. This does not establish live provider completion.
