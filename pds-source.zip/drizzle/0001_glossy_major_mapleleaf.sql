CREATE TABLE `auth_rate_limits` (
	`key_hash` text NOT NULL,
	`window_start` integer NOT NULL,
	`attempts` integer DEFAULT 1 NOT NULL,
	PRIMARY KEY(`key_hash`, `window_start`)
);
--> statement-breakpoint
CREATE TABLE `diary_accounts` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text,
	`role` text DEFAULT 'member' NOT NULL,
	`auth_version` integer DEFAULT 1 NOT NULL,
	`created_at` integer NOT NULL,
	`deleted_at` integer,
	CONSTRAINT "diary_accounts_role" CHECK("diary_accounts"."role" IN ('member','admin'))
);
--> statement-breakpoint
CREATE TABLE `diary_audit` (
	`id` text PRIMARY KEY NOT NULL,
	`account_id` text,
	`event` text NOT NULL,
	`success` integer NOT NULL,
	`created_at` integer NOT NULL,
	CONSTRAINT "diary_audit_success" CHECK("diary_audit"."success" IN (0,1))
);
--> statement-breakpoint
CREATE INDEX `diary_audit_time` ON `diary_audit` (`created_at`);--> statement-breakpoint
CREATE TABLE `diary_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`auth_version` integer NOT NULL,
	`created_at` integer NOT NULL,
	`expires_at` integer NOT NULL,
	`revoked_at` integer,
	FOREIGN KEY (`user_id`) REFERENCES `diary_accounts`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `diary_sessions_user` ON `diary_sessions` (`user_id`);--> statement-breakpoint
CREATE TABLE `feedback` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`category` text NOT NULL,
	`screen` text NOT NULL,
	`problem` text NOT NULL,
	`suggestion` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'received' NOT NULL,
	`priority` text NOT NULL,
	`group_key` text NOT NULL,
	`reason` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	`deleted_at` text,
	FOREIGN KEY (`user_id`) REFERENCES `diary_accounts`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "feedback_category" CHECK("feedback"."category" IN ('design','ux','feature','bug')),
	CONSTRAINT "feedback_screen" CHECK(length("feedback"."screen") BETWEEN 1 AND 100),
	CONSTRAINT "feedback_problem" CHECK(length("feedback"."problem") BETWEEN 1 AND 2000),
	CONSTRAINT "feedback_suggestion" CHECK(length("feedback"."suggestion")<=2000),
	CONSTRAINT "feedback_status" CHECK("feedback"."status" IN ('received','reviewing','proposed','applied','deferred')),
	CONSTRAINT "feedback_priority" CHECK("feedback"."priority" IN ('urgent','high','normal','low'))
);
--> statement-breakpoint
CREATE INDEX `feedback_owner` ON `feedback` (`user_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `feedback_groups` ON `feedback` (`group_key`,`deleted_at`);--> statement-breakpoint
CREATE TABLE `feedback_events` (
	`id` text PRIMARY KEY NOT NULL,
	`feedback_id` text NOT NULL,
	`actor_id` text NOT NULL,
	`action` text NOT NULL,
	`reason` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`feedback_id`) REFERENCES `feedback`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`actor_id`) REFERENCES `diary_accounts`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
ALTER TABLE `plans` ADD `owner_id` text REFERENCES diary_accounts(id);--> statement-breakpoint
CREATE INDEX `plans_owner` ON `plans` (`owner_id`);