CREATE TABLE `ui_changes` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`feedback_id` text,
	`before_json` text NOT NULL,
	`after_json` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `diary_accounts`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `ui_changes_owner` ON `ui_changes` (`user_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `ui_preferences` (
	`user_id` text PRIMARY KEY NOT NULL,
	`preferences` text DEFAULT '{}' NOT NULL,
	`automatic` integer DEFAULT 1 NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `diary_accounts`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "ui_preferences_automatic" CHECK("ui_preferences"."automatic" IN (0,1))
);
