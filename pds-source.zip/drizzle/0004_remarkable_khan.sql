CREATE TABLE `study_days` (
	`id` text PRIMARY KEY NOT NULL,
	`protocol_id` text NOT NULL,
	`day_number` integer NOT NULL,
	`seoul_date` text NOT NULL,
	`sessions_json` text NOT NULL,
	`total_minutes` real NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`protocol_id`) REFERENCES `study_protocols`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "study_five_days" CHECK("study_days"."day_number" BETWEEN 1 AND 5),
	CONSTRAINT "study_day_minutes" CHECK("study_days"."total_minutes" BETWEEN 0 AND 1440)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `study_day_number_unique` ON `study_days` (`protocol_id`,`day_number`);--> statement-breakpoint
CREATE UNIQUE INDEX `study_date_unique` ON `study_days` (`protocol_id`,`seoul_date`);--> statement-breakpoint
CREATE TABLE `study_protocols` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`question` text NOT NULL,
	`rules_json` text NOT NULL,
	`baseline_rule` text NOT NULL,
	`changed_rule` text,
	`change_reason` text,
	`change_refs` text,
	`changed_at` text,
	`created_at` text NOT NULL,
	`manual_check_json` text,
	`manual_checked_at` text,
	FOREIGN KEY (`user_id`) REFERENCES `diary_accounts`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `study_owner_unique` ON `study_protocols` (`user_id`);