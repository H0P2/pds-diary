CREATE TABLE `diary_profiles` (
	`user_id` text PRIMARY KEY NOT NULL,
	`username` text NOT NULL,
	`display_name` text NOT NULL,
	`bio` text DEFAULT '' NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `diary_accounts`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "profile_username_format" CHECK(length("diary_profiles"."username") BETWEEN 3 AND 20 AND "diary_profiles"."username"=lower("diary_profiles"."username") AND "diary_profiles"."username" NOT GLOB '*[^a-z0-9_]*'),
	CONSTRAINT "profile_name_length" CHECK(length("diary_profiles"."display_name") BETWEEN 1 AND 30),
	CONSTRAINT "profile_bio_length" CHECK(length("diary_profiles"."bio")<=200)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `diary_profiles_username_unique` ON `diary_profiles` (`username`);--> statement-breakpoint
CREATE TABLE `community_comments` (
	`id` text PRIMARY KEY NOT NULL,
	`post_id` text NOT NULL,
	`author_id` text NOT NULL,
	`body` text NOT NULL,
	`created_at` text NOT NULL,
	`deleted_at` text,
	FOREIGN KEY (`post_id`) REFERENCES `community_posts`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`author_id`) REFERENCES `diary_accounts`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "community_comment_body" CHECK(length("community_comments"."body") BETWEEN 1 AND 1000)
);
--> statement-breakpoint
CREATE INDEX `community_comments_thread` ON `community_comments` (`post_id`,`deleted_at`,`created_at`,`id`);--> statement-breakpoint
CREATE INDEX `community_comments_author` ON `community_comments` (`author_id`);--> statement-breakpoint
CREATE TABLE `community_posts` (
	`id` text PRIMARY KEY NOT NULL,
	`author_id` text NOT NULL,
	`title` text NOT NULL,
	`body` text NOT NULL,
	`plan_snapshot` text,
	`created_at` text NOT NULL,
	`deleted_at` text,
	FOREIGN KEY (`author_id`) REFERENCES `diary_accounts`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "community_post_title" CHECK(length("community_posts"."title") BETWEEN 1 AND 200),
	CONSTRAINT "community_post_body" CHECK(length("community_posts"."body")<=3000)
);
--> statement-breakpoint
CREATE INDEX `community_posts_feed` ON `community_posts` (`deleted_at`,`created_at`,`id`);--> statement-breakpoint
CREATE INDEX `community_posts_author` ON `community_posts` (`author_id`);