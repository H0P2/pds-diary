# 플랜두씨 다이어리 · ALEPH T06
계획 → 할 일 → 실행 → 돌아보기 → 다음 계획을 Cloudflare D1에 저장합니다.

## 실행
Node.js 22.13 이상. npm ci, npm run db:generate, npm run build 후 README의 마이그레이션 파일을 로컬 DB에 적용하고 npm run dev로 엽니다.
로컬 DB: node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_easy_sentinel.sql

## 주요 규칙
로그인 없음. 공개해서 괜찮은 내용만 입력하세요. 저장 단위는 정수 분, 시각은 UTC ISO8601, 날짜·지연 판정은 Asia/Seoul입니다. 기간 집계는 할 일 마감일의 시작~끝 양끝 포함입니다. 보관한 할 일은 집계에서 제외하고 복원할 수 있습니다. 완료 취소 후 다시 완료하면 새 세대의 완료 이력이 추가됩니다. 실제 실행은 여러 세션을 저장할 수 있습니다.

contracts/pds-schema-v2.json에 최종 필드·관계·날짜 규칙이 있습니다. docs/role-vaults에 세 역할의 초안·실제계약·검증 결과가 있습니다. 제안서와 실제 구현이 다르면 실제 계약이 우선합니다.

## 확인 방법 초안 (사용자 실제 기록 입력 후 재확인)
1. 첫 화면에서 계획을 저장하면 과제 진행 할 일 5개가 함께 생깁니다.
2. 실행 탭에서 실제 시작·종료를 기록하고, 돌아보기 숫자를 눌러 근거를 확인합니다.
3. 새로고침해도 같은 기록이 남고 전체 내보내기로 JSON 파일 1개를 받을 수 있으면 통과입니다.
4. 저장 실패 시 오류 안내가 나타납니다. 입력을 유지한 채 다시 불러오거나 재시도하세요.

## 남은 사용자 작업
본인의 실제 실행 기록 3건 이상, 계획 기간·우선순위·예상시간 확인, AI에 맡긴 일/직접 판단/제안 미채택 이유 3줄 작성. 검증용 데이터는 실제 실행 실적으로 제출하지 않습니다. 앱과 소스 URL의 시크릿 창 확인 후 제출하세요.
