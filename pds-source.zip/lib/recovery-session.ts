import { env } from 'cloudflare:workers';
export const recoverySessionCookieName='__Host-pds-recovery-session';
export const recoverySessionLifetime=10*60*1000;
export type RecoverySession={nonce:string;created:number;user_id:string;access_token:string;refresh_token:string};
export function recoverySessionCookie(value:string,maxAge=600){return `${recoverySessionCookieName}=${value}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;}
async function key(){
 const secret=(env as unknown as {RECOVERY_SESSION_KEY?:string}).RECOVERY_SESSION_KEY;
 if(!secret||! /^[a-fA-F0-9]{64}$/.test(secret))throw Error('Recovery encryption not configured');
 const bytes=Uint8Array.from(secret.match(/../g)!,v=>parseInt(v,16));
 return crypto.subtle.importKey('raw',bytes,{name:'AES-GCM'},false,['encrypt','decrypt']);
}
export async function ensureRecoverySessionConfigured(){await key();}
function encode(bytes:Uint8Array){return btoa(String.fromCharCode(...bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function decode(value:string){return Uint8Array.from(atob(value.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));}
export async function sealRecoverySession(session:RecoverySession){
 const iv=crypto.getRandomValues(new Uint8Array(12));
 const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:new TextEncoder().encode(recoverySessionCookieName)},await key(),new TextEncoder().encode(JSON.stringify(session)));
 const bytes=new Uint8Array(iv.length+cipher.byteLength);bytes.set(iv);bytes.set(new Uint8Array(cipher),iv.length);
 const value=encode(bytes);if(value.length>3800)throw Error('Recovery session too large');return value;
}
export async function readRecoverySession(request:Request):Promise<RecoverySession|null>{
 const matches=(request.headers.get('cookie')||'').split(';').map(v=>v.trim()).filter(v=>v.startsWith(recoverySessionCookieName+'='));
 if(matches.length!==1)return null;const value=matches[0].slice(recoverySessionCookieName.length+1);
 if(! /^[a-zA-Z0-9_-]{40,3800}$/.test(value))return null;
 const cryptoKey=await key();
 try{
  const bytes=decode(value);const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:bytes.slice(0,12),additionalData:new TextEncoder().encode(recoverySessionCookieName)},cryptoKey,bytes.slice(12));
  const s=JSON.parse(new TextDecoder().decode(plain));
  if(!s||! /^[a-f0-9-]{36}$/.test(s.nonce)||!Number.isFinite(s.created)||s.created>Date.now()||Date.now()-s.created>=recoverySessionLifetime||typeof s.user_id!=='string'||!s.user_id||typeof s.access_token!=='string'||!s.access_token||typeof s.refresh_token!=='string'||!s.refresh_token)return null;
  return s;
 }catch{return null;}
}
