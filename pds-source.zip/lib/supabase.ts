import { createClient } from '@supabase/supabase-js';
import { env } from 'cloudflare:workers';
export function provider() {
  if (!env.SUPABASE_URL || !env.SUPABASE_PUBLISHABLE_KEY) throw new Error('Authentication not configured');
  return createClient(env.SUPABASE_URL, env.SUPABASE_PUBLISHABLE_KEY, {
    auth: { persistSession:false, autoRefreshToken:false, detectSessionInUrl:false, flowType:'pkce' },
  });
}
export function ownerEmail() { return (env.DIARY_OWNER_EMAIL || '').trim().toLowerCase(); }

// OAuth storage stays in server memory; only PKCE verifier slots enter an HttpOnly cookie.
export function oauthProvider(storage:{getItem:(key:string)=>string|null;setItem:(key:string,value:string)=>void;removeItem:(key:string)=>void}) {
  if (!env.SUPABASE_URL || !env.SUPABASE_PUBLISHABLE_KEY) throw new Error('Authentication not configured');
  return createClient(env.SUPABASE_URL,env.SUPABASE_PUBLISHABLE_KEY,{auth:{persistSession:true,storage,autoRefreshToken:false,detectSessionInUrl:false,flowType:'pkce'}});
}
export async function socialAvailability() {
  if (!env.SUPABASE_URL || !env.SUPABASE_PUBLISHABLE_KEY) throw new Error('Authentication not configured');
  const response=await fetch(`${env.SUPABASE_URL}/auth/v1/settings`,{headers:{apikey:env.SUPABASE_PUBLISHABLE_KEY},signal:AbortSignal.timeout(5000)});
  if(!response.ok)throw new Error('Provider settings unavailable');
  const settings:any=await response.json();return {google:settings.external?.google===true,kakao:settings.external?.kakao===true};
}
export function providerOrigin(){return new URL(env.SUPABASE_URL||'').origin;}
