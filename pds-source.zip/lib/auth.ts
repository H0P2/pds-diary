// Server-only: provider verification happens in the auth route.
// @ts-nocheck
import { database } from '@/db/raw';
export const COOKIE_NAME = '__Host-pds-session';
const lifetimeMs = 60 * 60 * 1000;
const tokenPattern = /^[a-f0-9]{64}$/;
const hex = bytes => Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
export async function digestToken(token) {
  return hex(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(token))));
}
function readCookie(request) {
  const matches = (request.headers.get('cookie') || '').split(';').map(part => part.trim())
    .filter(part => part.startsWith(`${COOKIE_NAME}=`));
  if (matches.length !== 1) return null;
  const token = matches[0].slice(COOKIE_NAME.length + 1);
  return tokenPattern.test(token) ? token : null;
}
export function sessionCookie(token) {
  if (!tokenPattern.test(token)) throw new Error('Invalid session token');
  return `${COOKIE_NAME}=${token}; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=3600`;
}
export const clearCookie = () => `${COOKIE_NAME}=; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=0`;

// verifiedUser must come from the server-side Auth response, never request JSON.
export async function issueSession(db, verifiedUser, now = Date.now()) {
  if (!verifiedUser?.id || !verifiedUser.email_confirmed_at || !verifiedUser.email) {
    throw new Error('Verified email required');
  }
  const token = hex(crypto.getRandomValues(new Uint8Array(32)));
  const tokenHash = await digestToken(token);
  const expires = now + lifetimeMs;
  await db.prepare(`INSERT INTO diary_sessions (token_hash,user_id,auth_version,created_at,expires_at)
    SELECT ?,id,auth_version,?,? FROM diary_accounts WHERE id=? AND deleted_at IS NULL`)
    .bind(tokenHash, now, expires, verifiedUser.id).run();
  const persisted = await db.prepare('SELECT token_hash FROM diary_sessions WHERE token_hash=?').bind(tokenHash).first();
  if (!persisted) throw new Error('Account unavailable');
  return { cookie: sessionCookie(token), expiresAt: expires };
}
export async function authenticate(db, request, now = Date.now()) {
  const token = readCookie(request);
  if (!token) return null;
  const session = await db.prepare(`SELECT a.id AS user_id,a.role,s.token_hash,s.expires_at
    FROM diary_sessions s JOIN diary_accounts a ON a.id=s.user_id
    WHERE s.token_hash=? AND s.revoked_at IS NULL AND s.expires_at>?
    AND s.auth_version=a.auth_version AND a.deleted_at IS NULL`)
    .bind(await digestToken(token), now).first();
  return session || null;
}
export async function revokeCurrentSession(db, request, now = Date.now()) {
  const token = readCookie(request);
  if (token) await db.prepare('UPDATE diary_sessions SET revoked_at=? WHERE token_hash=? AND revoked_at IS NULL')
    .bind(now, await digestToken(token)).run();
  return clearCookie();
}
export async function revokeAllSessions(db, verifiedUserId) {
  await db.prepare('UPDATE diary_accounts SET auth_version=auth_version+1 WHERE id=?').bind(verifiedUserId).run();
}
export function requireSameOrigin(request) {
  const origin = request.headers.get('origin');
  if (!origin || origin !== new URL(request.url).origin) throw new Error('Origin rejected');
}
export function requireOrigin(request: Request) {
  try { requireSameOrigin(request); } catch { throw Response.json({error:'요청 출처를 확인할 수 없습니다.'},{status:403}); }
}
export async function requireUser(request: Request) {
  const principal = await authenticate(database(), request);
  if (!principal) throw Response.json({error:'로그인이 필요합니다.'},{status:401});
  const account = await database().prepare('SELECT email FROM diary_accounts WHERE id=?').bind(principal.user_id).first();
  return {id:principal.user_id,email:account?.email||'',role:principal.role};
}

// Each name and SQL expression is fixed server-side; no table name from request input.
const ownedQueries = {
  plans: 'SELECT p.* FROM plans p WHERE p.owner_id=?',
  plan_versions: 'SELECT v.* FROM plan_versions v JOIN plans p ON p.id=v.plan_id WHERE p.owner_id=?',
  tasks: 'SELECT t.* FROM tasks t JOIN plans p ON p.id=t.plan_id WHERE p.owner_id=?',
  executions: 'SELECT e.* FROM executions e JOIN tasks t ON t.id=e.task_id JOIN plans p ON p.id=t.plan_id WHERE p.owner_id=?',
  completion_events: 'SELECT e.* FROM completion_events e JOIN tasks t ON t.id=e.task_id JOIN plans p ON p.id=t.plan_id WHERE p.owner_id=?',
  reviews: 'SELECT r.* FROM reviews r JOIN plans p ON p.id=r.plan_id WHERE p.owner_id=?',
};
export async function ownedSnapshot(db, request, now = Date.now()) {
  const principal = await authenticate(db, request, now);
  if (!principal) return { status: 401, error: '로그인이 필요합니다.' };
  const names = Object.keys(ownedQueries);
  const result = await db.batch(names.map(name => db.prepare(ownedQueries[name]).bind(principal.user_id)));
  return { status: 200, data: Object.fromEntries(names.map((name, index) => [name, result[index].results])) };
}

const auditEvents = new Set(['signup', 'login', 'logout', 'password_change', 'account_delete']);
export async function audit(db, event, success, accountId: string | null = null, now = Date.now(), email: string | null = null) {
  if (!auditEvents.has(event) || typeof success !== 'boolean') throw new Error('Invalid audit event');
  // Allow only normalized signup emails; never serialize passwords or request bodies.
  if (email !== null && (event !== 'signup' || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))) throw new Error('Invalid audit email');
  await db.prepare('INSERT INTO diary_audit (id,account_id,event,success,created_at,email) VALUES (?,?,?,?,?,?)')
    .bind(crypto.randomUUID(), accountId, event, success ? 1 : 0, now, email).run();
}
