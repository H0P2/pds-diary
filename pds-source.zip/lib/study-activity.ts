import { seoulDate, roundMinutes, type StudyDay, type StudyProtocol } from './study';

export const activityScanLimit = 1000;
type ExecutionInterval = { started_at: unknown; ended_at: unknown };

// Require an explicit timezone and a real calendar date; Date.parse alone normalizes invalid dates.
function timestamp(value: unknown): number | null {
 if (typeof value !== 'string') return null;
 const match = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d{1,9})?(Z|[+-]\d{2}:\d{2})$/i.exec(value);
 if (!match) return null;
 const [, year, month, day, hour, minute, second, zone] = match;
 const calendar = new Date(`${year}-${month}-${day}T00:00:00Z`);
 if (!Number.isFinite(+calendar) || calendar.toISOString().slice(0,10) !== `${year}-${month}-${day}` || +hour > 23 || +minute > 59 || +second > 59) return null;
 if (zone.toUpperCase() !== 'Z' && (+zone.slice(1,3) > 23 || +zone.slice(4,6) > 59)) return null;
 const parsed = Date.parse(value);
 return Number.isFinite(parsed) ? parsed : null;
}

export function studyActivity(entries: ExecutionInterval[], now: number, protocol: StudyProtocol | null, days: StudyDay[]) {
 const today = seoulDate(now), startOfDay = Date.parse(`${today}T00:00:00+09:00`), endOfDay = startOfDay + 86400000;
 const intervals: [number, number][] = [];
 let invalid = 0, sourceCount = 0;
 for (const entry of entries) {
  const start = timestamp(entry.started_at), end = timestamp(entry.ended_at);
  if (start === null || end === null || end <= start || start > now || end > now) { invalid++; continue; }
  const clippedStart = Math.max(start, startOfDay), clippedEnd = Math.min(end, endOfDay);
  if (clippedEnd <= clippedStart) continue;
  sourceCount++;
  intervals.push([clippedStart, clippedEnd]);
 }
 intervals.sort((a,b) => a[0]-b[0]);
 const merged: [number,number][] = [];
 for (const interval of intervals) {
  const previous = merged.at(-1);
  if (previous && interval[0] <= previous[1]) previous[1] = Math.max(previous[1], interval[1]);
  else merged.push([...interval]);
 }
 const sessionSeconds = merged.map(([start,end]) => Math.round((end-start)/1000)).filter(seconds => seconds > 0);
 const seconds = sessionSeconds.reduce((sum,value) => sum+value, 0);
 const notes = [`내 계정의 최근 실행 기록 최대 ${activityScanLimit}건만 확인합니다. 더 오래된 기록은 초안에서 빠질 수 있습니다.`, '저장된 시작·종료 시각만 사용하며 서울 날짜 경계를 나누고 겹치는 구간은 한 번만 합산합니다. 초 단위로 반올림합니다. 브라우저·대기 시간은 수집하지 않습니다.'];
 if (invalid) notes.push(`시각이 없거나 잘못되었거나 종료가 시작보다 늦지 않거나 미래인 ${invalid}건은 제외했습니다.`);
 if (!sessionSeconds.length) notes.push('오늘 합산할 실제 실행 구간이 없습니다. 미기록을 0분 사용으로 만들지 않습니다.');
 if (intervals.length > merged.length) notes.push('겹치거나 이어지는 실행 구간을 합쳤습니다.');
 let canRecord = sessionSeconds.length > 0;
 if (seconds > 86400) { canRecord = false; notes.push('초 단위 반올림 후 하루 저장 한도 1440분을 넘습니다. 구간을 직접 확인해 주세요.'); }
 if (sessionSeconds.length > 100) { canRecord = false; notes.push('합쳐진 구간이 100개를 넘습니다. 초안은 확인할 수 있지만 저장 가능한 구간 수를 넘어 자동으로 채울 수 없습니다.'); }
 if (protocol && (days.length >= 5 || days.some(day => day.seoul_date >= today))) { canRecord = false; notes.push('오늘 기록이 이미 저장되었거나 5일 기록이 완료되어 추가 저장할 수 없습니다.'); }
 if (protocol && days.length >= 2 && !protocol.changed_at) { canRecord = false; notes.push('다음 기록 전에 작업 시작 규칙 변경을 직접 확인하고 저장해야 합니다.'); }
 if (protocol && days.length >= 2 && protocol.changed_at && Date.parse(protocol.changed_at) >= now) { canRecord = false; notes.push('규칙 변경 시각 이후에 다음 기록을 확인해 주세요.'); }
 const baselineSuggestion = protocol?.baseline_rule || '작업 시작 전에 오늘 할 작업 한 가지를 고르고 바로 시작한다.';
 const changeSuggestion = protocol && days.length === 2 && !protocol.changed_at && !protocol.changed_rule ? {
  rule: protocol.baseline_rule === '작업 시작 전에 첫 행동 한 가지를 적고 5분 타이머를 시작한다.' ? '작업 시작 전에 오늘 할 작업 한 가지를 고르고 바로 시작한다.' : '작업 시작 전에 첫 행동 한 가지를 적고 5분 타이머를 시작한다.',
  reason: `저장된 1일차 ${days[0].seoul_date} ${roundMinutes(days[0].total_minutes)}분, 2일차 ${days[1].seoul_date} ${roundMinutes(days[1].total_minutes)}분을 확인했습니다. 이 두 기록만으로 효과를 단정할 수 없어 시작 규칙 한 가지만 바꿔 다음 3일 기록과 비교하려는 제안입니다.`,
 } : null;
 return { today, source_count: sourceCount, seconds, minutes: seconds/60, sessions: sessionSeconds.map(value => value/60), notes, can_record: canRecord, baseline_suggestion: baselineSuggestion, change_suggestion: changeSuggestion };
}
