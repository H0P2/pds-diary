const channelName='pds-session-change';
const storageKey='pds-session-change';
let revision=0;
export const getSessionRevision=()=>revision;
export function invalidateSessionView(){revision++;}
// Only a change signal crosses tabs. Identity, cookies and tokens never enter it.
export function notifySessionChanged(includeLocal=true){
 if(typeof window==='undefined')return;
 try{const channel=new BroadcastChannel(channelName);channel.postMessage('changed');channel.close();}catch{}
 try{window.localStorage.setItem(storageKey,crypto.randomUUID());}catch{}
 if(includeLocal)window.dispatchEvent(new Event(channelName));
}
export function subscribeSessionChanges(onChange:()=>void){
 let channel:BroadcastChannel|undefined;
 try{channel=new BroadcastChannel(channelName);channel.onmessage=event=>{if(event.data==='changed')onChange();};}catch{}
 const storage=(event:StorageEvent)=>{if(event.key===storageKey&&event.newValue)onChange();};
 window.addEventListener('storage',storage);
 window.addEventListener(channelName,onChange);
 return()=>{channel?.close();window.removeEventListener('storage',storage);window.removeEventListener(channelName,onChange);};
}
