import { database } from '@/db/raw';
import { ownerEmail } from '@/lib/supabase';
import { issueSession, audit } from '@/lib/auth';
import type { User } from '@supabase/supabase-js';
const headers = {'Cache-Control':'private, no-store'};
function fail(message:string,status=400):never { throw Response.json({error:message},{status,headers}); }
export async function signedIn(user:User, socialRegistration=false) {
  if (!user.email_confirmed_at || !user.email || user.is_anonymous) fail('이메일 인증을 완료하세요.',401);
  const db=database(),now=Date.now(),isOwner=user.email.toLowerCase()===ownerEmail();
  const existing=await db.prepare('SELECT id,deleted_at FROM diary_accounts WHERE id=?').bind(user.id).first<{id:string;deleted_at:number|null}>();
  if(existing?.deleted_at)fail('삭제한 다이어리 계정은 다시 로그인할 수 없습니다.',403);
  const statements=[db.prepare("INSERT INTO diary_accounts(id,email,role,created_at) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET email=excluded.email,role=excluded.role WHERE diary_accounts.deleted_at IS NULL").bind(user.id,user.email,isOwner?'admin':'member',now)];
  if(isOwner)statements.push(db.prepare('UPDATE plans SET owner_id=? WHERE owner_id IS NULL').bind(user.id));
  await db.batch(statements);
  const session=await issueSession(db,user,now);
  const account=await db.prepare('SELECT role FROM diary_accounts WHERE id=?').bind(user.id).first<{role:string}>();
  if(socialRegistration&&!existing)await audit(db,'signup',true,user.id,now,user.email.toLowerCase());
  await audit(db,'login',true,user.id,now);
  const profile=await db.prepare('SELECT username,display_name FROM diary_profiles WHERE user_id=?').bind(user.id).first<{username:string;display_name:string}>();
  return Response.json({user:{id:user.id,email:user.email,role:account?.role||'member',username:profile?.username||null,display_name:profile?.display_name||''}},{headers:{...headers,'Set-Cookie':session.cookie}});
}
