// Months are a fixed estimate, not calendar arithmetic. Plan dates remain calendar dates.
export const durationUnits = [
  { value: 'month', label: '달', minutes: 43200 },
  { value: 'week', label: '주', minutes: 10080 },
  { value: 'hour', label: '시간', minutes: 60 },
  { value: 'minute', label: '분', minutes: 1 },
  { value: 'second', label: '초', minutes: 1 / 60 },
] as const;
export function preferredUnit(minutes: number) {
  const seconds = Math.round(Math.abs(minutes) * 60);
  return durationUnits.find(u => seconds > 0 && seconds % Math.round(u.minutes * 60) === 0) || durationUnits[3];
}
export function formatDuration(minutes: number, unset = false): string {
  let seconds = Math.round(Math.abs(Number(minutes) || 0) * 60);
  if (!seconds) return unset ? '미정' : '0초';
  const parts: string[] = [];
  for (const unit of durationUnits) {
    const size = Math.round(unit.minutes * 60), count = Math.floor(seconds / size);
    if (count) { parts.push(`${count}${unit.label}`); seconds %= size; }
  }
  return (minutes < 0 ? '−' : '') + parts.join(' ');
}
export function seoulTimestamp(value: string): string {
  return value + (value.length === 16 ? ':00' : '') + '+09:00';
}
