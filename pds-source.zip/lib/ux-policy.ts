/** Fixed local rules. Submitted text never becomes executable code or CSS. */
export type ExperiencePreferences={large_text:boolean;high_contrast:boolean;comfortable:boolean};
export type ExperienceKey=keyof ExperiencePreferences;
export const experienceLabels:Record<ExperienceKey,string>={large_text:'글자 크게',high_contrast:'대비 높게',comfortable:'버튼·간격 여유롭게'};
export function preferencesFrom(value:unknown):ExperiencePreferences {
 let parsed:unknown=value;
 if(typeof value==='string'){try{parsed=JSON.parse(value);}catch{parsed={};}}
 const record=parsed&&typeof parsed==='object'?parsed as Record<string,unknown>:{};
 return {large_text:record.large_text===true,high_contrast:record.high_contrast===true,comfortable:record.comfortable===true};
}
export function preferenceSuggestions(text:string):ExperienceKey[] {
 const result:ExperienceKey[]=[];
 if(/글자.{0,12}(작|크게)|작은\s*(글씨|글자)|글씨.{0,12}(작|크게)|작은\s*텍스트|small\s*(text|font)/i.test(text))result.push('large_text');
 if(/대비|contrast|색.{0,8}(구분|흐리)|흐린.{0,8}(글|텍스트)/i.test(text))result.push('high_contrast');
 if(/모바일|작은\s*화면|mobile|버튼.{0,12}(찾기|찾기 어려|누르기 어려|작|안 보)|버튼.{0,8}어려/i.test(text))result.push('comfortable');
 return result;
}
export function applyPreferenceSuggestions(current:ExperiencePreferences,keys:ExperienceKey[]):ExperiencePreferences {
 const result={...current};for(const key of keys)if(Object.hasOwn(experienceLabels,key))result[key]=true;return result;
}
export function preferenceSql(keys:ExperienceKey[]):string {
 // Only the three allowlisted keys can reach SQL; user feedback is never interpolated.
 const allowed=keys.filter(key=>Object.hasOwn(experienceLabels,key));
 return allowed.length?`json_set(preferences,${allowed.map(key=>`'$.${key}',json('true')`).join(',')})`:'preferences';
}
