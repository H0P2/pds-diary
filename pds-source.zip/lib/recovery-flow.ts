export const recoveryCookieName='__Host-pds-recovery';
export const recoveryLifetime=30*60*1000;
export function recoveryCookie(value:string,maxAge=1800){return `${recoveryCookieName}=${encodeURIComponent(value)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;}
export function readRecovery(request:Request){try{
 const matches=(request.headers.get('cookie')||'').split(';').map(s=>s.trim()).filter(s=>s.startsWith(recoveryCookieName+'='));if(matches.length!==1)return null;
 const raw=matches[0].slice(recoveryCookieName.length+1);if(raw.length>6000)return null;const f=JSON.parse(decodeURIComponent(raw));
 if(!/^[a-f0-9-]{36}$/.test(f.nonce)||!Number.isFinite(f.created)||f.created>Date.now()||Date.now()-f.created>recoveryLifetime||!f.verifiers||typeof f.verifiers!=='object'||Array.isArray(f.verifiers))return null;
 const slots=Object.entries(f.verifiers);let recovery=false;if(!slots.length)return null;for(const [k,v] of slots){if(!k.includes('code-verifier')||typeof v!=='string'||v.length>1000)return null;const decoded=JSON.parse(v);if(Array.isArray(decoded)){if(decoded.some(x=>typeof x!=='string'||!/^[a-f0-9]{32}$/.test(x)))return null;}else if(typeof decoded==='string'&&decoded.endsWith('/recovery'))recovery=true;else return null;}if(!recovery)return null;return f as {nonce:string;created:number;verifiers:Record<string,string>};
 }catch{return null;}}
