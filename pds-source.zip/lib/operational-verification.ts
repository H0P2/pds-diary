export type OperationalVerificationInput = { mode: "read" | "fixture" | "foreign"; plan_id?: string; task_id?: string; owner_id?: string };
type Row = Record<string, unknown>;
type Snapshot = Record<string, unknown>;
const entities = ["plans", "tasks", "executions", "plan_versions", "reviews", "completion_events"] as const;
const fixtureTitle = "운영 검증 전용 · 실사용 아님";
const taskTitle = "검증용 할 일 · 실사용 아님";
const rows = (data: Snapshot, key: string): Row[] => Array.isArray(data[key]) ? data[key] as Row[] : [];
const counts = (data: Snapshot) => Object.fromEntries(entities.map(key => [key, rows(data, key).length]));
const exportLists = ["community_posts", "community_comments", "study_protocols", "study_days", "feedback", "feedback_events", "experience", "experience_changes", "security_activity"] as const;
function completeSnapshot(value: Snapshot): boolean { return entities.every(key => Array.isArray(value[key])); }
function canonical(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonical).sort().join(",")}]`;
  if (value && typeof value === "object") return "{" + Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([key, child]) => `${JSON.stringify(key)}:${canonical(child)}`).join(",") + "}";
  return JSON.stringify(value) ?? "null";
}
async function snapshotDigest(value: Snapshot): Promise<string> {
  const content = Object.fromEntries(entities.map(key => [key, value[key]]));
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonical(content)));
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
}
function hasCredentialField(value: unknown): boolean {
  if (!value || typeof value !== "object") return false;
  return Object.entries(value).some(([key, child]) => (key !== "request_key" && /token|password|cookie|secret|authorization|api[_-]?key/i.test(key)) || hasCredentialField(child));
}


export function createOperationalVerifier(userId: string, onSessionEnd: () => void, lifecycle: AbortController) {
    let running = false;
    const request = async (path: string, body?: Row, headers?: Record<string, string>) => {
      if (lifecycle.signal.aborted) throw Error("검증 세션이 종료되었습니다.");
      const response = await fetch(path, {
        method: body ? "POST" : "GET", credentials: "same-origin", cache: "no-store",
        signal: AbortSignal.any([lifecycle.signal, AbortSignal.timeout(15000)]),
        headers: { ...(body ? { "Content-Type": "application/json" } : {}), ...headers },
        ...(body ? { body: JSON.stringify(body) } : {}),
      });
      if (response.status === 401) { lifecycle.abort(); onSessionEnd(); throw Error("로그인 세션이 종료되어 검증을 중단했습니다."); }
      const raw: unknown = await response.json().catch(() => null);
      if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw Error("검증 응답을 확인하지 못했습니다. 빈 자료로 판정하지 않습니다.");
      const value = raw as Snapshot;
      if (lifecycle.signal.aborted) throw Error("검증 세션이 종료되었습니다.");
      return { status: response.status, value };
    };
    const getEntity = (entity: string, id: string) => request(`/api/pds?entity=${entity}&id=${encodeURIComponent(id)}`);
    const today = () => new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Seoul" }).format(new Date());
    const planFields = () => ({ title: fixtureTitle, start_date: today(), end_date: today(), priority: 2, success: "접근차단검증", estimated_minutes: 0, starter_tasks: false });
    const taskFields = () => ({ title: taskTitle, due_date: today(), priority: 2, estimated_minutes: 0, tags: "운영검증" });
    const tool = {
      name: "verify_diary_operations", title: "운영 검증",
      description: "로그인한 본인 자료를 안전 집계하거나 실사용이 아닌 검증 계획·할 일을 준비하고, 먼저 404가 확인된 타인 ID의 접근 거절을 검증합니다. 실제 실행·완료·5일 기록은 생성하지 않습니다.",
      inputSchema: { type: "object", properties: { mode: { type: "string", enum: ["read", "fixture", "foreign"] }, plan_id: { type: "string" }, task_id: { type: "string" }, owner_id: { type: "string", description: "상대 탭의 read 결과 verified_user_id. foreign 검증에 필수." } }, required: ["mode"], additionalProperties: false },
      annotations: { readOnlyHint: false, destructiveHint: true, untrustedContentHint: true },
      async execute(raw: unknown) {
        if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw Error("검증 입력을 확인하세요.");
        const input = raw as OperationalVerificationInput;
        if (!Object.keys(input).every(key => ["mode", "plan_id", "task_id", "owner_id"].includes(key)) || !["read", "fixture", "foreign"].includes(input.mode)) throw Error("검증 종류를 확인하세요.");
        for (const id of [input.plan_id, input.task_id, input.owner_id]) if (id !== undefined && (typeof id !== "string" || !/^[A-Za-z0-9_-]{1,100}$/.test(id))) throw Error("검증 ID를 확인하세요.");
        if (running) throw Error("진행 중인 검증이 끝난 뒤 다시 요청하세요.");
        running = true;
        try {
          const session = await request("/api/auth");
          if (session.status !== 200) throw Error("서버의 로그인 상태를 확인하지 못했습니다.");
          const user = session.value.user;
          if (!user || typeof user !== "object" || !("id" in user) || user.id !== userId) {
            lifecycle.abort(); onSessionEnd(); throw Error("로그인 계정이 바뀌어 검증을 중단했습니다.");
          }
          if (input.mode === "read") {
            const pds = await request("/api/pds");
            const exported = await request("/api/account");
            if (pds.status !== 200 || exported.status !== 200) return { pds_status: pds.status, export_status: exported.status, summaries_unavailable: true };
            if (!completeSnapshot(pds.value) || !completeSnapshot(exported.value)) throw Error("필수 자료 목록이 빠져 있어 검증을 중단했습니다.");
            const planId = input.plan_id || rows(pds.value, "plans")[0]?.id;
            const taskId = input.task_id || rows(pds.value, "tasks")[0]?.id;
            const digest = await snapshotDigest(pds.value), exportedDigest = await snapshotDigest(exported.value);
            return { verified_user_id: userId, pds_status: pds.status, export_status: exported.status, counts: counts(pds.value), export_counts: counts(exported.value), export_additional_counts: Object.fromEntries(exportLists.map(key => [key, Array.isArray(exported.value[key]) ? rows(exported.value, key).length : null])), export_profile_present: !!exported.value.profile, export_required_sections_present: exportLists.every(key => Array.isArray(exported.value[key])) && Object.hasOwn(exported.value, "profile") && Object.hasOwn(exported.value, "account"), pds_content_digest: digest, export_pds_content_matches: digest === exportedDigest, credential_fields_present: hasCredentialField(pds.value) || hasCredentialField(exported.value), own_plan_status: typeof planId === "string" ? (await getEntity("plans", planId)).status : null, own_task_status: typeof taskId === "string" ? (await getEntity("tasks", taskId)).status : null };
          }
          if (input.mode === "fixture") {
            let snapshot = await request("/api/pds");
            if (snapshot.status !== 200 || !completeSnapshot(snapshot.value)) throw Error("본인 목록을 확인하지 못해 검증 자료 생성을 중단했습니다.");
            let plan = rows(snapshot.value, "plans").find(row => row.title === fixtureTitle);
            if (!plan) {
              const created = await request("/api/pds", { action: "plan", ...planFields() });
              if (created.status !== 200) return { plan_create_status: created.status };
              snapshot = await request("/api/pds");
              plan = rows(snapshot.value, "plans").find(row => row.id === created.value.id && row.title === fixtureTitle);
            }
            if (typeof plan?.id !== "string") throw Error("검증용 계획을 확인하지 못했습니다.");
            let task = rows(snapshot.value, "tasks").find(row => row.plan_id === plan.id && row.title === taskTitle && !row.deleted_at);
            if (!task) {
              const created = await request("/api/pds", { action: "task", plan_id: plan.id, ...taskFields() });
              if (created.status !== 200) return { task_create_status: created.status, plan_id: plan.id };
              snapshot = await request("/api/pds");
              task = rows(snapshot.value, "tasks").find(row => row.plan_id === plan.id && row.title === taskTitle && !row.deleted_at);
            }
            if (typeof task?.id !== "string") throw Error("검증용 할 일을 확인하지 못했습니다.");
            return { plan_id: plan.id, task_id: task.id, own_plan_status: (await getEntity("plans", plan.id)).status, own_task_status: (await getEntity("tasks", task.id)).status, real_use_records_created: false };
          }
          if (!input.plan_id || !input.task_id || !input.owner_id) throw Error("타인 검증에는 상대 계정·계획·할 일 ID가 모두 필요합니다.");
          if (input.owner_id === userId) throw Error("본인 계정 ID로 타인 검증을 진행할 수 없습니다.");
          const planRead = await getEntity("plans", input.plan_id);
          const taskRead = await getEntity("tasks", input.task_id);
          if (planRead.status !== 404 || taskRead.status !== 404) return { foreign_plan_read: planRead.status, foreign_task_read: taskRead.status, mutations_skipped: true };
          const forgedOwner = input.owner_id;
          const baseline = await request("/api/pds");
          if (baseline.status !== 200 || !completeSnapshot(baseline.value)) throw Error("변경 전 목록을 확인하지 못해 검증을 중단했습니다.");
          const beforeDigest = await snapshotDigest(baseline.value);
          const statuses: Record<string, number | boolean> = { foreign_plan_read: planRead.status, foreign_task_read: taskRead.status };
          const attempts: [string, Row][] = [
            ["foreign_plan_update", { action: "plan", id: input.plan_id, version: 1, ...planFields(), owner_id: forgedOwner, user_id: forgedOwner }],
            ["foreign_task_priority", { action: "priority", id: input.task_id, priority: 3 }],
            ["foreign_task_delete", { action: "delete", id: input.task_id }],
            ["foreign_task_update", { action: "task", id: input.task_id, plan_id: input.plan_id, ...taskFields(), owner_id: forgedOwner, user_id: forgedOwner }],
          ];
          for (const [key, body] of attempts) {
            const { status } = await request("/api/pds", body);
            statuses[key] = status;
            if (![403, 404].includes(status)) return { ...statuses, further_mutations_skipped: true };
          }
          const spoofedURL = await request(`/api/pds?owner_id=${encodeURIComponent(forgedOwner)}&user_id=${encodeURIComponent(forgedOwner)}`);
          const spoofedHeader = await request("/api/pds", undefined, { "X-User-Id": forgedOwner, "X-Owner-Id": forgedOwner });
          const after = await request("/api/pds");
          statuses.forged_owner_url_get = spoofedURL.status;
          statuses.forged_owner_header_get = spoofedHeader.status;
          statuses.forged_owner_url_lists_unchanged = spoofedURL.status === 200 && completeSnapshot(spoofedURL.value) && await snapshotDigest(spoofedURL.value) === beforeDigest;
          statuses.forged_owner_header_lists_unchanged = spoofedHeader.status === 200 && completeSnapshot(spoofedHeader.value) && await snapshotDigest(spoofedHeader.value) === beforeDigest;
          statuses.own_lists_unchanged = after.status === 200 && completeSnapshot(after.value) && await snapshotDigest(after.value) === beforeDigest;
          return statuses;
        } finally { running = false; }
      },
    };
  return tool;
}
