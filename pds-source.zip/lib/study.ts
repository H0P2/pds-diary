export const studyQuestion = '작업 시작 규칙을 한 가지 바꾸면 하루 실제 집중 작업 시간(분)이 늘어나는가?';
export const studyRules = {
 metric:'하루 실제 집중 작업 시간',unit:'분',calculation:'그날 실제 집중 작업 구간을 초 단위로 합산한 뒤 60으로 나눈 분. 휴식·중복 구간 제외. 평균은 기록된 날 합계 ÷ 기록된 날짜 수.',
 missing:'미기록 날짜는 0으로 대체하지 않고 제외. 5개 서로 다른 실제 서울 날짜가 있어야 완료. 연속 날짜일 필요는 없음.',
 duplicate:'서울 날짜당 1건, 작업 구간은 중복 없이 입력. 저장한 기록 수정·삭제·과거 날짜 입력 불가.',
 outlier:'0~1440분만 허용, 초 단위 정밀도. 720분 초과는 이상값 표기하되 원래 합계에 포함하며 삭제·보정하지 않음.',
 rounding:'합계·평균·전후 차이는 원래 초 합계로 계산 후 분 단위 소수 둘째 자리 반올림.',weekStart:'월요일',timezone:'Asia/Seoul',
} as const;
export type StudyDay={id:string;protocol_id:string;day_number:number;seoul_date:string;sessions_json:string;total_minutes:number;note:string;created_at:string};
export type StudyProtocol={id:string;user_id:string;question:string;rules_json:string;baseline_rule:string;changed_rule:string|null;change_reason:string|null;change_refs:string|null;changed_at:string|null;created_at:string;manual_check_json:string|null;manual_checked_at:string|null};
export function seoulDate(now:number){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(now));}
export function roundMinutes(value:number){return Math.round((value+Number.EPSILON)*100)/100;}
export function studySummary(days:StudyDay[]){
 const group=(items:StudyDay[])=>{const seconds=items.reduce((sum,item)=>sum+Math.round(item.total_minutes*60),0),total=seconds/60;return {count:items.length,total:roundMinutes(total),seconds,mean:items.length?roundMinutes(total/items.length):null,formula:items.length?`${seconds}초 ÷ 60 ÷ ${items.length}`:'기록 없음'};};
 const before=group(days.filter(day=>day.day_number<=2)),after=group(days.filter(day=>day.day_number>=3)),all=group(days);
 return {before,after,all,complete:days.length===5,difference:before.count===2&&after.count===3?roundMinutes(after.seconds/60/3-before.seconds/60/2):null,outliers:days.filter(day=>day.total_minutes>720).map(day=>day.id)};
}
export function sessionMinutes(value:unknown):number[]{
 if(!Array.isArray(value)||value.length>100||value.length<1||value.some(item=>typeof item!=='number'||!Number.isFinite(item)||Math.abs(item*60-Math.round(item*60))>0.000001||item<0||item>1440))throw Error('작업 구간은 0~1440분이며 초 단위까지 입력해 주세요.');
 if(value.reduce((sum,item)=>sum+Math.round(item*60),0)>86400)throw Error('하루 합계는 1440분을 넘을 수 없습니다.');
 return value;
}
