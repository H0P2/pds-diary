import {sql} from 'drizzle-orm';
import {sqliteTable,text,index,check} from 'drizzle-orm/sqlite-core';
import {diaryAccounts} from './schema';
export const communityPosts=sqliteTable('community_posts',{
 id:text('id').primaryKey().notNull(),authorId:text('author_id').notNull().references(()=>diaryAccounts.id,{onDelete:'cascade'}),title:text('title').notNull(),body:text('body').notNull(),planSnapshot:text('plan_snapshot'),createdAt:text('created_at').notNull(),deletedAt:text('deleted_at')
},t=>[index('community_posts_feed').on(t.deletedAt,t.createdAt,t.id),index('community_posts_author').on(t.authorId),check('community_post_title',sql`length(${t.title}) BETWEEN 1 AND 200`),check('community_post_body',sql`length(${t.body})<=3000`)]);
export const communityComments=sqliteTable('community_comments',{
 id:text('id').primaryKey().notNull(),postId:text('post_id').notNull().references(()=>communityPosts.id,{onDelete:'cascade'}),authorId:text('author_id').notNull().references(()=>diaryAccounts.id,{onDelete:'cascade'}),body:text('body').notNull(),createdAt:text('created_at').notNull(),deletedAt:text('deleted_at')
},t=>[index('community_comments_thread').on(t.postId,t.deletedAt,t.createdAt,t.id),index('community_comments_author').on(t.authorId),check('community_comment_body',sql`length(${t.body}) BETWEEN 1 AND 1000`)]);
