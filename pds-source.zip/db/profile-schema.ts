import {sql} from 'drizzle-orm';
import {sqliteTable,text,check} from 'drizzle-orm/sqlite-core';
import {diaryAccounts} from './schema';
export const diaryProfiles=sqliteTable('diary_profiles',{
 userId:text('user_id').primaryKey().references(()=>diaryAccounts.id,{onDelete:'cascade'}),
 username:text('username').notNull().unique(),
 displayName:text('display_name').notNull(),
 bio:text('bio').notNull().default(''),
},table=>[
 check('profile_username_format',sql`length(${table.username}) BETWEEN 3 AND 20 AND ${table.username}=lower(${table.username}) AND ${table.username} NOT GLOB '*[^a-z0-9_]*'`),
 check('profile_name_length',sql`length(${table.displayName}) BETWEEN 1 AND 30`),
 check('profile_bio_length',sql`length(${table.bio})<=200`),
]);
