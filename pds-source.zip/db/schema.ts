import { sql } from "drizzle-orm";
import { sqliteTable, text, integer, uniqueIndex, index, primaryKey, check } from "drizzle-orm/sqlite-core";
export const diaryAccounts=sqliteTable("diary_accounts",{
 id:text("id").primaryKey().notNull(),email:text("email"),role:text("role").notNull().default("member"),authVersion:integer("auth_version").notNull().default(1),createdAt:integer("created_at").notNull(),deletedAt:integer("deleted_at")
},t=>[check("diary_accounts_role",sql`${t.role} IN ('member','admin')`)]);
export const diarySessions=sqliteTable("diary_sessions",{
 tokenHash:text("token_hash").primaryKey().notNull(),userId:text("user_id").notNull().references(()=>diaryAccounts.id),authVersion:integer("auth_version").notNull(),createdAt:integer("created_at").notNull(),expiresAt:integer("expires_at").notNull(),revokedAt:integer("revoked_at")
},t=>[index("diary_sessions_user").on(t.userId)]);
export const diaryAudit=sqliteTable("diary_audit",{
 id:text("id").primaryKey().notNull(),accountId:text("account_id"),email:text("email"),event:text("event").notNull(),success:integer("success").notNull(),createdAt:integer("created_at").notNull()
},t=>[index("diary_audit_time").on(t.createdAt),check("diary_audit_success",sql`${t.success} IN (0,1)`)]);
export const authRateLimits=sqliteTable("auth_rate_limits",{
 keyHash:text("key_hash").notNull(),windowStart:integer("window_start").notNull(),attempts:integer("attempts").notNull().default(1)
},t=>[primaryKey({columns:[t.keyHash,t.windowStart]})]);
export const plans = sqliteTable("plans", {
 id:text("id").primaryKey(), ownerId:text("owner_id").references(()=>diaryAccounts.id), title:text("title").notNull(), startDate:text("start_date").notNull(), endDate:text("end_date").notNull(), priority:integer("priority").notNull(), success:text("success").notNull(), estimatedMinutes:integer("estimated_minutes").notNull(), improvement:text("improvement").notNull().default(""), sourceReviewId:text("source_review_id"), version:integer("version").notNull().default(1), createdAt:text("created_at").notNull()
},t=>[index("plans_owner").on(t.ownerId)]);
export const planVersions = sqliteTable("plan_versions",{id:text("id").primaryKey(),planId:text("plan_id").notNull().references(()=>plans.id),version:integer("version").notNull(),snapshot:text("snapshot").notNull(),createdAt:text("created_at").notNull()},t=>[uniqueIndex("plan_version_unique").on(t.planId,t.version)]);
export const tasks = sqliteTable("tasks",{id:text("id").primaryKey(),planId:text("plan_id").notNull().references(()=>plans.id),title:text("title").notNull(),dueDate:text("due_date").notNull(),priority:integer("priority").notNull(),tags:text("tags").notNull(),estimatedMinutes:integer("estimated_minutes").notNull(),status:text("status").notNull().default("todo"),generation:integer("generation").notNull().default(0),deletedAt:text("deleted_at"),createdAt:text("created_at").notNull()},t=>[index("tasks_plan").on(t.planId)]);
export const executions = sqliteTable("executions",{id:text("id").primaryKey(),taskId:text("task_id").notNull().references(()=>tasks.id),startedAt:text("started_at").notNull(),endedAt:text("ended_at").notNull(),actualMinutes:integer("actual_minutes").notNull(),blockedReason:text("blocked_reason").notNull(),requestKey:text("request_key").notNull().unique(),createdAt:text("created_at").notNull()},t=>[index("executions_task").on(t.taskId)]);
export const completionEvents = sqliteTable("completion_events",{id:text("id").primaryKey(),taskId:text("task_id").notNull().references(()=>tasks.id),generation:integer("generation").notNull(),createdAt:text("created_at").notNull()},t=>[uniqueIndex("completion_task_generation").on(t.taskId,t.generation)]);
export const reviews=sqliteTable("reviews",{id:text("id").primaryKey(),planId:text("plan_id").notNull().references(()=>plans.id),fromDate:text("from_date").notNull(),toDate:text("to_date").notNull(),improvement:text("improvement").notNull(),metrics:text("metrics").notNull(),createdAt:text("created_at").notNull()},t=>[index("reviews_plan").on(t.planId)]);

export const feedback=sqliteTable("feedback",{
 id:text("id").primaryKey(),userId:text("user_id").notNull().references(()=>diaryAccounts.id,{onDelete:"cascade"}),category:text("category").notNull(),screen:text("screen").notNull(),problem:text("problem").notNull(),suggestion:text("suggestion").notNull().default(""),status:text("status").notNull().default("received"),priority:text("priority").notNull(),groupKey:text("group_key").notNull(),reason:text("reason").notNull().default(""),createdAt:text("created_at").notNull(),updatedAt:text("updated_at").notNull(),deletedAt:text("deleted_at")
},t=>[index("feedback_owner").on(t.userId,t.createdAt),index("feedback_groups").on(t.groupKey,t.deletedAt),check("feedback_category",sql`${t.category} IN ('design','ux','feature','bug')`),check("feedback_screen",sql`length(${t.screen}) BETWEEN 1 AND 100`),check("feedback_problem",sql`length(${t.problem}) BETWEEN 1 AND 2000`),check("feedback_suggestion",sql`length(${t.suggestion})<=2000`),check("feedback_status",sql`${t.status} IN ('received','reviewing','proposed','applied','deferred')`),check("feedback_priority",sql`${t.priority} IN ('urgent','high','normal','low')`)]);
export const feedbackEvents=sqliteTable("feedback_events",{
 id:text("id").primaryKey(),feedbackId:text("feedback_id").notNull().references(()=>feedback.id,{onDelete:"cascade"}),actorId:text("actor_id").notNull().references(()=>diaryAccounts.id,{onDelete:"cascade"}),action:text("action").notNull(),reason:text("reason").notNull().default(""),createdAt:text("created_at").notNull()
});

export const uiPreferences=sqliteTable("ui_preferences",{
 userId:text("user_id").primaryKey().references(()=>diaryAccounts.id,{onDelete:"cascade"}),preferences:text("preferences").notNull().default("{}"),automatic:integer("automatic").notNull().default(1),version:integer("version").notNull().default(1),updatedAt:text("updated_at").notNull()
},t=>[check("ui_preferences_automatic",sql`${t.automatic} IN (0,1)`)]);
export const uiChanges=sqliteTable("ui_changes",{
 id:text("id").primaryKey(),userId:text("user_id").notNull().references(()=>diaryAccounts.id,{onDelete:"cascade"}),feedbackId:text("feedback_id"),beforeJson:text("before_json").notNull(),afterJson:text("after_json").notNull(),createdAt:text("created_at").notNull()
},t=>[index("ui_changes_owner").on(t.userId,t.createdAt)]);

export * from './study-schema';

export * from './profile-schema';
export * from './community-schema';
