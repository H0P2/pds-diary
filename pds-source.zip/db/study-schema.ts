import { sql } from 'drizzle-orm';
import { sqliteTable, text, integer, real, uniqueIndex, check } from 'drizzle-orm/sqlite-core';
import { diaryAccounts } from './schema';
export const studyProtocols = sqliteTable('study_protocols', {
 id:text('id').primaryKey().notNull(),userId:text('user_id').notNull().references(()=>diaryAccounts.id,{onDelete:'cascade'}),question:text('question').notNull(),rulesJson:text('rules_json').notNull(),baselineRule:text('baseline_rule').notNull(),changedRule:text('changed_rule'),changeReason:text('change_reason'),changeRefs:text('change_refs'),changedAt:text('changed_at'),createdAt:text('created_at').notNull(),manualCheckJson:text('manual_check_json'),manualCheckedAt:text('manual_checked_at')
},t=>[uniqueIndex('study_owner_unique').on(t.userId)]);
export const studyDays = sqliteTable('study_days', {
 id:text('id').primaryKey().notNull(),protocolId:text('protocol_id').notNull().references(()=>studyProtocols.id,{onDelete:'cascade'}),dayNumber:integer('day_number').notNull(),seoulDate:text('seoul_date').notNull(),sessionsJson:text('sessions_json').notNull(),totalMinutes:real('total_minutes').notNull(),note:text('note').notNull().default(''),createdAt:text('created_at').notNull()
},t=>[uniqueIndex('study_day_number_unique').on(t.protocolId,t.dayNumber),uniqueIndex('study_date_unique').on(t.protocolId,t.seoulDate),check('study_five_days',sql`${t.dayNumber} BETWEEN 1 AND 5`),check('study_day_minutes',sql`${t.totalMinutes} BETWEEN 0 AND 1440`)]);
