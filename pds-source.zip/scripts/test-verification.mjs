import ts from 'typescript';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';

// Real route/session code, in-memory synthetic DB only. No operating account or network.
const root=path.resolve(import.meta.dirname,'..'),sqlite=new DatabaseSync(':memory:');
for(const name of fs.readdirSync(path.join(root,'drizzle')).filter(name=>/^0.*\.sql$/.test(name)).sort())sqlite.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));
function statement(sql,params=[]){const item=sqlite.prepare(sql);return {bind:(...args)=>statement(sql,args),first:async()=>item.get(...params)||null,all:async()=>item.columns().length?{results:item.all(...params)}:{results:[],meta:{changes:Number(item.run(...params).changes)}},run:async()=>({meta:{changes:Number(item.run(...params).changes)}})};}
const db={prepare:statement,batch:async statements=>{sqlite.exec('BEGIN');try{const result=[];for(const item of statements)result.push(await item.all());sqlite.exec('COMMIT');return result;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
globalThis.verificationTestDatabase=db;
const urls=new Map();
function moduleURL(filename){filename=path.resolve(filename);if(urls.has(filename))return urls.get(filename);let source=fs.readFileSync(filename,'utf8').replace(/import\s*\{\s*database\s*\}\s*from\s*["']@\/db\/raw["'];?/g,'const database=()=>globalThis.verificationTestDatabase;');source=source.replace(/(from\s*["'])(@\/[^"']+|\.[^"']+)(["'])/g,(_all,before,spec,after)=>{let target=spec.startsWith('@/')?path.join(root,spec.slice(2)):path.resolve(path.dirname(filename),spec);if(!path.extname(target))target+='.ts';return before+moduleURL(target)+after;});const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;const url='data:text/javascript;base64,'+Buffer.from(compiled).toString('base64');urls.set(filename,url);return url;}
const auth=await import(moduleURL(path.join(root,'lib/auth.ts'))),pds=await import(moduleURL(path.join(root,'app/api/pds/route.ts'))),verification=await import(moduleURL(path.join(root,'app/api/verification/route.ts')));
const user={id:'verification-synthetic-only',email:'verification@example.test',email_confirmed_at:'synthetic'};
sqlite.prepare('INSERT INTO diary_accounts(id,email,created_at) VALUES(?,?,?)').run(user.id,user.email,Date.now());
const session=await auth.issueSession(db,user),cookie=session.cookie.split(';')[0],url='https://diary.example.test/api/verification';
const body=JSON.stringify({action:'logout_check'});
const response=await verification.POST(new Request(url,{method:'POST',headers:{cookie,origin:'https://diary.example.test','content-type':'application/json'},body}));
assert.equal(response.status,200);const value=await response.json();assert.equal(value.before_status,200);assert.equal(value.after_status,401);assert.equal(value.same_request,true);assert.equal(value.scope,'server-internal same-request session check');assert.equal(value.url,'https://diary.example.test/api/pds');assert.equal(value.method,'GET');assert.ok(Number.isFinite(Date.parse(value.checked_at)));assert.match(response.headers.get('set-cookie'),/Max-Age=0/);assert.equal(JSON.stringify(value).includes(cookie),false);
assert.equal((await pds.GET(new Request(value.url,{headers:{cookie}}))).status,401);assert.equal(sqlite.prepare('SELECT COUNT(*) count FROM plans').get().count,0);assert.equal(sqlite.prepare('SELECT COUNT(*) count FROM study_days').get().count,0);
console.log('PASS: Local synthetic DB, real handlers: identical server-side GET succeeds before session revocation and returns 401 afterward; no credential in result, no PDS/study rows created. Not operating evidence.');
sqlite.close();delete globalThis.verificationTestDatabase;
