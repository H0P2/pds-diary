import ts from 'typescript';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
const root=path.resolve(import.meta.dirname,'..'),sqlite=new DatabaseSync(':memory:');
sqlite.exec('PRAGMA foreign_keys=ON');
for(const name of fs.readdirSync(path.join(root,'drizzle')).filter(n=>/^0.*\.sql$/.test(n)).sort())sqlite.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));
let resolutions=0;
function statement(sql,params=[]){const s=sqlite.prepare(sql);return {bind:(...args)=>statement(sql,args),first:async()=>s.get(...params)||null,all:async()=>s.columns().length?{results:s.all(...params)}:{results:[],meta:{changes:Number(s.run(...params).changes)}},run:async()=>({meta:{changes:Number(s.run(...params).changes)}})};}
const db={prepare:sql=>{if(sql.startsWith('SELECT a.email FROM diary_profiles'))resolutions++;return statement(sql);},batch:async statements=>{sqlite.exec('BEGIN');try{const out=[];for(const s of statements)out.push(await s.all());sqlite.exec('COMMIT');return out;}catch(e){sqlite.exec('ROLLBACK');throw e;}}};
globalThis.profileTestDatabase=db;
const urls=new Map();
function moduleURL(filename){filename=path.resolve(filename);if(urls.has(filename))return urls.get(filename);let source=fs.readFileSync(filename,'utf8');
 source=source.replace(/import\s*\{\s*database\s*\}\s*from\s*['"]@\/db\/raw['"];?/g,'const database=()=>globalThis.profileTestDatabase;');
 source=source.replace(/import\s*\{\s*provider,\s*ownerEmail\s*\}\s*from\s*['"]@\/lib\/supabase['"];?/g,'const provider=()=>globalThis.profileTestProvider;const ownerEmail=()=>"owner@example.test";');
 source=source.replace(/import\s*\{\s*ownerEmail\s*\}\s*from\s*['"]@\/lib\/supabase['"];?/g,'const ownerEmail=()=>"owner@example.test";');
 source=source.replace(/(from\s*['"])(@\/[^'"]+|\.[^'"]+)(['"])/g,(_m,before,spec,after)=>{let target=spec.startsWith('@/')?path.join(root,spec.slice(2)):path.resolve(path.dirname(filename),spec);if(!path.extname(target))target+='.ts';return before+moduleURL(target)+after;});
 const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;const url='data:text/javascript;base64,'+Buffer.from(compiled).toString('base64');urls.set(filename,url);return url;
}
const auth=await import(moduleURL(path.join(root,'lib/auth.ts'))),profile=await import(moduleURL(path.join(root,'app/api/profile/route.ts'))),login=await import(moduleURL(path.join(root,'app/api/auth/route.ts')));
const users=[{id:'profile-user-a',email:'a@example.test',email_confirmed_at:'fixture'},{id:'profile-user-b',email:'b@example.test',email_confirmed_at:'fixture'}];
for(const u of users)sqlite.prepare('INSERT INTO diary_accounts(id,email,created_at) VALUES(?,?,?)').run(u.id,u.email,Date.now());
const sessions=await Promise.all(users.map(u=>auth.issueSession(db,u))),cookies=sessions.map(s=>s.cookie.split(';')[0]);
function req(cookie='',body,url='https://diary.example.test/api/profile',extra={}){return new Request(url,{method:body?'POST':'GET',headers:{cookie,origin:'https://diary.example.test','content-type':'application/json',...extra},...(body?{body:JSON.stringify(body)}:{})});}
const read=async cookie=>{const r=await profile.GET(req(cookie));return {status:r.status,data:await r.json()};};
const save=async(cookie,body)=>{const r=await profile.POST(req(cookie,body));return {status:r.status,data:await r.json()};};
const checks=[];async function check(label,fn){await fn();checks.push(label);console.log('PASS:',label);}
await check('Profile requires authentication and same-origin mutation; defaults are private',async()=>{
 assert.equal((await read()).status,401);assert.equal((await save('',{username:'anonymous',display_name:'Anon',bio:''})).status,401);
 assert.equal((await profile.POST(req(cookies[0],{username:'alice',display_name:'A',bio:''},undefined,{origin:'https://evil.example.test'}))).status,403);
 assert.deepEqual((await read(cookies[0])).data.profile,{user_id:users[0].id,username:null,display_name:'',bio:''});
});
await check('Profile ownership comes only from the session; fields and Unicode lengths are validated',async()=>{
 const good={username:'Alice_01',display_name:'첫 사용자',bio:'안녕하세요',user_id:users[1].id,role:'admin'};
 const r=await save(cookies[0],good);assert.equal(r.status,200);assert.equal(r.data.profile.user_id,users[0].id);assert.equal(r.data.profile.username,'alice_01');
 assert.equal((await read(cookies[1])).data.profile.username,null);assert.equal(sqlite.prepare('SELECT role FROM diary_accounts WHERE id=?').get(users[0].id).role,'member');
 for(const body of [{...good,username:'ab'},{...good,username:'bad-id'},{...good,display_name:' '},{...good,display_name:'가'.repeat(31)},{...good,bio:'🙂'.repeat(201)}])assert.equal((await save(cookies[0],body)).status,400);
 assert.equal((await save(cookies[0],{username:'alice_01',display_name:'🙂'.repeat(30),bio:'🙂'.repeat(200)})).status,200);
});
await check('Duplicate usernames and concurrent reservations return409 without changing either owner',async()=>{
 assert.equal((await save(cookies[1],{username:'ALICE_01',display_name:'B',bio:''})).status,409);
 const results=await Promise.all(cookies.map((cookie,i)=>save(cookie,{username:'shared_id',display_name:String(i),bio:''})));
 assert.deepEqual(results.map(r=>r.status).sort(),[200,409]);assert.equal(sqlite.prepare('SELECT count(*) n FROM diary_profiles WHERE username=?').get('shared_id').n,1);
 await save(cookies[0],{username:'alice_01',display_name:'A',bio:''});await save(cookies[1],{username:'bob_02',display_name:'B',bio:''});
});
let providerEmail='',wrong=false,confirmed=true,cleanupThrow=false;
globalThis.profileTestProvider={auth:{signInWithPassword:async({email,password})=>{providerEmail=email;assert.equal(password,'Synthetic-only-password');return wrong?{error:{message:'private provider detail'},data:{session:null}}:{error:null,data:{session:{access_token:'synthetic-only-token'}}};},getUser:async()=>({error:null,data:{user:{...users[0],email_confirmed_at:confirmed?'fixture':null}}}),signOut:async()=>{if(cleanupThrow)throw Error('Synthetic cleanup failure');return {error:null};}}};
const attempt=async(identifier,extra={})=>{const r=await login.POST(req('',{action:'login',identifier,password:'Synthetic-only-password'},'https://diary.example.test/api/auth',extra));return {status:r.status,data:await r.json(),cookie:r.headers.get('set-cookie')};};
await check('ID login resolves privately then verifies Supabase password and confirmed user; email still works',async()=>{
 let result=await attempt('ALICE_01');assert.equal(result.status,200);assert.equal(providerEmail,users[0].email);assert.equal(result.data.user.username,'alice_01');assert.equal(result.data.user.display_name,'A');assert.ok(result.cookie.includes('HttpOnly'));
 result=await attempt(users[0].email);assert.equal(result.status,200);assert.equal(providerEmail,users[0].email);
 const signedCookie=result.cookie.split(';')[0];const status=await login.GET(req(signedCookie,undefined,'https://diary.example.test/api/auth'));assert.equal((await status.json()).user.username,'alice_01');
 confirmed=false;assert.equal((await attempt('alice_01')).status,401);confirmed=true;
 wrong=true;const bad=await attempt('alice_01');wrong=false;const missing=await attempt('not_registered');assert.equal(missing.status,401);assert.deepEqual(missing.data,bad.data);assert.ok(!JSON.stringify(missing.data).includes(users[0].email));
 assert.ok(!JSON.stringify(result.data).includes('synthetic-only-token'));
});
await check('Unknown IDs are rate limited before profile resolution; passwords never enter audit logs',async()=>{
 for(let n=0;n<20;n++)assert.equal((await attempt('rate_unknown',{ 'cf-connecting-ip':'rate-fixture'})).status,401);
 const before=resolutions;assert.equal((await attempt('rate_unknown',{'cf-connecting-ip':'rate-fixture'})).status,429);assert.equal(resolutions,before);
 assert.ok(!JSON.stringify(sqlite.prepare('SELECT * FROM diary_audit').all()).includes('Synthetic-only-password'));
});
await check('Verified ID login remains successful when provider cleanup throws',async()=>{
 cleanupThrow=true;const result=await attempt('alice_01',{'cf-connecting-ip':'cleanup-fixture'});cleanupThrow=false;
 assert.equal(result.status,200);assert.equal(result.data.user.id,users[0].id);assert.ok(await auth.authenticate(db,req(result.cookie.split(';')[0])));
});
await check('Changing an ID removes old login mapping; deleted accounts cannot use their ID',async()=>{
 await save(cookies[0],{username:'alice_new',display_name:'A',bio:''});assert.equal((await attempt('alice_01',{'cf-connecting-ip':'rename-fixture'})).status,401);
 assert.equal((await attempt('alice_new',{'cf-connecting-ip':'rename-fixture'})).status,200);
 sqlite.prepare('UPDATE diary_accounts SET deleted_at=? WHERE id=?').run(Date.now(),users[0].id);assert.equal((await attempt('alice_new',{'cf-connecting-ip':'delete-fixture'})).status,401);assert.equal((await read(cookies[0])).status,401);
});
await check('Configured owner promotes an existing member and claims only legacy unowned plans; non-owner stays member',async()=>{
 const owner={id:'configured-owner-fixture',email:'owner@example.test',email_confirmed_at:'fixture'};
 sqlite.prepare("INSERT INTO diary_accounts(id,email,role,created_at) VALUES(?,?,'member',?)").run(owner.id,owner.email,Date.now());
 const plan=sqlite.prepare('INSERT INTO plans(id,owner_id,title,start_date,end_date,priority,success,estimated_minutes,created_at) VALUES(?,?,?,?,?,?,?,?,?)');
 plan.run('legacy-owner-fixture',null,'Synthetic legacy','2026-10-10','2026-10-10',2,'Synthetic',1,'fixture');
 plan.run('other-owner-fixture',users[1].id,'Synthetic other','2026-10-10','2026-10-10',2,'Synthetic',1,'fixture');
 let verified=users[1];
 globalThis.profileTestProvider={auth:{signInWithPassword:async()=>({error:null,data:{session:{access_token:'synthetic-owner-only-token'}}}),getUser:async()=>({error:null,data:{user:verified}}),signOut:async()=>({error:null})}};
 const nonOwner=await login.POST(req('',{action:'login',email:users[1].email,password:'Synthetic-only-password',role:'admin',owner_id:owner.id},'https://diary.example.test/api/auth',{'cf-connecting-ip':'non-owner-fixture'}));
 assert.equal(nonOwner.status,200);assert.equal((await nonOwner.json()).user.role,'member');assert.equal(sqlite.prepare('SELECT owner_id FROM plans WHERE id=?').get('legacy-owner-fixture').owner_id,null);
 verified=owner;
 const promoted=await login.POST(req('',{action:'login',email:owner.email,password:'Synthetic-only-password'},'https://diary.example.test/api/auth',{'cf-connecting-ip':'configured-owner-fixture'}));
 assert.equal(promoted.status,200);assert.equal((await promoted.json()).user.role,'admin');assert.equal(sqlite.prepare('SELECT role FROM diary_accounts WHERE id=?').get(owner.id).role,'admin');
 assert.equal(sqlite.prepare('SELECT owner_id FROM plans WHERE id=?').get('legacy-owner-fixture').owner_id,owner.id);assert.equal(sqlite.prepare('SELECT owner_id FROM plans WHERE id=?').get('other-owner-fixture').owner_id,users[1].id);
});
console.log(`PASS: ${checks.length} profile/ID-login checks; synthetic data, provider mocked, no network.`);
sqlite.close();delete globalThis.profileTestDatabase;delete globalThis.profileTestProvider;
