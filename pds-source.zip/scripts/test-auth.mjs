import ts from 'typescript';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';

// Executes the real protected route with only its D1 binding replaced. No network or user data.
const root=path.resolve(import.meta.dirname,'..');
const sqlite=new DatabaseSync(':memory:');
const migrations=fs.readdirSync(path.join(root,'drizzle')).filter(name=>/^0.*\.sql$/.test(name)).sort();
for(const name of migrations)sqlite.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));
function statement(sql,params=[]) {
 const s=sqlite.prepare(sql);
 return {bind:(...args)=>statement(sql,args),first:async()=>s.get(...params)||null,
 all:async()=>s.columns().length?{results:s.all(...params)}:{results:[],meta:{changes:Number(s.run(...params).changes)}},run:async()=>({meta:{changes:Number(s.run(...params).changes)}})};
}
const db={prepare:statement,batch:async statements=>{
 sqlite.exec('BEGIN');try{const results=[];for(const s of statements)results.push(await s.all());sqlite.exec('COMMIT');return results}
 catch(error){sqlite.exec('ROLLBACK');throw error}
}};
globalThis.authTestDatabase=db;
const urls=new Map();
function moduleURL(filename){
 filename=path.resolve(filename);if(urls.has(filename))return urls.get(filename);
 let source=fs.readFileSync(filename,'utf8');
 source=source.replace(/import\s*\{\s*database\s*\}\s*from\s*["']@\/db\/raw["'];?/g,'const database=()=>globalThis.authTestDatabase;');
 source=source.replace(/import\s*["']server-only["'];?/g,'');
 source=source.replace(/import\s*\{\s*provider,\s*ownerEmail\s*\}\s*from\s*['"]@\/lib\/supabase['"];?/, 'const provider=()=>globalThis.authTestProvider;const ownerEmail=()=>"owner@example.test";');
 source=source.replace(/import\s*\{\s*ownerEmail\s*\}\s*from\s*['"]@\/lib\/supabase['"];?/, 'const ownerEmail=()=>"owner@example.test";');
 source=source.replace(/import\s*\{\s*socialAvailability,\s*oauthProvider,\s*providerOrigin\s*\}\s*from\s*['"]@\/lib\/supabase['"];?/, 'const socialAvailability=async()=>globalThis.socialTestAvailability;const oauthProvider=storage=>globalThis.socialTestProvider(storage);const providerOrigin=()=>"https://fixture.supabase.co";');
 source=source.replace(/import\s*\{\s*oauthProvider\s*\}\s*from\s*['"]@\/lib\/supabase['"];?/, 'const oauthProvider=storage=>globalThis.socialTestProvider(storage);');
 source=source.replace(/(from\s*["'])(@\/[^"']+|\.[^"']+)(["'])/g,(_all,before,spec,after)=>{
  let target=spec.startsWith('@/')?path.join(root,spec.slice(2)):path.resolve(path.dirname(filename),spec);
  if(!path.extname(target))target+='.ts';
  return before+moduleURL(target)+after;
 });
 const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
 const url='data:text/javascript;base64,'+Buffer.from(compiled).toString('base64');urls.set(filename,url);return url;
}
const auth=await import(moduleURL(path.join(root,'lib/auth.ts')));
const route=await import(moduleURL(path.join(root,'app/api/pds/route.ts')));
const feedback=await import(moduleURL(path.join(root,'app/api/feedback/route.ts')));
const authRoute=await import(moduleURL(path.join(root,'app/api/auth/route.ts')));
const accountRoute=await import(moduleURL(path.join(root,'app/api/account/route.ts')));
const experienceRoute=await import(moduleURL(path.join(root,'app/api/experience/route.ts')));
const socialRoute=await import(moduleURL(path.join(root,'app/api/auth/social/route.ts')));
const socialCallback=await import(moduleURL(path.join(root,'app/auth/social/callback/route.ts')));
const oauthFlow=await import(moduleURL(path.join(root,'lib/oauth-flow.ts')));
const names=['plans','plan_versions','tasks','executions','completion_events','reviews'];
const owners=['qa-owner-a','qa-owner-b'];
const instant=Date.now();
for(const owner of owners){
 sqlite.prepare('INSERT INTO diary_accounts(id,created_at) VALUES (?,?)').run(owner,instant);
 sqlite.prepare("INSERT INTO plans(id,title,start_date,end_date,priority,success,estimated_minutes,created_at,owner_id) VALUES (?,'Fixture','2026-10-09','2026-10-23',1,'Fixture',0,'fixture',?)").run(`plan-${owner}`,owner);
 sqlite.prepare("INSERT INTO tasks(id,plan_id,title,due_date,priority,tags,estimated_minutes,created_at) VALUES (?,?,'Fixture','2026-10-10',1,'fixture',0,'fixture')").run(`task-${owner}`,`plan-${owner}`);
 sqlite.prepare("INSERT INTO executions VALUES (?,?,'fixture','fixture',1,'',?,'fixture')").run(`execution-${owner}`,`task-${owner}`,`key-${owner}`);
 sqlite.prepare("INSERT INTO completion_events VALUES (?,?,0,'fixture')").run(`event-${owner}`,`task-${owner}`);
 sqlite.prepare("INSERT INTO reviews VALUES (?,?,'2026-10-09','2026-10-10','fixture','{}','fixture')").run(`review-${owner}`,`plan-${owner}`);
 sqlite.prepare("INSERT INTO plan_versions VALUES (?,?,1,'{}','fixture')").run(`version-${owner}`,`plan-${owner}`);
}
sqlite.prepare("INSERT INTO plans(id,title,start_date,end_date,priority,success,estimated_minutes,created_at) VALUES ('legacy','Legacy','2026-10-09','2026-10-23',1,'Fixture',0,'fixture')").run();
const issue=async owner=>auth.issueSession(db,{id:owner,email:`${owner}@example.test`,email_confirmed_at:'fixture'},instant);
const sessions=await Promise.all(owners.map(issue));
const cookies=sessions.map(s=>s.cookie.split(';')[0]);
function req(cookie='',body,url='https://diary.example.test/api/pds',extra={}){
 return new Request(url,{method:body?'POST':'GET',headers:{cookie,origin:'https://diary.example.test','content-type':'application/json',...extra},...(body?{body:JSON.stringify(body)}:{})});
}
const call=async(cookie,body)=>{const response=await route.POST(req(cookie,body));return {status:response.status,data:await response.json()}};
const snapshot=()=>Object.fromEntries(names.map(name=>[name,sqlite.prepare(`SELECT * FROM ${name} ORDER BY id`).all()]));
const checks=[];
async function check(label,fn){await fn();checks.push(label);console.log('PASS:',label);}
await check('Anonymous GET and POST return 401',async()=>{
 assert.equal((await route.GET(req())).status,401);assert.equal((await call('',{action:'delete',id:`task-${owners[0]}`})).status,401);
});
await check('Both owners see exactly their six lists; URL and header spoofing ignored',async()=>{
 for(let i=0;i<owners.length;i++){
  const response=await route.GET(req(cookies[i],undefined,`https://diary.example.test/api/pds?owner_id=${owners[1-i]}`,{'x-user-id':owners[1-i],'x-owner-id':owners[1-i]}));
  assert.equal(response.status,200);const data=await response.json();assert.deepEqual(Object.keys(data).sort(),[...names].sort());
  for(const name of names){assert.equal(data[name].length,1,name);assert.ok(data[name][0].id.endsWith(owners[i]),name);}
 }
});
await check('Cross-owner updates, deletes and child references denied in both directions; all rows unchanged',async()=>{
 for(let i=0;i<owners.length;i++){
  const other=owners[1-i],before=snapshot();
  const bodies=[
   {action:'plan',id:`plan-${other}`,version:1,title:'Tampered',start_date:'2026-10-09',end_date:'2026-10-23',priority:1,success:'Tampered',estimated_minutes:0},
   {action:'task',id:`task-${other}`,plan_id:`plan-${other}`,title:'Tampered',due_date:'2026-10-10',priority:1,tags:'',estimated_minutes:0},
   {action:'task',id:`task-${other}`,plan_id:`plan-${owners[i]}`,title:'Tampered',due_date:'2026-10-10',priority:1,tags:'',estimated_minutes:0},
   ...['delete','restore','complete','reopen'].map(action=>({action,id:`task-${other}`,generation:0})),
   {action:'execution',task_id:`task-${other}`,started_at:'2026-10-09T00:00:00Z',ended_at:'2026-10-09T00:01:00Z',request_key:`attack-${i}`},
   {action:'review',plan_id:`plan-${other}`,from_date:'2026-10-09',to_date:'2026-10-10',improvement:'Tampered'},
   {action:'plan',source_review_id:`review-${other}`,title:'Tampered',start_date:'2026-10-09',end_date:'2026-10-23',priority:1,success:'Tampered',estimated_minutes:0}
  ];
  for(const body of bodies){const result=await call(cookies[i],{...body,owner_id:other,user_id:other});assert.ok([403,404].includes(result.status),`${body.action}: ${result.status}`);assert.deepEqual(snapshot(),before,body.action);}
 }
});
await check('New plan ignores forged owner in request body',async()=>{
 const response=await call(cookies[0],{action:'plan',owner_id:owners[1],user_id:owners[1],title:'My plan',start_date:'2026-10-09',end_date:'2026-10-23',priority:1,success:'Fixture',estimated_minutes:0});
 assert.equal(response.status,200);assert.equal(sqlite.prepare('SELECT owner_id FROM plans WHERE id=?').get(response.data.id).owner_id,owners[0]);
});
await check('Owners can modify their own rows; identical external keys do not collide between owners',async()=>{
 for(let i=0;i<owners.length;i++){
  const owner=owners[i],cookie=cookies[i];
  assert.equal((await call(cookie,{action:'plan',id:`plan-${owner}`,version:1,title:'Updated',start_date:'2026-10-09',end_date:'2026-10-23',priority:1,success:'Fixture',estimated_minutes:1})).status,200);
  assert.equal(sqlite.prepare('SELECT version FROM plans WHERE id=?').get(`plan-${owner}`).version,2);
  const execution={action:'execution',task_id:`task-${owner}`,started_at:'2026-10-09T00:00:00Z',ended_at:'2026-10-09T00:00:45Z',request_key:'shared-external-key',blocked_reason:''};
  assert.equal((await call(cookie,execution)).status,200);assert.equal((await call(cookie,execution)).status,200);
  assert.equal(sqlite.prepare('SELECT count(*) n FROM executions WHERE task_id=?').get(`task-${owner}`).n,2);
  assert.equal(sqlite.prepare('SELECT actual_minutes FROM executions WHERE task_id=? AND started_at=?').get(`task-${owner}`,'2026-10-09T00:00:00.000Z').actual_minutes,0.75);
  assert.equal((await call(cookie,{action:'delete',id:`task-${owner}`})).status,200);assert.ok(sqlite.prepare('SELECT deleted_at FROM tasks WHERE id=?').get(`task-${owner}`).deleted_at);
  assert.equal((await call(cookie,{action:'restore',id:`task-${owner}`})).status,200);assert.equal(sqlite.prepare('SELECT deleted_at FROM tasks WHERE id=?').get(`task-${owner}`).deleted_at,null);
 }
});
await check('Cross-origin mutation rejected before any rows change',async()=>{
 const before=snapshot();const response=await route.POST(req(cookies[0],{action:'delete',id:`task-${owners[0]}`},undefined,{origin:'https://attacker.example.test'}));assert.equal(response.status,403);assert.deepEqual(snapshot(),before);
});
await check('Feedback owner isolation, forged owner ignored, foreign delete404 and admin403',async()=>{
 const ids=[];
 const feedbackURL='https://diary.example.test/api/feedback';
 const mutate=(method,cookie,body)=>feedback[method](new Request(feedbackURL,{method,headers:{cookie,origin:'https://diary.example.test','content-type':'application/json'},body:JSON.stringify(body)}));
 for(let i=0;i<owners.length;i++){
  const response=await mutate('POST',cookies[i],{category:'ux',screen:'계획',problem:'버튼 찾기 어려움',suggestion:'표시 개선',user_id:owners[1-i],owner_id:owners[1-i]});
  assert.equal(response.status,201);const data=await response.json();ids.push(data.id);
  assert.equal(sqlite.prepare('SELECT user_id FROM feedback WHERE id=?').get(data.id).user_id,owners[i]);
 }
 for(let i=0;i<owners.length;i++){
  const response=await feedback.GET(req(cookies[i],undefined,`${feedbackURL}?id=${ids[1-i]}&user_id=${owners[1-i]}`,{'x-user-id':owners[1-i]}));assert.equal(response.status,200);
  const data=await response.json();assert.deepEqual(data.items.map(item=>item.id),[ids[i]]);assert.equal(data.groups[0].count,1);
  const before=sqlite.prepare('SELECT * FROM feedback ORDER BY id').all();
  assert.equal((await mutate('DELETE',cookies[i],{id:ids[1-i]})).status,404);assert.deepEqual(sqlite.prepare('SELECT * FROM feedback ORDER BY id').all(),before);
  assert.equal((await feedback.GET(req(cookies[i],undefined,feedbackURL+'?scope=admin'))).status,403);
  assert.equal((await mutate('PATCH',cookies[i],{id:ids[i],status:'reviewing',priority:'normal',reason:'fixture'})).status,403);
  assert.deepEqual(sqlite.prepare('SELECT * FROM feedback ORDER BY id').all(),before);
 }
 for(let i=0;i<owners.length;i++){
  assert.equal((await mutate('DELETE',cookies[i],{id:ids[i]})).status,200);
  const response=await feedback.GET(req(cookies[i],undefined,feedbackURL));assert.deepEqual((await response.json()).items,[]);
 }
 assert.equal((await feedback.GET(req('',undefined,feedbackURL))).status,401);
});
await check('Auth route trusts provider-verified identity, rejects unverified account, and masks login failures',async()=>{
 let mode='verified';
 globalThis.authTestProvider={auth:{
  signInWithPassword:async()=>mode==='failed'?{error:{message:'provider detail'},data:{session:null}}:{error:null,data:{session:{access_token:'mock-provider-token'}}},
  getUser:async()=>({error:null,data:{user:{id:owners[0],email:owners[0]+'@example.test',email_confirmed_at:mode==='unverified'?null:'fixture'}}}),
  signUp:async()=>({error:null,data:{user:{id:'signup-fixture-user'},session:null}}),
  signOut:async()=>({error:null})
 }};
 const login=body=>authRoute.POST(req('',{action:'login',password:'Synthetic-QA-only-123',...body},'https://diary.example.test/api/auth'));
 const success=await login({email:owners[0]+'@example.test',user_id:owners[1],owner_id:owners[1]});assert.equal(success.status,200);assert.equal((await success.json()).user.id,owners[0]);assert.ok(success.headers.get('set-cookie').includes('HttpOnly'));
 mode='unverified';assert.equal((await login({email:owners[0]+'@example.test'})).status,401);
 mode='failed';const wrong=await login({email:owners[0]+'@example.test'}),unknown=await login({email:'absent@example.test'});assert.equal(wrong.status,401);assert.equal(unknown.status,401);assert.deepEqual(await wrong.json(),await unknown.json());
 const signup=await authRoute.POST(req('',{action:'signup',email:' Signup@Example.test ',password:'Synthetic-QA-only-123',role:'admin'},'https://diary.example.test/api/auth'));assert.equal(signup.status,200);
 const registration=sqlite.prepare("SELECT * FROM diary_audit WHERE event='signup' ORDER BY created_at DESC LIMIT 1").get();assert.equal(registration.email,'signup@example.test');assert.equal(registration.account_id,'signup-fixture-user');assert.equal(registration.success,1);
 globalThis.authTestProvider.auth.signUp=async()=>({error:{message:'SMTP private provider detail'},data:{user:null,session:null}});const failedSignup=await authRoute.POST(req('',{action:'signup',email:'blocked@example.test',password:'Synthetic-QA-only-123'},'https://diary.example.test/api/auth'));assert.equal(failedSignup.status,503);assert.ok(!JSON.stringify(await failedSignup.json()).includes('private provider detail'));

 for(const row of sqlite.prepare('SELECT * FROM diary_audit').all())assert.ok(!JSON.stringify(row).includes('Synthetic-QA-only-123'));
 delete globalThis.authTestProvider;
});
await check('Password change verifies the current identity and revokes every previous app session',async()=>{
 const id='password-change-qa';sqlite.prepare("INSERT INTO diary_accounts(id,email,role,created_at) VALUES (?,?,'member',?)").run(id,id+'@example.test',Date.now());
 const user={id,email:id+'@example.test',email_confirmed_at:'fixture'};const first=await auth.issueSession(db,user),second=await auth.issueSession(db,user);let verified=user;
 globalThis.authTestProvider={auth:{signInWithPassword:async()=>({error:null,data:{session:{access_token:'synthetic-password-token'}}}),getUser:async()=>({error:null,data:{user:verified}}),updateUser:async()=>({error:null}),signOut:async()=>({error:null})}};
 const change=()=>authRoute.POST(req(first.cookie.split(';')[0],{action:'password_change',email:user.email,password:'Synthetic-old-test-123',new_password:'Synthetic-new-test-456'},'https://diary.example.test/api/auth'));
 verified={...user,id:owners[1]};assert.equal((await change()).status,403);assert.ok(await auth.authenticate(db,req(first.cookie.split(';')[0])));
 verified=user;assert.equal((await change()).status,200);for(const issued of [first,second])assert.equal(await auth.authenticate(db,req(issued.cookie.split(';')[0])),null);
 for(const row of sqlite.prepare('SELECT * FROM diary_audit').all())assert.ok(!JSON.stringify(row).includes('Synthetic-new-test-456'));
 delete globalThis.authTestProvider;
});
await check('Same URL and same cookie returns 401 after logout',async()=>{
 assert.equal((await route.GET(req(cookies[0]))).status,200);assert.equal((await authRoute.POST(req(cookies[0],{action:'logout'},'https://diary.example.test/api/auth'))).status,200);assert.equal((await route.GET(req(cookies[0]))).status,401);
});
await check('Expired session rejected by real route; expiry boundary exact',async()=>{
 assert.ok(await auth.authenticate(db,req(cookies[1]),sessions[1].expiresAt-1));assert.equal(await auth.authenticate(db,req(cookies[1]),sessions[1].expiresAt),null);
 sqlite.prepare('UPDATE diary_sessions SET expires_at=? WHERE user_id=?').run(Date.now()-1,owners[1]);assert.equal((await route.GET(req(cookies[1]))).status,401);
});
await check('Automatic experience changes only own allowlisted preferences; opt-out, reset and no-op respected',async()=>{
 const fresh=await Promise.all(owners.map(owner=>auth.issueSession(db,{id:owner,email:owner+'@example.test',email_confirmed_at:'fixture'})));
 const current=fresh.map(session=>session.cookie.split(';')[0]),url='https://diary.example.test/api/experience';
 const change=(i,body)=>experienceRoute.POST(req(current[i],{...body,owner_id:owners[1-i],user_id:owners[1-i]},url));
 const get=async i=>(await experienceRoute.GET(req(current[i],undefined,url))).json();
 const defaults={large_text:false,high_contrast:false,comfortable:false};
 for(let i=0;i<2;i++){assert.equal((await change(i,{action:'reset'})).status,200);const data=await get(i);assert.deepEqual(data.preferences,defaults);assert.equal(data.automatic,false);}
 await change(0,{action:'automatic',enabled:true});const otherBefore=await get(1);
 const submit=()=>feedback.POST(req(current[0],{category:'ux',screen:'모바일',problem:'글자가 작고 대비가 흐려서 버튼 누르기 어려워요',suggestion:'개선',user_id:owners[1]},'https://diary.example.test/api/feedback'));
 const applied=await submit();assert.equal(applied.status,201);const data=await applied.json();assert.equal(data.applied.length,3);assert.deepEqual(data.experience,{large_text:true,high_contrast:true,comfortable:true});assert.deepEqual(await get(1),otherBefore);
 const count=()=>sqlite.prepare('SELECT count(*) n FROM ui_changes WHERE user_id=?').get(owners[0]).n;
 const history=count();assert.deepEqual((await (await submit()).json()).applied,[]);assert.equal(count(),history);
 const reset=await change(0,{action:'reset'});assert.deepEqual((await reset.json()).preferences,defaults);assert.equal((await get(0)).automatic,false);
 const resetHistory=count();assert.deepEqual((await (await submit()).json()).applied,[]);assert.deepEqual((await get(0)).preferences,defaults);assert.equal(count(),resetHistory);
 await change(0,{action:'automatic',enabled:true});await submit();await change(0,{action:'automatic',enabled:false});assert.equal((await get(0)).automatic,false);
 const offHistory=count();await submit();assert.equal(count(),offHistory);assert.deepEqual(await get(1),otherBefore);
 assert.equal((await experienceRoute.GET(req('',undefined,url))).status,401);
});
await check('Account export isolated; audit403; wrong confirmation400 unchanged; app deletion owner-only and revokes sessions',async()=>{
 const fresh=await Promise.all(owners.map(owner=>auth.issueSession(db,{id:owner,email:owner+'@example.test',email_confirmed_at:'fixture'})));
 const current=fresh.map(session=>session.cookie.split(';')[0]),url='https://diary.example.test/api/account';
 // The existing feedback rows are soft-deleted: exports must still include the owner's data only.
 for(let i=0;i<owners.length;i++){
  sqlite.prepare('INSERT INTO study_protocols(id,user_id,question,rules_json,baseline_rule,created_at) VALUES(?,?,?,?,?,?)').run('study-'+owners[i],owners[i],'fixture','{}','fixture','2026-10-09T00:00:00Z');
 sqlite.prepare('INSERT INTO study_days(id,protocol_id,day_number,seoul_date,sessions_json,total_minutes,created_at) VALUES(?,?,?,?,?,?,?)').run('study-day-'+owners[i],'study-'+owners[i],1,'2026-10-09','[1]',1,'2026-10-09T00:00:00Z');
 const owned=sqlite.prepare('SELECT id FROM feedback WHERE user_id=?').get(owners[i]);
  sqlite.prepare('INSERT INTO feedback_events(id,feedback_id,actor_id,action,reason,created_at) VALUES(?,?,?,?,?,?)').run('account-event-'+owners[i],owned.id,owners[i],'fixture','fixture','fixture');
  const response=await accountRoute.GET(req(current[i],undefined,url));assert.equal(response.status,200);const data=await response.json();
  const expected=await (await route.GET(req(current[i]))).json();for(const name of names)assert.deepEqual(data[name],expected[name],name);
  assert.equal(data.study_protocols.length,1);assert.equal(data.study_protocols[0].user_id,owners[i]);assert.equal(data.study_days.length,1);assert.equal(data.study_days[0].protocol_id,'study-'+owners[i]);assert.ok(data.feedback.length>=1);for(const item of data.feedback)assert.equal(item.user_id,owners[i]);
  assert.equal(data.experience.length,1);assert.deepEqual(data.experience,JSON.parse(JSON.stringify(sqlite.prepare('SELECT preferences,automatic,version,updated_at FROM ui_preferences WHERE user_id=?').all(owners[i]))));assert.ok(data.experience_changes.length>=1);assert.deepEqual(data.experience_changes,JSON.parse(JSON.stringify(sqlite.prepare('SELECT id,feedback_id,before_json,after_json,created_at FROM ui_changes WHERE user_id=?').all(owners[i]))));assert.equal(data.feedback_events.length,1);assert.equal(data.feedback_events[0].actor_id,owners[i]);
  assert.equal((await accountRoute.GET(req(current[i],undefined,url+'?audit=1'))).status,403);
 }
 const allTables=[...names,'feedback','feedback_events','diary_sessions','diary_accounts','diary_audit','ui_preferences','ui_changes','study_protocols','study_days'];
 const allRows=()=>Object.fromEntries(allTables.map(name=>[name,sqlite.prepare(`SELECT * FROM ${name} ORDER BY 1`).all()]));
 const remove=(cookie,confirmation)=>accountRoute.DELETE(new Request(url,{method:'DELETE',headers:{cookie,origin:'https://diary.example.test','content-type':'application/json'},body:JSON.stringify({confirmation,user_id:owners[1]})}));
 const before=allRows();assert.equal((await remove(current[0],'wrong')).status,400);assert.deepEqual(allRows(),before);
 const otherBefore=await (await accountRoute.GET(req(current[1],undefined,url))).json();delete otherBefore.exported_at;
 assert.equal((await remove(current[0],'삭제')).status,200);
 const erased=sqlite.prepare('SELECT email,deleted_at FROM diary_accounts WHERE id=?').get(owners[0]);assert.equal(erased.email,null);assert.ok(erased.deleted_at);assert.equal(sqlite.prepare('SELECT count(*) n FROM diary_sessions WHERE user_id=?').get(owners[0]).n,0);assert.equal(sqlite.prepare('SELECT count(*) n FROM study_days WHERE protocol_id=?').get('study-'+owners[0]).n,0);
 globalThis.authTestProvider={auth:{signInWithPassword:async()=>({error:null,data:{session:{access_token:'synthetic-deleted-token'}}}),getUser:async()=>({error:null,data:{user:{id:owners[0],email:owners[0]+'@example.test',email_confirmed_at:'fixture'}}})}};assert.equal((await authRoute.POST(req('',{action:'login',email:owners[0]+'@example.test',password:'Synthetic-deleted-test-123'},'https://diary.example.test/api/auth'))).status,403);delete globalThis.authTestProvider;
 assert.equal((await route.GET(req(current[0]))).status,401);assert.equal((await route.GET(req(cookies[0]))).status,401);
 for(const name of ['ui_preferences','ui_changes','study_protocols'])assert.equal(sqlite.prepare(`SELECT count(*) n FROM ${name} WHERE user_id=?`).get(owners[0]).n,0);
 for(const name of ['plans','feedback'])assert.equal(sqlite.prepare(`SELECT count(*) n FROM ${name} WHERE ${name==='plans'?'owner_id':'user_id'}=?`).get(owners[0]).n,0);
 for(const name of ['tasks','plan_versions','reviews'])assert.equal(sqlite.prepare(`SELECT count(*) n FROM ${name} WHERE plan_id=?`).get('plan-'+owners[0]).n,0);
 for(const name of ['executions','completion_events'])assert.equal(sqlite.prepare(`SELECT count(*) n FROM ${name} WHERE task_id=?`).get('task-'+owners[0]).n,0);
 assert.equal(sqlite.prepare('SELECT count(*) n FROM feedback_events WHERE actor_id=?').get(owners[0]).n,0);
 const otherAfter=await (await accountRoute.GET(req(current[1],undefined,url))).json();delete otherAfter.exported_at;assert.deepEqual(otherAfter,otherBefore);
 assert.equal(sqlite.prepare('SELECT count(*) n FROM plans WHERE id=?').get('legacy').n,1);
});
await check('Social login rejects foreign origins, disabled providers, unsupported names, and forged or expired callbacks',async()=>{
 globalThis.socialTestAvailability={google:false,kakao:false};
 const url='https://diary.example.test/api/auth/social';
 assert.equal((await socialRoute.POST(req('',{provider:'google'},url,{origin:'https://attacker.example.test'}))).status,403);
 assert.equal((await socialRoute.POST(req('',{provider:'unknown'},url))).status,400);
 assert.equal((await socialRoute.POST(req('',{provider:'google'},url))).status,503);
 const rejected=await socialCallback.GET(new Request('https://diary.example.test/auth/social/callback?code=forged&attempt=forged'));assert.equal(new URL(rejected.headers.get('Location')).searchParams.get('social_error'),'1');assert.ok(!rejected.headers.get('Set-Cookie').includes('__Host-pds-session'));
 const expired={state:crypto.randomUUID(),provider:'google',created:Date.now()-600001,verifiers:{'fixture-code-verifier':'verifier'}};
 assert.equal(oauthFlow.readFlow(new Request(url,{headers:{cookie:oauthFlow.cookie(JSON.stringify(expired)).split(';')[0]}})),null);
});
await check('Social login binds PKCE to this browser and issues only a provider-verified app session',async()=>{
 globalThis.socialTestAvailability={google:true,kakao:true};
 globalThis.socialTestProvider=storage=>({auth:{signInWithOAuth:async()=>{storage.setItem('fixture-code-verifier','verifier');return {error:null,data:{url:'https://fixture.supabase.co/auth/v1/authorize?provider=google'}};},exchangeCodeForSession:async()=>({error:null,data:{session:{access_token:'social-synthetic-test-token'}}}),getUser:async()=>({error:null,data:{user:{id:'social-qa-owner',email:'social-qa-owner@example.test',email_confirmed_at:'fixture'}}}),signOut:async()=>({error:null})}});
 const start=await socialRoute.POST(req('',{provider:'google'},'https://diary.example.test/api/auth/social'));assert.equal(start.status,200);
 const flowHeader=start.headers.get('Set-Cookie');assert.ok(flowHeader.includes('HttpOnly')&&flowHeader.includes('Secure')&&flowHeader.includes('SameSite=Lax'));assert.ok(!flowHeader.includes('social-synthetic-test-token'));
 const flowCookie=flowHeader.split(';')[0],flow=oauthFlow.readFlow(new Request('https://diary.example.test',{headers:{cookie:flowCookie}}));
 const bad=await socialCallback.GET(new Request('https://diary.example.test/auth/social/callback?code=fixture&attempt=wrong',{headers:{cookie:flowCookie}}));assert.ok(!bad.headers.get('Set-Cookie').includes('__Host-pds-session'));
 const result=await socialCallback.GET(new Request('https://diary.example.test/auth/social/callback?code=fixture&attempt='+flow.state,{headers:{cookie:flowCookie}}));assert.equal(result.status,303);assert.equal(new URL(result.headers.get('Location')).search,'');assert.ok(result.headers.get('Set-Cookie').includes('__Host-pds-session'));assert.ok(!result.headers.get('Set-Cookie').includes('social-synthetic-test-token'));
 delete globalThis.socialTestAvailability;delete globalThis.socialTestProvider;
});

const report={tested_at:new Date().toISOString(),scope:'Real PDS, feedback, account and auth routes + local session helper, in-memory SQLite. Auth provider response mocked; Supabase network and live D1 not exercised.',checks};
const output=path.resolve(root,'../../task07/qa/auth-route-results.json');fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');
sqlite.close();delete globalThis.authTestDatabase;

