import ts from 'typescript';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';

// Executes the real protected route with only its D1 binding replaced. No network or user data.
const root=path.resolve(import.meta.dirname,'..');
const sqlite=new DatabaseSync(':memory:');
const migrations=fs.readdirSync(path.join(root,'drizzle')).filter(name=>/^0.*\.sql$/.test(name)).sort();
for(const name of migrations)sqlite.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));
function statement(sql,params=[]) {
 const s=sqlite.prepare(sql);
 return {bind:(...args)=>statement(sql,args),first:async()=>s.get(...params)||null,
 all:async()=>s.columns().length?{results:s.all(...params)}:{results:[],meta:{changes:Number(s.run(...params).changes)}},run:async()=>({meta:{changes:Number(s.run(...params).changes)}})};
}
const db={prepare:statement,batch:async statements=>{
 sqlite.exec('BEGIN');try{const results=[];for(const s of statements)results.push(await s.all());sqlite.exec('COMMIT');return results}
 catch(error){sqlite.exec('ROLLBACK');throw error}
}};
globalThis.authTestDatabase=db;
globalThis.authTestEnvironment={RECOVERY_SESSION_KEY:"17".repeat(32)};
const urls=new Map();
function moduleURL(filename){
 filename=path.resolve(filename);if(urls.has(filename))return urls.get(filename);
 let source=fs.readFileSync(filename,'utf8');
 source=source.replace(/import\s*\{\s*database\s*\}\s*from\s*["']@\/db\/raw["'];?/g,'const database=()=>globalThis.authTestDatabase;');
 source=source.replace(/import\s*["']server-only["'];?/g,'');
 source=source.replace(/import\s*\{\s*env\s*\}\s*from\s*['"]cloudflare:workers['"];?/g,'const env=globalThis.authTestEnvironment;');
 source=source.replace(/import\s*\{\s*provider,\s*ownerEmail\s*\}\s*from\s*['"]@\/lib\/supabase['"];?/, 'const provider=()=>globalThis.authTestProvider;const ownerEmail=()=>"owner@example.test";');
 source=source.replace(/import\s*\{\s*ownerEmail\s*\}\s*from\s*['"]@\/lib\/supabase['"];?/, 'const ownerEmail=()=>"owner@example.test";');
 source=source.replace(/import\s*\{\s*socialAvailability,\s*oauthProvider,\s*providerOrigin\s*\}\s*from\s*['"]@\/lib\/supabase['"];?/, 'const socialAvailability=async()=>globalThis.socialTestAvailability;const oauthProvider=storage=>globalThis.socialTestProvider(storage);const providerOrigin=()=>"https://fixture.supabase.co";');
 source=source.replace(/import\s*\{\s*oauthProvider\s*\}\s*from\s*['"]@\/lib\/supabase['"];?/, 'const oauthProvider=storage=>globalThis.socialTestProvider(storage);');
 source=source.replace(/(from\s*["'])(@\/[^"']+|\.[^"']+)(["'])/g,(_all,before,spec,after)=>{
  let target=spec.startsWith('@/')?path.join(root,spec.slice(2)):path.resolve(path.dirname(filename),spec);
  if(!path.extname(target))target+='.ts';
  return before+moduleURL(target)+after;
 });
 const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
 const url='data:text/javascript;base64,'+Buffer.from(compiled).toString('base64');urls.set(filename,url);return url;
}
const auth=await import(moduleURL(path.join(root,'lib/auth.ts')));
const route=await import(moduleURL(path.join(root,'app/api/pds/route.ts')));
const feedback=await import(moduleURL(path.join(root,'app/api/feedback/route.ts')));
const authRoute=await import(moduleURL(path.join(root,'app/api/auth/route.ts')));
const accountRoute=await import(moduleURL(path.join(root,'app/api/account/route.ts')));
const experienceRoute=await import(moduleURL(path.join(root,'app/api/experience/route.ts')));
const socialRoute=await import(moduleURL(path.join(root,'app/api/auth/social/route.ts')));
const socialCallback=await import(moduleURL(path.join(root,'app/auth/social/callback/route.ts')));
const oauthFlow=await import(moduleURL(path.join(root,'lib/oauth-flow.ts')));
const names=['plans','plan_versions','tasks','executions','completion_events','reviews'];
const owners=['qa-owner-a','qa-owner-b'];
const instant=Date.now();
for(const owner of owners){
 sqlite.prepare('INSERT INTO diary_accounts(id,created_at) VALUES (?,?)').run(owner,instant);
 sqlite.prepare("INSERT INTO plans(id,title,start_date,end_date,priority,success,estimated_minutes,created_at,owner_id) VALUES (?,'Fixture','2026-10-09','2026-10-23',1,'Fixture',0,'fixture',?)").run(`plan-${owner}`,owner);
 sqlite.prepare("INSERT INTO tasks(id,plan_id,title,due_date,priority,tags,estimated_minutes,created_at) VALUES (?,?,'Fixture','2026-10-10',1,'fixture',0,'fixture')").run(`task-${owner}`,`plan-${owner}`);
 sqlite.prepare("INSERT INTO executions VALUES (?,?,'fixture','fixture',1,'',?,'fixture')").run(`execution-${owner}`,`task-${owner}`,`key-${owner}`);
 sqlite.prepare("INSERT INTO completion_events VALUES (?,?,0,'fixture')").run(`event-${owner}`,`task-${owner}`);
 sqlite.prepare("INSERT INTO reviews VALUES (?,?,'2026-10-09','2026-10-10','fixture','{}','fixture')").run(`review-${owner}`,`plan-${owner}`);
 sqlite.prepare("INSERT INTO plan_versions VALUES (?,?,1,'{}','fixture')").run(`version-${owner}`,`plan-${owner}`);
}
sqlite.prepare("INSERT INTO plans(id,title,start_date,end_date,priority,success,estimated_minutes,created_at) VALUES ('legacy','Legacy','2026-10-09','2026-10-23',1,'Fixture',0,'fixture')").run();
const issue=async owner=>auth.issueSession(db,{id:owner,email:`${owner}@example.test`,email_confirmed_at:'fixture'},instant);
const sessions=await Promise.all(owners.map(issue));
const cookies=sessions.map(s=>s.cookie.split(';')[0]);
function req(cookie='',body,url='https://diary.example.test/api/pds',extra={}){
 return new Request(url,{method:body?'POST':'GET',headers:{cookie,origin:'https://diary.example.test','content-type':'application/json',...extra},...(body?{body:JSON.stringify(body)}:{})});
}
const call=async(cookie,body)=>{const response=await route.POST(req(cookie,body));return {status:response.status,data:await response.json()}};
const snapshot=()=>Object.fromEntries(names.map(name=>[name,sqlite.prepare(`SELECT * FROM ${name} ORDER BY id`).all()]));
const checks=[];
async function check(label,fn){await fn();checks.push(label);console.log('PASS:',label);}
await check('Anonymous GET and POST return 401',async()=>{
 assert.equal((await route.GET(req())).status,401);assert.equal((await call('',{action:'delete',id:`task-${owners[0]}`})).status,401);
});
await check('Both owners see exactly their six lists; URL and header spoofing ignored',async()=>{
 for(let i=0;i<owners.length;i++){
  const response=await route.GET(req(cookies[i],undefined,`https://diary.example.test/api/pds?owner_id=${owners[1-i]}`,{'x-user-id':owners[1-i],'x-owner-id':owners[1-i]}));
  assert.equal(response.status,200);const data=await response.json();assert.deepEqual(Object.keys(data).sort(),[...names].sort());
  for(const name of names){assert.equal(data[name].length,1,name);assert.ok(data[name][0].id.endsWith(owners[i]),name);}
 }
});
await check('Individual reads: each owner gets own six rows200, foreign and missing rows404 in both directions; owner spoofing ignored and rows unchanged',async()=>{
 const prefixes={plans:'plan',tasks:'task',executions:'execution',reviews:'review',plan_versions:'version',completion_events:'event'};
 const before=snapshot();
 for(let i=0;i<owners.length;i++){
  for(const entity of names){
   const ownId=`${prefixes[entity]}-${owners[i]}`,otherId=`${prefixes[entity]}-${owners[1-i]}`;
   const read=recordId=>route.GET(req(cookies[i],undefined,`https://diary.example.test/api/pds?entity=${entity}&id=${recordId}&owner_id=${owners[1-i]}`,{'x-user-id':owners[1-i],'x-owner-id':owners[1-i]}));
   const own=await read(ownId);assert.equal(own.status,200,entity);assert.deepEqual(await own.json(),JSON.parse(JSON.stringify(sqlite.prepare(`SELECT * FROM ${entity} WHERE id=?`).get(ownId))));
   const foreign=await read(otherId),absent=await read('missing-record');assert.equal(foreign.status,404,entity);assert.equal(absent.status,404,entity);assert.deepEqual(await foreign.json(),await absent.json());
  }
 }
 assert.equal((await route.GET(req(cookies[0],undefined,'https://diary.example.test/api/pds?entity=plans&id=legacy'))).status,404);
 assert.deepEqual(snapshot(),before);
});
await check('Individual read validates allowlisted entity and id only after authentication',async()=>{
 const invalid=['entity=unknown&id=fixture','entity=constructor&id=fixture','entity=plans','id=fixture','entity=plans&id=','entity=plans&id=bad%20id','entity=plans&id='+('x'.repeat(101)),'entity=plans&entity=tasks&id=fixture','entity=plans&id=fixture&id=other'];
 const before=snapshot();
 for(const query of invalid){
  const url='https://diary.example.test/api/pds?'+query;
  assert.equal((await route.GET(req(cookies[0],undefined,url))).status,400,query);
  assert.equal((await route.GET(req('',undefined,url))).status,401,query);
 }
 assert.equal((await route.GET(req('',undefined,'https://diary.example.test/api/pds?entity=plans&id=plan-'+owners[0]))).status,401);
 assert.deepEqual(snapshot(),before);
});
await check('Cross-owner updates, deletes and child references denied in both directions; all rows unchanged',async()=>{
 for(let i=0;i<owners.length;i++){
  const other=owners[1-i],before=snapshot();
  const bodies=[
   {action:'plan',id:`plan-${other}`,version:1,title:'Tampered',start_date:'2026-10-09',end_date:'2026-10-23',priority:1,success:'Tampered',estimated_minutes:0},
   {action:'task',id:`task-${other}`,plan_id:`plan-${other}`,title:'Tampered',due_date:'2026-10-10',priority:1,tags:'',estimated_minutes:0},
   {action:'task',id:`task-${other}`,plan_id:`plan-${owners[i]}`,title:'Tampered',due_date:'2026-10-10',priority:1,tags:'',estimated_minutes:0},
   ...['delete','restore','complete','reopen'].map(action=>({action,id:`task-${other}`,generation:0})),
   {action:'execution',task_id:`task-${other}`,started_at:'2026-10-09T00:00:00Z',ended_at:'2026-10-09T00:01:00Z',request_key:`attack-${i}`},
   {action:'review',plan_id:`plan-${other}`,from_date:'2026-10-09',to_date:'2026-10-10',improvement:'Tampered'},
   {action:'plan',source_review_id:`review-${other}`,title:'Tampered',start_date:'2026-10-09',end_date:'2026-10-23',priority:1,success:'Tampered',estimated_minutes:0}
  ];
  for(const body of bodies){const result=await call(cookies[i],{...body,owner_id:other,user_id:other});assert.ok([403,404].includes(result.status),`${body.action}: ${result.status}`);assert.deepEqual(snapshot(),before,body.action);}
 }
});
await check('New plan ignores forged owner in request body',async()=>{
 const response=await call(cookies[0],{action:'plan',owner_id:owners[1],user_id:owners[1],title:'My plan',start_date:'2026-10-09',end_date:'2026-10-23',priority:1,success:'Fixture',estimated_minutes:0});
 assert.equal(response.status,200);assert.equal(sqlite.prepare('SELECT owner_id FROM plans WHERE id=?').get(response.data.id).owner_id,owners[0]);
});
await check('Owners can modify their own rows; identical external keys do not collide between owners',async()=>{
 for(let i=0;i<owners.length;i++){
  const owner=owners[i],cookie=cookies[i];
  assert.equal((await call(cookie,{action:'plan',id:`plan-${owner}`,version:1,title:'Updated',start_date:'2026-10-09',end_date:'2026-10-23',priority:1,success:'Fixture',estimated_minutes:1})).status,200);
  assert.equal(sqlite.prepare('SELECT version FROM plans WHERE id=?').get(`plan-${owner}`).version,2);
  const execution={action:'execution',task_id:`task-${owner}`,started_at:'2026-10-09T00:00:00Z',ended_at:'2026-10-09T00:00:45Z',request_key:'shared-external-key',blocked_reason:''};
  assert.equal((await call(cookie,execution)).status,200);assert.equal((await call(cookie,execution)).status,200);
  assert.equal(sqlite.prepare('SELECT count(*) n FROM executions WHERE task_id=?').get(`task-${owner}`).n,2);
  assert.equal(sqlite.prepare('SELECT actual_minutes FROM executions WHERE task_id=? AND started_at=?').get(`task-${owner}`,'2026-10-09T00:00:00.000Z').actual_minutes,0.75);
  assert.equal((await call(cookie,{action:'delete',id:`task-${owner}`})).status,200);assert.ok(sqlite.prepare('SELECT deleted_at FROM tasks WHERE id=?').get(`task-${owner}`).deleted_at);
  assert.equal((await call(cookie,{action:'restore',id:`task-${owner}`})).status,200);assert.equal(sqlite.prepare('SELECT deleted_at FROM tasks WHERE id=?').get(`task-${owner}`).deleted_at,null);
 }
});
await check('Cross-origin mutation rejected before any rows change',async()=>{
 const before=snapshot();const response=await route.POST(req(cookies[0],{action:'delete',id:`task-${owners[0]}`},undefined,{origin:'https://attacker.example.test'}));assert.equal(response.status,403);assert.deepEqual(snapshot(),before);
});
await check('Feedback owner isolation, forged owner ignored, foreign delete404 and admin403',async()=>{
 const ids=[];
 const feedbackURL='https://diary.example.test/api/feedback';
 const mutate=(method,cookie,body)=>feedback[method](new Request(feedbackURL,{method,headers:{cookie,origin:'https://diary.example.test','content-type':'application/json'},body:JSON.stringify(body)}));
 for(let i=0;i<owners.length;i++){
  const response=await mutate('POST',cookies[i],{category:'ux',screen:'계획',problem:'버튼 찾기 어려움',suggestion:'표시 개선',user_id:owners[1-i],owner_id:owners[1-i]});
  assert.equal(response.status,201);const data=await response.json();ids.push(data.id);
  assert.equal(sqlite.prepare('SELECT user_id FROM feedback WHERE id=?').get(data.id).user_id,owners[i]);
 }
 for(let i=0;i<owners.length;i++){
  const response=await feedback.GET(req(cookies[i],undefined,`${feedbackURL}?id=${ids[1-i]}&user_id=${owners[1-i]}`,{'x-user-id':owners[1-i]}));assert.equal(response.status,200);
  const data=await response.json();assert.deepEqual(data.items.map(item=>item.id),[ids[i]]);assert.equal(data.groups[0].count,1);
  const before=sqlite.prepare('SELECT * FROM feedback ORDER BY id').all();
  assert.equal((await mutate('DELETE',cookies[i],{id:ids[1-i]})).status,404);assert.deepEqual(sqlite.prepare('SELECT * FROM feedback ORDER BY id').all(),before);
  assert.equal((await feedback.GET(req(cookies[i],undefined,feedbackURL+'?scope=admin'))).status,403);
  assert.equal((await mutate('PATCH',cookies[i],{id:ids[i],status:'reviewing',priority:'normal',reason:'fixture'})).status,403);
  assert.deepEqual(sqlite.prepare('SELECT * FROM feedback ORDER BY id').all(),before);
 }
 for(let i=0;i<owners.length;i++){
  assert.equal((await mutate('DELETE',cookies[i],{id:ids[i]})).status,200);
  const response=await feedback.GET(req(cookies[i],undefined,feedbackURL));assert.deepEqual((await response.json()).items,[]);
 }
 assert.equal((await feedback.GET(req('',undefined,feedbackURL))).status,401);
});
await check('Auth route trusts provider-verified identity, rejects unverified account, and masks login failures',async()=>{
 let mode='verified';
 globalThis.authTestProvider={auth:{
  signInWithPassword:async()=>mode==='failed'?{error:{message:'provider detail'},data:{session:null}}:{error:null,data:{session:{access_token:'mock-provider-token'}}},
  getUser:async()=>({error:null,data:{user:{id:owners[0],email:owners[0]+'@example.test',email_confirmed_at:mode==='unverified'?null:'fixture'}}}),
  signUp:async()=>({error:null,data:{user:{id:'signup-fixture-user'},session:null}}),
  signOut:async()=>({error:null})
 }};
 const login=body=>authRoute.POST(req('',{action:'login',password:'Synthetic-QA-only-123',...body},'https://diary.example.test/api/auth'));
 const success=await login({email:owners[0]+'@example.test',user_id:owners[1],owner_id:owners[1]});assert.equal(success.status,200);assert.equal((await success.json()).user.id,owners[0]);assert.ok(success.headers.get('set-cookie').includes('HttpOnly'));
 mode='unverified';assert.equal((await login({email:owners[0]+'@example.test'})).status,401);
 mode='failed';const wrong=await login({email:owners[0]+'@example.test'}),unknown=await login({email:'absent@example.test'});assert.equal(wrong.status,401);assert.equal(unknown.status,401);assert.deepEqual(await wrong.json(),await unknown.json());
 const signup=await authRoute.POST(req('',{action:'signup',email:' Signup@Example.test ',password:'Aa!12345',role:'admin'},'https://diary.example.test/api/auth'));assert.equal(signup.status,200);
 assert.equal((await authRoute.POST(req('',{action:'signup',email:'short@example.test',password:'Aa!1234'},'https://diary.example.test/api/auth'))).status,400);
 const registration=sqlite.prepare("SELECT * FROM diary_audit WHERE event='signup' ORDER BY created_at DESC LIMIT 1").get();assert.equal(registration.email,'signup@example.test');assert.equal(registration.account_id,'signup-fixture-user');assert.equal(registration.success,1);
 globalThis.authTestProvider.auth.signUp=async()=>({error:{message:'SMTP private provider detail'},data:{user:null,session:null}});const failedSignup=await authRoute.POST(req('',{action:'signup',email:'blocked@example.test',password:'Synthetic-QA-only-123'},'https://diary.example.test/api/auth'));assert.equal(failedSignup.status,503);assert.ok(!JSON.stringify(await failedSignup.json()).includes('private provider detail'));

 for(const row of sqlite.prepare('SELECT * FROM diary_audit').all())assert.ok(!JSON.stringify(row).includes('Synthetic-QA-only-123'));
 delete globalThis.authTestProvider;
});
await check('Password change verifies the current identity and revokes every previous app session',async()=>{
 const id='password-change-qa';sqlite.prepare("INSERT INTO diary_accounts(id,email,role,created_at) VALUES (?,?,'member',?)").run(id,id+'@example.test',Date.now());
 const user={id,email:id+'@example.test',email_confirmed_at:'fixture'};const first=await auth.issueSession(db,user),second=await auth.issueSession(db,user);let verified=user;
 globalThis.authTestProvider={auth:{signInWithPassword:async()=>({error:null,data:{session:{access_token:'synthetic-password-token'}}}),getUser:async()=>({error:null,data:{user:verified}}),updateUser:async()=>({error:null}),signOut:async()=>({error:null})}};
 const change=()=>authRoute.POST(req(first.cookie.split(';')[0],{action:'password_change',email:user.email,password:'Synthetic-old-test-123',new_password:'Bb!12345'},'https://diary.example.test/api/auth'));
 verified={...user,id:owners[1]};assert.equal((await change()).status,403);assert.ok(await auth.authenticate(db,req(first.cookie.split(';')[0])));
 verified=user;assert.equal((await change()).status,200);for(const issued of [first,second])assert.equal(await auth.authenticate(db,req(issued.cookie.split(';')[0])),null);
 for(const row of sqlite.prepare('SELECT * FROM diary_audit').all())assert.ok(!JSON.stringify(row).includes('Bb!12345'));
 delete globalThis.authTestProvider;
});
await check('Same URL and same cookie returns 401 after logout',async()=>{
 assert.equal((await route.GET(req(cookies[0]))).status,200);assert.equal((await authRoute.POST(req(cookies[0],{action:'logout'},'https://diary.example.test/api/auth'))).status,200);assert.equal((await route.GET(req(cookies[0]))).status,401);
});
await check('Expired session rejected by real route; expiry boundary exact',async()=>{
 assert.ok(await auth.authenticate(db,req(cookies[1]),sessions[1].expiresAt-1));assert.equal(await auth.authenticate(db,req(cookies[1]),sessions[1].expiresAt),null);
 sqlite.prepare('UPDATE diary_sessions SET expires_at=? WHERE user_id=?').run(Date.now()-1,owners[1]);assert.equal((await route.GET(req(cookies[1]))).status,401);
});
await check('Automatic experience changes only own allowlisted preferences; opt-out, reset and no-op respected',async()=>{
 const fresh=await Promise.all(owners.map(owner=>auth.issueSession(db,{id:owner,email:owner+'@example.test',email_confirmed_at:'fixture'})));
 const current=fresh.map(session=>session.cookie.split(';')[0]),url='https://diary.example.test/api/experience';
 const change=(i,body)=>experienceRoute.POST(req(current[i],{...body,owner_id:owners[1-i],user_id:owners[1-i]},url));
 const get=async i=>(await experienceRoute.GET(req(current[i],undefined,url))).json();
 const defaults={large_text:false,high_contrast:false,comfortable:false};
 for(let i=0;i<2;i++){assert.equal((await change(i,{action:'reset'})).status,200);const data=await get(i);assert.deepEqual(data.preferences,defaults);assert.equal(data.automatic,false);}
 await change(0,{action:'automatic',enabled:true});const otherBefore=await get(1);
 const submit=()=>feedback.POST(req(current[0],{category:'ux',screen:'모바일',problem:'글자가 작고 대비가 흐려서 버튼 누르기 어려워요',suggestion:'개선',user_id:owners[1]},'https://diary.example.test/api/feedback'));
 const applied=await submit();assert.equal(applied.status,201);const data=await applied.json();assert.equal(data.applied.length,3);assert.deepEqual(data.experience,{large_text:true,high_contrast:true,comfortable:true});assert.deepEqual(await get(1),otherBefore);
 const count=()=>sqlite.prepare('SELECT count(*) n FROM ui_changes WHERE user_id=?').get(owners[0]).n;
 const history=count();assert.deepEqual((await (await submit()).json()).applied,[]);assert.equal(count(),history);
 const reset=await change(0,{action:'reset'});assert.deepEqual((await reset.json()).preferences,defaults);assert.equal((await get(0)).automatic,false);
 const resetHistory=count();assert.deepEqual((await (await submit()).json()).applied,[]);assert.deepEqual((await get(0)).preferences,defaults);assert.equal(count(),resetHistory);
 await change(0,{action:'automatic',enabled:true});await submit();await change(0,{action:'automatic',enabled:false});assert.equal((await get(0)).automatic,false);
 const offHistory=count();await submit();assert.equal(count(),offHistory);assert.deepEqual(await get(1),otherBefore);
 assert.equal((await experienceRoute.GET(req('',undefined,url))).status,401);
});
await check('Account export isolated; audit403; wrong confirmation400 unchanged; app deletion owner-only and revokes sessions',async()=>{
 const fresh=await Promise.all(owners.map(owner=>auth.issueSession(db,{id:owner,email:owner+'@example.test',email_confirmed_at:'fixture'})));
 const current=fresh.map(session=>session.cookie.split(';')[0]),url='https://diary.example.test/api/account';
 // New social/profile data is exported and erased only for its owner.
 for(let i=0;i<owners.length;i++){
  sqlite.prepare('INSERT INTO diary_profiles(user_id,username,display_name,bio) VALUES(?,?,?,?)').run(owners[i],'export_user_'+i,'Fixture '+i,'');
  sqlite.prepare('INSERT INTO community_posts(id,author_id,title,body,created_at) VALUES(?,?,?,?,?)').run('export-post-'+i,owners[i],'Fixture post '+i,'Fixture body','2026-10-10T00:00:00Z');
  sqlite.prepare('INSERT INTO community_comments(id,post_id,author_id,body,created_at) VALUES(?,?,?,?,?)').run('export-comment-'+i,'export-post-'+i,owners[i],'Fixture reply','2026-10-10T00:00:00Z');
 }
 // The existing feedback rows are soft-deleted: exports must still include the owner's data only.
 for(let i=0;i<owners.length;i++){
  sqlite.prepare('INSERT INTO study_protocols(id,user_id,question,rules_json,baseline_rule,created_at) VALUES(?,?,?,?,?,?)').run('study-'+owners[i],owners[i],'fixture','{}','fixture','2026-10-09T00:00:00Z');
 sqlite.prepare('INSERT INTO study_days(id,protocol_id,day_number,seoul_date,sessions_json,total_minutes,created_at) VALUES(?,?,?,?,?,?,?)').run('study-day-'+owners[i],'study-'+owners[i],1,'2026-10-09','[1]',1,'2026-10-09T00:00:00Z');
 const owned=sqlite.prepare('SELECT id FROM feedback WHERE user_id=?').get(owners[i]);
  sqlite.prepare('INSERT INTO feedback_events(id,feedback_id,actor_id,action,reason,created_at) VALUES(?,?,?,?,?,?)').run('account-event-'+owners[i],owned.id,owners[i],'fixture','fixture','fixture');
  const response=await accountRoute.GET(req(current[i],undefined,url));assert.equal(response.status,200);const data=await response.json();
  assert.equal(data.profile.username,'export_user_'+i);assert.deepEqual(data.community_posts.map(p=>p.id),['export-post-'+i]);assert.deepEqual(data.community_comments.map(c=>c.id),['export-comment-'+i]);
  const expected=await (await route.GET(req(current[i]))).json();for(const name of names)assert.deepEqual(data[name],expected[name],name);
  assert.equal(data.study_protocols.length,1);assert.equal(data.study_protocols[0].user_id,owners[i]);assert.equal(data.study_days.length,1);assert.equal(data.study_days[0].protocol_id,'study-'+owners[i]);assert.ok(data.feedback.length>=1);for(const item of data.feedback)assert.equal(item.user_id,owners[i]);
  assert.equal(data.experience.length,1);assert.deepEqual(data.experience,JSON.parse(JSON.stringify(sqlite.prepare('SELECT preferences,automatic,version,updated_at FROM ui_preferences WHERE user_id=?').all(owners[i]))));assert.ok(data.experience_changes.length>=1);assert.deepEqual(data.experience_changes,JSON.parse(JSON.stringify(sqlite.prepare('SELECT id,feedback_id,before_json,after_json,created_at FROM ui_changes WHERE user_id=?').all(owners[i]))));assert.equal(data.feedback_events.length,1);assert.equal(data.feedback_events[0].actor_id,owners[i]);
  assert.equal((await accountRoute.GET(req(current[i],undefined,url+'?audit=1'))).status,403);
 }
 const allTables=[...names,'feedback','feedback_events','diary_sessions','diary_accounts','diary_audit','ui_preferences','ui_changes','study_protocols','study_days','diary_profiles','community_posts','community_comments'];
 const allRows=()=>Object.fromEntries(allTables.map(name=>[name,sqlite.prepare(`SELECT * FROM ${name} ORDER BY 1`).all()]));
 const remove=(cookie,confirmation)=>accountRoute.DELETE(new Request(url,{method:'DELETE',headers:{cookie,origin:'https://diary.example.test','content-type':'application/json'},body:JSON.stringify({confirmation,user_id:owners[1]})}));
 const before=allRows();assert.equal((await remove(current[0],'wrong')).status,400);assert.deepEqual(allRows(),before);
 const otherBefore=await (await accountRoute.GET(req(current[1],undefined,url))).json();delete otherBefore.exported_at;
 assert.equal((await remove(current[0],'삭제')).status,200);
 const erased=sqlite.prepare('SELECT email,deleted_at FROM diary_accounts WHERE id=?').get(owners[0]);assert.equal(erased.email,null);assert.ok(erased.deleted_at);assert.equal(sqlite.prepare('SELECT count(*) n FROM diary_sessions WHERE user_id=?').get(owners[0]).n,0);assert.equal(sqlite.prepare('SELECT count(*) n FROM study_days WHERE protocol_id=?').get('study-'+owners[0]).n,0);
 globalThis.authTestProvider={auth:{signInWithPassword:async()=>({error:null,data:{session:{access_token:'synthetic-deleted-token'}}}),getUser:async()=>({error:null,data:{user:{id:owners[0],email:owners[0]+'@example.test',email_confirmed_at:'fixture'}}})}};assert.equal((await authRoute.POST(req('',{action:'login',email:owners[0]+'@example.test',password:'Synthetic-deleted-test-123'},'https://diary.example.test/api/auth'))).status,403);delete globalThis.authTestProvider;
 assert.equal((await route.GET(req(current[0]))).status,401);assert.equal((await route.GET(req(cookies[0]))).status,401);
 for(const name of ['community_posts','community_comments'])assert.equal(sqlite.prepare(`SELECT count(*) n FROM ${name} WHERE author_id=?`).get(owners[0]).n,0);
 for(const name of ['ui_preferences','ui_changes','study_protocols','diary_profiles'])assert.equal(sqlite.prepare(`SELECT count(*) n FROM ${name} WHERE user_id=?`).get(owners[0]).n,0);
 for(const name of ['plans','feedback'])assert.equal(sqlite.prepare(`SELECT count(*) n FROM ${name} WHERE ${name==='plans'?'owner_id':'user_id'}=?`).get(owners[0]).n,0);
 for(const name of ['tasks','plan_versions','reviews'])assert.equal(sqlite.prepare(`SELECT count(*) n FROM ${name} WHERE plan_id=?`).get('plan-'+owners[0]).n,0);
 for(const name of ['executions','completion_events'])assert.equal(sqlite.prepare(`SELECT count(*) n FROM ${name} WHERE task_id=?`).get('task-'+owners[0]).n,0);
 assert.equal(sqlite.prepare('SELECT count(*) n FROM feedback_events WHERE actor_id=?').get(owners[0]).n,0);
 const otherAfter=await (await accountRoute.GET(req(current[1],undefined,url))).json();delete otherAfter.exported_at;assert.deepEqual(otherAfter,otherBefore);
 assert.equal(sqlite.prepare('SELECT count(*) n FROM plans WHERE id=?').get('legacy').n,1);
});
await check('Social login rejects foreign origins, disabled providers, unsupported names, and forged or expired callbacks',async()=>{
 globalThis.socialTestAvailability={google:false,kakao:false};
 const url='https://diary.example.test/api/auth/social';
 assert.equal((await socialRoute.POST(req('',{provider:'google'},url,{origin:'https://attacker.example.test'}))).status,403);
 assert.equal((await socialRoute.POST(req('',{provider:'unknown'},url))).status,400);
 assert.equal((await socialRoute.POST(req('',{provider:'google'},url))).status,503);
 const rejected=await socialCallback.GET(new Request('https://diary.example.test/auth/social/callback?code=forged&attempt=forged'));assert.equal(new URL(rejected.headers.get('Location')).searchParams.get('social_error'),'1');assert.ok(!rejected.headers.get('Set-Cookie').includes('__Host-pds-session'));
 const expired={state:crypto.randomUUID(),provider:'google',created:Date.now()-600001,verifiers:{'fixture-code-verifier':'verifier'}};
 assert.equal(oauthFlow.readFlow(new Request(url,{headers:{cookie:oauthFlow.cookie(JSON.stringify(expired)).split(';')[0]}})),null);
});
await check('Social login binds PKCE to this browser and issues only a provider-verified app session',async()=>{
 globalThis.socialTestAvailability={google:true,kakao:true};
 globalThis.socialTestProvider=storage=>({auth:{signInWithOAuth:async()=>{storage.setItem('fixture-code-verifier','verifier');return {error:null,data:{url:'https://fixture.supabase.co/auth/v1/authorize?provider=google'}};},exchangeCodeForSession:async()=>({error:null,data:{session:{access_token:'social-synthetic-test-token'}}}),getUser:async()=>({error:null,data:{user:{id:'social-qa-owner',email:'social-qa-owner@example.test',email_confirmed_at:'fixture'}}}),signOut:async()=>({error:null})}});
 const start=await socialRoute.POST(req('',{provider:'google'},'https://diary.example.test/api/auth/social'));assert.equal(start.status,200);
 const flowHeader=start.headers.get('Set-Cookie');assert.ok(flowHeader.includes('HttpOnly')&&flowHeader.includes('Secure')&&flowHeader.includes('SameSite=Lax'));assert.ok(!flowHeader.includes('social-synthetic-test-token'));
 const flowCookie=flowHeader.split(';')[0],flow=oauthFlow.readFlow(new Request('https://diary.example.test',{headers:{cookie:flowCookie}}));
 const bad=await socialCallback.GET(new Request('https://diary.example.test/auth/social/callback?code=fixture&attempt=wrong',{headers:{cookie:flowCookie}}));assert.ok(!bad.headers.get('Set-Cookie').includes('__Host-pds-session'));
 const result=await socialCallback.GET(new Request('https://diary.example.test/auth/social/callback?code=fixture&attempt='+flow.state,{headers:{cookie:flowCookie}}));assert.equal(result.status,303);assert.equal(new URL(result.headers.get('Location')).search,'');assert.ok(result.headers.get('Set-Cookie').includes('__Host-pds-session'));assert.ok(!result.headers.get('Set-Cookie').includes('social-synthetic-test-token'));
 delete globalThis.socialTestAvailability;delete globalThis.socialTestProvider;
});


const recoveryRoute=await import(moduleURL(path.join(root,'app/api/auth/recovery/route.ts')));
const recoveryFlow=await import(moduleURL(path.join(root,'lib/recovery-flow.ts')));
const recoveryURL='https://diary.example.test/api/auth/recovery';
let recoveryRequestNumber=0;
const recoveryPOST=(cookie,body,extra={})=>recoveryRoute.POST(req(cookie,body,recoveryURL,{'cf-connecting-ip':'synthetic-recovery-ip-'+(++recoveryRequestNumber),...extra}));
const recoveryGET=cookie=>recoveryRoute.GET(req(cookie,undefined,recoveryURL));
function responseCookies(response){return (response.headers.getSetCookie?.()||[response.headers.get('set-cookie')||'']).flatMap(value=>value.split(/,(?=\s*__Host-)/)).map(value=>value.trim().split(';')[0]).filter(Boolean);}
const cookieJar=(current,response)=>{
 const values=new Map(current.split(';').map(v=>v.trim()).filter(Boolean).map(v=>{const at=v.indexOf('=');return [v.slice(0,at),v.slice(at+1)];}));
 for(const cookie of responseCookies(response)){const at=cookie.indexOf('=');values.set(cookie.slice(0,at),cookie.slice(at+1));}
 return [...values].filter(([,value])=>value).map(([name,value])=>name+'='+value).join('; ');
};
function recoveryProvider(user,options={}){
 const calls={exchange:0,updates:0,restores:0,signOut:0};let consumed=false;
 const session={access_token:'synthetic-recovery-access-token',refresh_token:'synthetic-recovery-refresh-token',expires_at:Math.floor(Date.now()/1000)+3600,user};
 globalThis.socialTestProvider=storage=>({auth:{
  resetPasswordForEmail:async(_email,redirect)=>{assert.equal(new URL(redirect.redirectTo).pathname,'/auth/recovery');storage.setItem('fixture-code-verifier',JSON.stringify('synthetic-verifier/recovery'));if(options.flowId){storage.setItem('fixture-flow-'+options.flowId+'-code-verifier',JSON.stringify('synthetic-verifier/recovery'));storage.setItem('fixture-flows-code-verifier',JSON.stringify([options.flowId]));}return {error:options.deliveryError?{code:'email_address_not_authorized',message:'private SMTP detail'}:null};},
  exchangeCodeForSession:async (code,flow)=>{calls.exchange++;if(options.flowId)assert.equal(flow?.flowId,options.flowId);if(code!=='synthetic-one-use-code'||consumed)return {error:{code:'flow_state_not_found',message:'private provider detail'},data:{session:null}};consumed=true;return {error:null,data:{session,user,redirectType:'recovery'}};},
  setSession:async tokens=>{calls.restores++;assert.equal(tokens.access_token,session.access_token);assert.equal(tokens.refresh_token,session.refresh_token);if(options.rotateTokens){session.access_token='synthetic-rotated-access-'+calls.restores;session.refresh_token='synthetic-rotated-refresh-'+calls.restores;}return {error:null,data:{session,user}};},
  getUser:async()=>({error:null,data:{user}}),
  updateUser:async input=>{calls.updates++;const code=options.passwordError?.(input.password);return {error:code?{code,message:'private password provider detail'}:null,data:{user}};},
  signOut:async()=>{calls.signOut++;if(options.signOutThrows)throw Error('synthetic cleanup unavailable');return {error:null};}
 }});
 return calls;
}
async function requestRecovery(email){const response=await recoveryPOST('',{action:'request',email});assert.equal(response.status,200);return {response,cookie:cookieJar('',response)};}
async function prepareRecovery(email){const started=await requestRecovery(email);const prepared=await recoveryPOST(started.cookie,{action:'prepare',code:'synthetic-one-use-code'});assert.equal(prepared.status,200);const data=await prepared.json();assert.equal(data.ready,true);assert.ok(Number.isFinite(data.expires_at));return {cookie:cookieJar(started.cookie,prepared),started,prepared,data};}
await check('Recovery hides account existence and SMTP details; missing cookies, foreign origins and short passwords rejected',async()=>{
 const user={id:'recovery-delivery-qa',email:'delivery@example.test',email_confirmed_at:'fixture'};recoveryProvider(user);
 const start=await requestRecovery(user.email);const notice=await start.response.json();
 recoveryProvider(user,{deliveryError:true});const failure=await requestRecovery('unknown-delivery@example.test');assert.deepEqual(await failure.response.json(),notice);assert.ok(!JSON.stringify(notice).includes('private SMTP detail'));
 assert.equal((await recoveryPOST('',{action:'request',email:user.email},{origin:'https://evil.example.test'})).status,403);
 assert.equal((await recoveryPOST('',{action:'prepare',code:'synthetic-one-use-code'})).status,401);
 assert.equal((await recoveryPOST('',{action:'reset',new_password:'Cc!12345'})).status,401);
 assert.equal((await recoveryPOST(start.cookie,{action:'prepare',code:'synthetic-one-use-code'},{origin:'https://evil.example.test'})).status,403);
});
await check('Recovery prepare exchanges once, encrypts tokens, survives refresh and resets without replaying URL code',async()=>{
 const user={id:'recovery-refresh-qa',email:'refresh-recovery@example.test',email_confirmed_at:'fixture'};sqlite.prepare('INSERT INTO diary_accounts(id,created_at) VALUES(?,?)').run(user.id,Date.now());
 const first=await auth.issueSession(db,user),second=await auth.issueSession(db,user);const calls=recoveryProvider(user);const prepared=await prepareRecovery(user.email);
 assert.equal(calls.exchange,1);
 const header=prepared.prepared.headers.get('set-cookie');assert.ok(header.includes('HttpOnly')&&header.includes('Secure')&&header.includes('SameSite=Lax'));assert.ok(!header.includes('synthetic-recovery-access-token'));assert.ok(!header.includes('synthetic-recovery-refresh-token'));
 for(let refresh=0;refresh<2;refresh++){const status=await recoveryGET(prepared.cookie);assert.equal(status.status,200);assert.equal((await status.json()).ready,true);}
 assert.equal(calls.exchange,1);
 const repeated=await recoveryPOST(prepared.cookie,{action:'prepare',code:'synthetic-one-use-code'});assert.equal(repeated.status,200);assert.equal((await repeated.json()).ready,true);assert.equal(calls.exchange,1);
 assert.equal((await recoveryPOST(prepared.started.cookie,{action:'prepare',code:'synthetic-one-use-code'})).status,401);assert.equal(calls.exchange,1);
 assert.equal((await recoveryPOST(prepared.cookie,{action:'reset',new_password:'Cc!1234'})).status,400);assert.equal(calls.updates,0);
 const reset=await recoveryPOST(prepared.cookie,{action:'reset',new_password:'Cc!12345'});assert.equal(reset.status,200);assert.equal(calls.updates,1);assert.ok(calls.restores>=1);
 assert.equal((await route.GET(req(first.cookie.split(';')[0]))).status,401);assert.equal((await route.GET(req(second.cookie.split(';')[0]))).status,401);
 assert.equal((await recoveryPOST(prepared.cookie,{action:'reset',new_password:'Dd!12345'})).status,401);assert.equal(calls.updates,1);
 const resetText=JSON.stringify(await reset.json());assert.ok(!resetText.includes('synthetic-recovery-access-token'));assert.ok(!resetText.includes('synthetic-recovery-refresh-token'));
 for(const audit of sqlite.prepare('SELECT * FROM diary_audit').all())assert.ok(!JSON.stringify(audit).includes('Cc!12345'));
});
await check('Same-password and weak-password errors allow a corrected retry within the prepared session',async()=>{
 const user={id:'recovery-retry-qa',email:'retry-recovery@example.test',email_confirmed_at:'fixture'};sqlite.prepare('INSERT INTO diary_accounts(id,created_at) VALUES(?,?)').run(user.id,Date.now());
 const calls=recoveryProvider(user,{rotateTokens:true,passwordError:password=>password==='Same!12345'?'same_password':password==='Weak!12345'?'weak_password':null});const prepared=await prepareRecovery(user.email);let retryCookie=prepared.cookie;
 for(const password of ['Same!12345','Weak!12345']){const failure=await recoveryPOST(retryCookie,{action:'reset',new_password:password});assert.equal(failure.status,400);retryCookie=cookieJar(retryCookie,failure);const failureData=await failure.json();assert.equal(failureData.retryable,true);assert.ok(!JSON.stringify(failureData).includes('private password provider detail'));const status=await recoveryGET(retryCookie);assert.equal(status.status,200);assert.equal((await status.json()).ready,true);}
 assert.equal((await recoveryPOST(retryCookie,{action:'reset',new_password:'Correct!12345'})).status,200);assert.equal(calls.updates,3);assert.equal(calls.exchange,1);
});
await check('Successful password reset remains successful when provider cleanup throws',async()=>{
 const user={id:'recovery-cleanup-qa',email:'cleanup-recovery@example.test',email_confirmed_at:'fixture'};sqlite.prepare('INSERT INTO diary_accounts(id,created_at) VALUES(?,?)').run(user.id,Date.now());
 const calls=recoveryProvider(user,{signOutThrows:true});const prepared=await prepareRecovery(user.email);const reset=await recoveryPOST(prepared.cookie,{action:'reset',new_password:'Cleanup!12345'});assert.equal(reset.status,200);assert.equal(calls.updates,1);assert.ok(calls.signOut>=1);assert.ok(!JSON.stringify(await reset.json()).includes('cleanup unavailable'));
});
await check('Encrypted recovery session rejects cookie tampering, exact expiry and successful-session replay',async()=>{
 const user={id:'recovery-tamper-qa',email:'tamper-recovery@example.test',email_confirmed_at:'fixture'};sqlite.prepare('INSERT INTO diary_accounts(id,created_at) VALUES(?,?)').run(user.id,Date.now());
 const calls=recoveryProvider(user);const prepared=await prepareRecovery(user.email);
 const pairs=prepared.cookie.split(';').map(value=>value.trim());const protectedPair=pairs.find(value=>!value.startsWith(recoveryFlow.recoveryCookieName+'='));assert.ok(protectedPair);
 const equal=protectedPair.indexOf('='),token=protectedPair.slice(equal+1),at=Math.floor(token.length/2),tampered=token.slice(0,at)+(token[at]==='A'?'B':'A')+token.slice(at+1);const bad=pairs.map(value=>value===protectedPair?protectedPair.slice(0,equal+1)+tampered:value).join('; ');
 const tamperStatus=await recoveryGET(bad);assert.equal((await tamperStatus.json()).ready,false);assert.equal((await recoveryPOST(bad,{action:'reset',new_password:'Tamper!12345'})).status,401);assert.equal(calls.updates,0);
 const clock=Date.now;try{Date.now=()=>prepared.data.expires_at;const expired=await recoveryGET(prepared.cookie);assert.equal((await expired.json()).ready,false);assert.equal((await recoveryPOST(prepared.cookie,{action:'reset',new_password:'Expiry!12345'})).status,401);}finally{Date.now=clock;}
 assert.equal(calls.updates,0);assert.equal((await recoveryPOST(prepared.cookie,{action:'reset',new_password:'Valid!12345'})).status,200);assert.equal((await recoveryGET(prepared.cookie)).status,200);assert.equal((await (await recoveryGET(prepared.cookie)).json()).ready,false);assert.equal((await recoveryPOST(prepared.cookie,{action:'reset',new_password:'Replay!12345'})).status,401);assert.equal(calls.updates,1);
});
await check('Missing encryption key and malformed or unmatched flow IDs do not consume a valid PKCE claim',async()=>{
 const user={id:'recovery-config-qa',email:'config-recovery@example.test',email_confirmed_at:'fixture'},flowId='a'.repeat(32);sqlite.prepare('INSERT INTO diary_accounts(id,created_at) VALUES(?,?)').run(user.id,Date.now());const calls=recoveryProvider(user,{flowId});const started=await requestRecovery(user.email);
 const prepare=id=>recoveryPOST(started.cookie,{action:'prepare',code:'synthetic-one-use-code',flow_id:id});
 const key=globalThis.authTestEnvironment.RECOVERY_SESSION_KEY;try{globalThis.authTestEnvironment.RECOVERY_SESSION_KEY='';assert.equal((await prepare(flowId)).status,503);}finally{globalThis.authTestEnvironment.RECOVERY_SESSION_KEY=key;}
 for(const invalid of [null,'','tiny','a'.repeat(65),'b'.repeat(32),'invalid!flow'])assert.equal((await prepare(invalid)).status,401);assert.equal(calls.exchange,0);
 const success=await prepare(flowId);assert.equal(success.status,200);assert.equal(calls.exchange,1);
});
await check('Requesting a new recovery link invalidates the old prepared session and clears its cookie',async()=>{
 const user={id:'recovery-new-link-qa',email:'new-link-recovery@example.test',email_confirmed_at:'fixture'};sqlite.prepare('INSERT INTO diary_accounts(id,created_at) VALUES(?,?)').run(user.id,Date.now());const calls=recoveryProvider(user);const prepared=await prepareRecovery(user.email);
 const request=await recoveryPOST(prepared.cookie,{action:'request',email:user.email});assert.equal(request.status,200);const nextCookie=cookieJar(prepared.cookie,request);assert.ok(!nextCookie.includes('__Host-pds-recovery-session='));assert.equal((await (await recoveryGET(prepared.cookie)).json()).ready,false);assert.equal((await recoveryPOST(prepared.cookie,{action:'reset',new_password:'Previous!12345'})).status,401);assert.equal(calls.updates,0);
});
await check('Installed SDK recovery storage is accepted; invalid codes stay private and delivery rate limits apply',async()=>{
 const {createClient}=await import('@supabase/supabase-js');const storage=oauthFlow.memoryStorage();
 const client=createClient('https://fixture.supabase.co','fixture-public-key',{auth:{storage,persistSession:true,autoRefreshToken:false,detectSessionInUrl:false,flowType:'pkce'},global:{fetch:async()=>new Response('{}',{status:200,headers:{'content-type':'application/json'}})}});
 await client.auth.resetPasswordForEmail('fixture@example.test',{redirectTo:'https://diary.example.test/auth/recovery'});
 const flow={nonce:crypto.randomUUID(),created:Date.now(),verifiers:oauthFlow.verifierSlots(storage.values)};assert.ok(recoveryFlow.readRecovery(req(recoveryFlow.recoveryCookie(JSON.stringify(flow)).split(';')[0])));
 const user={id:'recovery-invalid-qa',email:'invalid-recovery@example.test',email_confirmed_at:'fixture'};recoveryProvider(user);const start=await requestRecovery(user.email);
 const invalid=await recoveryPOST(start.cookie,{action:'prepare',code:'invalid'});assert.equal(invalid.status,401);assert.ok(!JSON.stringify(await invalid.json()).includes('private provider detail'));
 let limited=false;for(let n=0;n<6;n++){const response=await recoveryPOST('',{action:'request',email:'rate-recovery@example.test'});if(response.status===429){limited=true;break;}}assert.equal(limited,true);
 delete globalThis.socialTestProvider;
});
const report={tested_at:new Date().toISOString(),scope:'Real PDS, feedback, account and auth routes + local session helper, in-memory SQLite. Auth provider response mocked; Supabase network and live D1 not exercised.',checks};
const output=path.resolve(root,'../../task07/qa/auth-route-results.json');fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');
sqlite.close();delete globalThis.authTestDatabase;delete globalThis.authTestEnvironment;
