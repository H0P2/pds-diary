import ts from 'typescript';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';

// Real route/session code, in-memory synthetic DB only. No operating account or network.
const root=path.resolve(import.meta.dirname,'..'),sqlite=new DatabaseSync(':memory:');
sqlite.exec('PRAGMA foreign_keys=ON');
for(const name of fs.readdirSync(path.join(root,'drizzle')).filter(name=>/^0.*\.sql$/.test(name)).sort())sqlite.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));
let failBatch=false,failDeletionAudit=false,guardPostBatch=false,postBatchPhase=false,blockedPostBatchQueries=0;
function statement(sql,params=[]){const item=sqlite.prepare(sql);const validate=()=>{if(failDeletionAudit&&sql.startsWith('INSERT INTO diary_audit'))throw Error('Synthetic audit statement failure');};return {bind:(...args)=>statement(sql,args),first:async()=>{validate();return item.get(...params)||null;},all:async()=>{validate();return item.columns().length?{results:item.all(...params)}:{results:[],meta:{changes:Number(item.run(...params).changes)}};},run:async()=>{validate();return {meta:{changes:Number(item.run(...params).changes)}};}};}
const db={prepare:sql=>{if(guardPostBatch&&postBatchPhase){blockedPostBatchQueries++;throw Error('Synthetic post-commit DB unavailable');}return statement(sql);},batch:async statements=>{sqlite.exec('BEGIN');try{const result=[];for(const item of statements){result.push(await item.all());if(failBatch&&result.length===3)throw Error('Synthetic batch failure');}sqlite.exec('COMMIT');if(guardPostBatch)postBatchPhase=true;return result;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
globalThis.accountRemainingDatabase=db;
const urls=new Map();
function moduleURL(filename){filename=path.resolve(filename);if(urls.has(filename))return urls.get(filename);let source=fs.readFileSync(filename,'utf8').replace(/import\s*\{\s*database\s*\}\s*from\s*["']@\/db\/raw["'];?/g,'const database=()=>globalThis.accountRemainingDatabase;');source=source.replace(/(from\s*["'])(@\/[^"']+|\.[^"']+)(["'])/g,(_all,before,spec,after)=>{let target=spec.startsWith('@/')?path.join(root,spec.slice(2)):path.resolve(path.dirname(filename),spec);if(!path.extname(target))target+='.ts';return before+moduleURL(target)+after;});const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;const url='data:text/javascript;base64,'+Buffer.from(compiled).toString('base64');urls.set(filename,url);return url;}
const auth=await import(moduleURL(path.join(root,'lib/auth.ts'))),route=await import(moduleURL(path.join(root,'app/api/account/route.ts')));
const users=['synthetic-delete-a','synthetic-delete-b'],instant='2026-10-10T00:00:00Z';
for(const id of users){
 sqlite.prepare('INSERT INTO diary_accounts(id,email,created_at) VALUES(?,?,?)').run(id,id+'@example.test',Date.now());
 sqlite.prepare('INSERT INTO plans(id,owner_id,title,start_date,end_date,priority,success,estimated_minutes,created_at) VALUES(?,?,?,?,?,?,?,?,?)').run('plan-'+id,id,'Synthetic','2026-10-10','2026-10-10',2,'Synthetic',0,instant);
 sqlite.prepare('INSERT INTO tasks(id,plan_id,title,due_date,priority,tags,estimated_minutes,created_at) VALUES(?,?,?,?,?,?,?,?)').run('task-'+id,'plan-'+id,'Synthetic','2026-10-10',2,'',0,instant);
 sqlite.prepare('INSERT INTO executions VALUES(?,?,?,?,?,?,?,?)').run('execution-'+id,'task-'+id,instant,instant,0,'','key-'+id,instant);
 sqlite.prepare('INSERT INTO completion_events VALUES(?,?,?,?)').run('completion-'+id,'task-'+id,0,instant);
 sqlite.prepare('INSERT INTO reviews VALUES(?,?,?,?,?,?,?)').run('review-'+id,'plan-'+id,'2026-10-10','2026-10-10','Synthetic','{}',instant);
 sqlite.prepare('INSERT INTO plan_versions VALUES(?,?,?,?,?)').run('version-'+id,'plan-'+id,1,'{}',instant);
 sqlite.prepare('INSERT INTO diary_profiles(user_id,username,display_name,bio) VALUES(?,?,?,?)').run(id,id.replaceAll('-','_'),'Synthetic','');
 sqlite.prepare('INSERT INTO community_posts(id,author_id,title,body,created_at) VALUES(?,?,?,?,?)').run('post-'+id,id,'Synthetic','Synthetic',instant);
 sqlite.prepare('INSERT INTO study_protocols(id,user_id,question,rules_json,baseline_rule,created_at) VALUES(?,?,?,?,?,?)').run('study-'+id,id,'Synthetic','{}','Synthetic',instant);
 sqlite.prepare('INSERT INTO study_days(id,protocol_id,day_number,seoul_date,sessions_json,total_minutes,created_at) VALUES(?,?,?,?,?,?,?)').run('day-'+id,'study-'+id,1,'2026-10-10','[0]',0,instant);
 sqlite.prepare('INSERT INTO feedback(id,user_id,category,screen,problem,suggestion,status,priority,group_key,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)').run('feedback-'+id,id,'ux','Synthetic','Synthetic','','received','normal','Synthetic',instant,instant);
 sqlite.prepare('INSERT INTO ui_preferences(user_id,updated_at) VALUES(?,?)').run(id,instant);
 sqlite.prepare('INSERT INTO ui_changes(id,user_id,before_json,after_json,created_at) VALUES(?,?,?,?,?)').run('change-'+id,id,'{}','{}',instant);
 sqlite.prepare('INSERT INTO diary_audit(id,account_id,event,success,created_at,email) VALUES(?,?,?,?,?,?)').run('audit-'+id,null,'signup',1,Date.now(),id+'@example.test');
}
// Important boundaries absent from the original auth suite: cross-author comments/review actor.
sqlite.prepare('INSERT INTO community_comments(id,post_id,author_id,body,created_at) VALUES(?,?,?,?,?)').run('b-on-a','post-'+users[0],users[1],'Synthetic reply',instant);
sqlite.prepare('INSERT INTO community_comments(id,post_id,author_id,body,created_at) VALUES(?,?,?,?,?)').run('a-on-b','post-'+users[1],users[0],'Synthetic reply',instant);
sqlite.prepare('INSERT INTO community_comments(id,post_id,author_id,body,created_at) VALUES(?,?,?,?,?)').run('b-on-b','post-'+users[1],users[1],'Synthetic own reply',instant);
sqlite.prepare('INSERT INTO feedback_events(id,feedback_id,actor_id,action,reason,created_at) VALUES(?,?,?,?,?,?)').run('a-reviews-b','feedback-'+users[1],users[0],'review_updated','Synthetic',instant);
const sessions=await Promise.all(users.map(id=>auth.issueSession(db,{id,email:id+'@example.test',email_confirmed_at:'synthetic'}))),cookies=sessions.map(s=>s.cookie.split(';')[0]);
const url='https://diary.example.test/api/account';
const request=(cookie,body,extra={})=>new Request(url,{method:'DELETE',headers:{cookie,origin:'https://diary.example.test','content-type':'application/json',...extra},body});
const tables=['plans','tasks','executions','completion_events','reviews','plan_versions','diary_accounts','diary_sessions','diary_audit','diary_profiles','community_posts','community_comments','study_protocols','study_days','feedback','feedback_events','ui_preferences','ui_changes'];
const state=()=>Object.fromEntries(tables.map(table=>[table,sqlite.prepare(`SELECT * FROM ${table} ORDER BY 1`).all()]));
const checks=[];async function check(label,fn){await fn();checks.push(label);console.log('PASS:',label);}
await check('Anonymous/origin/confirmation/JSON/type/stream-size failures preserve every row',async()=>{
 const before=state(),good=JSON.stringify({confirmation:'삭제'});
 for(const [cookie,body,extra,status] of [['',good,{},401],[cookies[0],good,{origin:'https://evil.example.test'},403],[cookies[0],JSON.stringify({confirmation:'wrong'}),{},400],[cookies[0],'{',{},400],[cookies[0],good,{'content-type':'text/plain'},415],[cookies[0],JSON.stringify({confirmation:'삭제',padding:'x'.repeat(600)}),{},413]]){assert.equal((await route.DELETE(request(cookie,body,extra))).status,status);assert.deepEqual(state(),before);}
});
await check('Simulated failure inside deletion batch rolls back all rows and leaves session active',async()=>{
 const before=state();failBatch=true;const response=await route.DELETE(request(cookies[0],JSON.stringify({confirmation:'삭제'})));failBatch=false;
 assert.equal(response.status,503);assert.deepEqual(state(),before);assert.ok(await auth.authenticate(db,new Request(url,{headers:{cookie:cookies[0]}})));
});
await check('Anonymous deletion audit failure rolls back deletion with no personal audit fields added',async()=>{
 const before=state();failDeletionAudit=true;const response=await route.DELETE(request(cookies[0],JSON.stringify({confirmation:'삭제'})));failDeletionAudit=false;
 assert.equal(response.status,503);assert.deepEqual(state(),before);assert.ok(await auth.authenticate(db,new Request(url,{headers:{cookie:cookies[0]}})));
});
await check('Owner deletion erases own full data and email-only signup audit; other independent data remains',async()=>{
 const bBefore=await (await route.GET(new Request(url,{headers:{cookie:cookies[1]}}))).json();delete bBefore.exported_at;
 guardPostBatch=true;const response=await route.DELETE(request(cookies[0],JSON.stringify({confirmation:'삭제',user_id:users[1]})));guardPostBatch=false;postBatchPhase=false;assert.equal(response.status,200);assert.equal(blockedPostBatchQueries,0);assert.match(response.headers.get('set-cookie'),/Max-Age=0/);
 const deletionAudit=sqlite.prepare("SELECT account_id,email FROM diary_audit WHERE event='account_delete'").all();assert.deepEqual(deletionAudit.map(row=>[row.account_id,row.email]),[[null,null]]);
 const erased=sqlite.prepare('SELECT * FROM diary_accounts WHERE id=?').get(users[0]);assert.equal(erased.email,null);assert.ok(erased.deleted_at);assert.equal(await auth.authenticate(db,new Request(url,{headers:{cookie:cookies[0]}})),null);
 for(const table of ['plans','tasks','executions','completion_events','reviews','plan_versions','diary_profiles','study_protocols','study_days','feedback','ui_preferences','ui_changes','community_posts'])assert.equal(sqlite.prepare(`SELECT COUNT(*) n FROM ${table} WHERE ${table==='diary_profiles'?'user_id':table==='ui_preferences'?'user_id':'id'}=?`).get(table==='diary_profiles'||table==='ui_preferences'?users[0]:({plans:'plan-',tasks:'task-',executions:'execution-',completion_events:'completion-',reviews:'review-',plan_versions:'version-',study_protocols:'study-',study_days:'day-',feedback:'feedback-',ui_changes:'change-',community_posts:'post-'}[table]+users[0])).n,0,table);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM diary_sessions WHERE user_id=?').get(users[0]).n,0);assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM diary_audit WHERE account_id=? OR email=?').get(users[0],users[0]+'@example.test').n,0);
 const bAfter=await (await route.GET(new Request(url,{headers:{cookie:cookies[1]}}))).json();delete bAfter.exported_at;
 bBefore.community_comments=bBefore.community_comments.filter(item=>item.id!=='b-on-a');assert.deepEqual(bAfter,bBefore);
 assert.equal((await route.DELETE(request(cookies[0],JSON.stringify({confirmation:'삭제'})))).status,401);
});
await check('Explicit boundaries: other reply on erased owner post is removed; foreign review actor UUID remains',async()=>{
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM community_comments WHERE id=?').get('b-on-a').n,0);assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM community_comments WHERE id=?').get('b-on-b').n,1);assert.equal(sqlite.prepare('SELECT actor_id FROM feedback_events WHERE id=?').get('a-reviews-b').actor_id,users[0]);
});
console.log(`PASS: ${checks.length} local synthetic account deletion checks. No provider/network/operating account; cross-comment and retained actor boundaries are documented, not full-isolation claims.`);
sqlite.close();delete globalThis.accountRemainingDatabase;
