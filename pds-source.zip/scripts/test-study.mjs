import ts from 'typescript';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
const root=path.resolve(import.meta.dirname,'..'),sqlite=new DatabaseSync(':memory:');
for(const name of fs.readdirSync(path.join(root,'drizzle')).filter(name=>/^0.*\.sql$/.test(name)).sort())sqlite.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));
function statement(sql,params=[]){const s=sqlite.prepare(sql);return {bind:(...args)=>statement(sql,args),first:async()=>s.get(...params)||null,all:async()=>s.columns().length?{results:s.all(...params)}:{results:[],meta:{changes:Number(s.run(...params).changes)}},run:async()=>({meta:{changes:Number(s.run(...params).changes)}})};}
const db={prepare:statement,batch:async statements=>{sqlite.exec('BEGIN');try{const results=[];for(const s of statements)results.push(await s.all());sqlite.exec('COMMIT');return results;}catch(e){sqlite.exec('ROLLBACK');throw e;}}};
globalThis.studyTestDatabase=db;
const urls=new Map();function moduleURL(filename){filename=path.resolve(filename);if(urls.has(filename))return urls.get(filename);let source=fs.readFileSync(filename,'utf8').replace(/import\s*\{\s*database\s*\}\s*from\s*["']@\/db\/raw["'];?/g,'const database=()=>globalThis.studyTestDatabase;');source=source.replace(/(from\s*["'])(@\/[^"']+|\.[^"']+)(["'])/g,(_all,before,spec,after)=>{let target=spec.startsWith('@/')?path.join(root,spec.slice(2)):path.resolve(path.dirname(filename),spec);if(!path.extname(target))target+='.ts';return before+moduleURL(target)+after;});const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText,url='data:text/javascript;base64,'+Buffer.from(compiled).toString('base64');urls.set(filename,url);return url;}
const auth=await import(moduleURL(path.join(root,'lib/auth.ts'))),route=await import(moduleURL(path.join(root,'app/api/study/route.ts'))),study=await import(moduleURL(path.join(root,'lib/study.ts')));
let clock=Date.parse('2026-10-08T15:00:00.001Z');const originalNow=Date.now;Date.now=()=>clock;
const owners=['fixture-study-a','fixture-study-b'];for(const id of owners)sqlite.prepare('INSERT INTO diary_accounts(id,created_at) VALUES(?,?)').run(id,clock);
async function cookie(owner){return (await auth.issueSession(db,{id:owner,email:owner+'@example.test',email_confirmed_at:'fixture'},clock)).cookie.split(';')[0];}
async function request(owner,input,origin='https://study.example.test'){return new Request('https://study.example.test/api/study',{method:input?'POST':'GET',headers:{cookie:owner?await cookie(owner):'',origin,'Content-Type':'application/json'},...(input?{body:JSON.stringify(input)}:{})});}
async function call(owner,input){const r=await route.POST(await request(owner,input));return {status:r.status,data:await r.json()};}
const get=async owner=>{const r=await route.GET(await request(owner));return {status:r.status,data:await r.json()};};
try{
 assert.equal(study.seoulDate(Date.parse('2026-10-08T14:59:59Z')),'2026-10-08');assert.equal(study.seoulDate(clock),'2026-10-09');assert.deepEqual(study.sessionMinutes([1/60,0.5]),[1/60,0.5]);const precise=study.studySummary([{day_number:1,total_minutes:1/60},{day_number:2,total_minutes:2/60}]);assert.equal(precise.before.seconds,3);assert.equal(precise.before.total,0.05);assert.equal(precise.before.mean,0.03);
 assert.equal((await get(null)).status,401);assert.equal((await call(null,{action:'record',sessions:[1]})).status,401);
 assert.equal((await route.POST(await request(owners[0],{action:'start',baseline_rule:'fixture',sessions:[1]},'https://foreign.example.test'))).status,403);
 assert.equal((await call(owners[0],{action:'start',baseline_rule:'fixture',sessions:[1],seoul_date:'2026-10-01'})).status,400);
 assert.equal((await call(owners[0],{action:'start',baseline_rule:'fixture',sessions:[1],user_id:owners[1]})).status,400);
 for(const sessions of [[-1],[1/120],[1441],[1000,500],[],['1']])assert.equal((await call(owners[0],{action:'start',baseline_rule:'fixture',sessions})).status,400);
 assert.equal((await call(owners[0],{action:'start',baseline_rule:'Fixture baseline action',sessions:[25,40],note:'Synthetic test data only'})).status,201);
 assert.equal((await call(owners[0],{action:'record',sessions:[10]})).status,409);
 assert.equal((await call(owners[0],{action:'change',changed_rule:'Fixture changed action',reason:'fixture'})).status,409);
 assert.equal((await get(owners[1])).data.protocol,null);
 clock+=86400000;assert.equal((await call(owners[0],{action:'record',sessions:[0]})).status,201);
 assert.equal((await call(owners[0],{action:'change',changed_rule:'Fixture baseline action',reason:'fixture'})).status,400);
 // Day3 blocked without a change, including a skipped calendar date.
 clock+=2*86400000;assert.equal((await call(owners[0],{action:'record',sessions:[120]})).status,409);
 const changed=await call(owners[0],{action:'change',changed_rule:'Fixture changed action',reason:'Fixture evidence from days 1 and 2'});assert.equal(changed.status,201);const refs=JSON.parse(changed.data.protocol.change_refs);assert.equal(refs.length,2);assert.deepEqual(refs.map(ref=>ref.total_minutes),[65,0]);assert.equal(changed.data.protocol.changed_at,new Date(clock).toISOString());
 assert.equal((await call(owners[0],{action:'change',changed_rule:'another',reason:'fixture'})).status,409);
 assert.equal((await call(owners[0],{action:'record',sessions:[120]})).status,409); // Must be strictly after the change timestamp.
 clock+=1;assert.equal((await call(owners[0],{action:'record',sessions:[120]})).status,201);
 clock+=86400000;assert.equal((await call(owners[0],{action:'record',sessions:[721]})).status,201);
 clock+=86400000;const completed=await call(owners[0],{action:'record',sessions:[1]});assert.equal(completed.status,201);const {summary,days}=completed.data;assert.equal(days.length,5);assert.equal(new Set(days.map(day=>day.seoul_date)).size,5);assert.equal(summary.complete,true);assert.equal(summary.before.total,65);assert.equal(summary.before.mean,32.5);assert.equal(summary.after.total,842);assert.equal(summary.after.mean,280.67);assert.equal(summary.difference,248.17);assert.equal(summary.all.count,5);assert.equal(summary.outliers.length,1);
 clock+=86400000;assert.equal((await call(owners[0],{action:'record',sessions:[1]})).status,409);
 const verify={action:'verify',before_total:65,before_mean:32.5,after_total:842,after_mean:280.67};assert.equal((await call(owners[0],{...verify,after_mean:280.66})).status,400);assert.equal((await call(owners[0],verify)).status,201);
 assert.equal((await get(owners[1])).data.days.length,0);assert.equal((await call(owners[1],{action:'record',sessions:[1]})).status,409);
 const unchanged=await get(owners[0]);assert.equal((await call(owners[1],{action:'verify',...verify})).status,409);assert.deepEqual((await get(owners[0])).data,unchanged.data);
 const preciseRoute=await call(owners[1],{action:'start',baseline_rule:'Fixture seconds baseline',sessions:[1/60,0.5]});assert.equal(preciseRoute.status,201);assert.equal(preciseRoute.data.summary.all.seconds,31);assert.equal(preciseRoute.data.days[0].total_minutes,31/60);
 sqlite.prepare('DELETE FROM study_days WHERE protocol_id IN (SELECT id FROM study_protocols WHERE user_id=?)').run(owners[0]);sqlite.prepare('DELETE FROM study_protocols WHERE user_id=?').run(owners[0]);assert.equal((await get(owners[0])).data.protocol,null);
 console.log('PASS: real study route with synthetic in-memory fixtures: auth, origin, owner isolation, Seoul boundary, no backdate, duplicate date, five-day cap, one timed rule change with two-day references, missing dates, zero and outlier treatment, raw-value rounding, hand calculation validation and deletion. No real usage records created.');
}finally{Date.now=originalNow;sqlite.close();delete globalThis.studyTestDatabase;}
