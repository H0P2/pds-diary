import ts from 'typescript';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
const root=path.resolve(import.meta.dirname,'..'),sqlite=new DatabaseSync(':memory:');
for(const name of fs.readdirSync(path.join(root,'drizzle')).filter(name=>/^0.*\.sql$/.test(name)).sort())sqlite.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));
function statement(sql,params=[]){const s=sqlite.prepare(sql);return {bind:(...args)=>statement(sql,args),first:async()=>s.get(...params)||null,all:async()=>({results:s.all(...params)}),run:async()=>({meta:{changes:Number(s.run(...params).changes)}})};}
const db={prepare:statement};globalThis.activityTestDatabase=db;
const urls=new Map();function moduleURL(filename){filename=path.resolve(filename);if(urls.has(filename))return urls.get(filename);let source=fs.readFileSync(filename,'utf8').replace(/import\s*\{\s*database\s*\}\s*from\s*["']@\/db\/raw["'];?/g,'const database=()=>globalThis.activityTestDatabase;');source=source.replace(/(from\s*["'])(@\/[^"']+|\.[^"']+)(["'])/g,(_all,before,spec,after)=>{let target=spec.startsWith('@/')?path.join(root,spec.slice(2)):path.resolve(path.dirname(filename),spec);if(!path.extname(target))target+='.ts';return before+moduleURL(target)+after;});const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText,url='data:text/javascript;base64,'+Buffer.from(compiled).toString('base64');urls.set(filename,url);return url;}
const auth=await import(moduleURL(path.join(root,'lib/auth.ts'))),route=await import(moduleURL(path.join(root,'app/api/study/activity/route.ts'))),{studyActivity}=await import(moduleURL(path.join(root,'lib/study-activity.ts')));
const originalNow=Date.now;let clock=Date.parse('2026-10-09T03:00:00Z');Date.now=()=>clock;
const owners=['activity-owner','activity-other','activity-admin'];
for(const owner of owners){sqlite.prepare('INSERT INTO diary_accounts(id,role,created_at) VALUES(?,?,?)').run(owner,owner.endsWith('admin')?'admin':'member',clock);sqlite.prepare('INSERT INTO plans(id,title,start_date,end_date,priority,success,estimated_minutes,created_at,owner_id) VALUES(?,?,?,?,?,?,?,?,?)').run(owner,'Synthetic fixture','2026-10-09','2026-10-09',1,'fixture',1,'fixture',owner);sqlite.prepare('INSERT INTO tasks(id,plan_id,title,due_date,priority,tags,estimated_minutes,created_at) VALUES(?,?,?,?,?,?,?,?)').run(owner,owner,'Synthetic fixture','2026-10-09',1,'',1,'fixture');}
async function get(owner,query=''){const cookie=owner?(await auth.issueSession(db,{id:owner,email:owner+'@example.test',email_confirmed_at:'fixture'},clock)).cookie.split(';')[0]:'';const response=await route.GET(new Request('https://activity.example.test/api/study/activity'+query,{headers:{cookie}}));assert.equal(response.headers.get('Cache-Control'),'private, no-store');return {status:response.status,data:await response.json()};}
let nextId=0;function execution(owner,start,end,cached=9999,created=new Date(clock).toISOString()){const id='fixture-'+String(nextId++).padStart(5,'0');sqlite.prepare('INSERT INTO executions(id,task_id,started_at,ended_at,actual_minutes,blocked_reason,request_key,created_at) VALUES(?,?,?,?,?,?,?,?)').run(id,owner,start,end,cached,'',id,created);}
const pair=(started_at,ended_at)=>({started_at,ended_at});
try{
 assert.equal((await get(null)).status,401);
 const empty=await get(owners[0]);assert.equal(empty.status,200);assert.deepEqual(empty.data.sessions,[]);assert.equal(empty.data.can_record,false);assert.equal(empty.data.source_count,0);assert.equal(empty.data.change_suggestion,null);
 execution(owners[1],'2026-10-09T00:00:00+09:00','2026-10-09T11:00:00+09:00');
 assert.equal((await get(owners[0],'?user_id='+owners[1])).data.seconds,0);assert.equal((await get(owners[2],'?owner_id='+owners[1])).data.seconds,0);
 execution(owners[0],'2026-10-08T23:59:30+09:00','2026-10-09T00:01:00+09:00'); // only today's 60 seconds
 execution(owners[0],'2026-10-08T15:00:30.000Z','2026-10-08T15:02:00Z'); // overlap adds 60 seconds
 execution(owners[0],'2026-10-09T01:00:00.000000+09:00','2026-10-09T01:00:01+09:00');
 execution(owners[0],'2026-10-08T10:00:00Z','2026-10-08T10:05:00Z'); // previous Seoul day
 for(const [start,end] of [['garbage','2026-10-09T01:00:00Z'],['2026-10-09T02:01:00Z','2026-10-09T02:00:00Z'],['2026-10-09T02:00:00Z','2026-10-09T04:00:00Z'],['2026-10-09T02:00:00','2026-10-09T02:01:00'],['2026-02-30T00:00:00Z','2026-10-09T00:00:00Z'],['2026-10-09T01:00:00Z','2026-10-09T01:00:00Z']])execution(owners[0],start,end);
 const actual=(await get(owners[0])).data;assert.equal(actual.today,'2026-10-09');assert.equal(actual.source_count,3);assert.equal(actual.seconds,121);assert.equal(actual.minutes,121/60);assert.deepEqual(actual.sessions,[2,1/60]);assert.equal(actual.can_record,true);assert(actual.notes.some(note=>note.includes('6건')));assert(actual.notes.some(note=>note.includes('1000')));
 const pure=studyActivity([pair('2026-10-08T14:59:59Z','2026-10-08T15:00:01Z')],Date.parse('2026-10-08T15:00:02Z'),null,[]);assert.equal(pure.today,'2026-10-09');assert.equal(pure.seconds,1);
 const before=studyActivity([pair('2026-10-08T14:59:58Z','2026-10-08T14:59:59Z')],Date.parse('2026-10-08T14:59:59.999Z'),null,[]);assert.equal(before.today,'2026-10-08');assert.equal(before.seconds,1);
 const multiday=studyActivity([pair('2026-10-07T00:00:00Z','2026-10-09T02:00:00Z')],clock,null,[]);assert.equal(multiday.seconds,11*3600);assert.deepEqual(multiday.sessions,[660]);
 assert.deepEqual(studyActivity([pair('2026-10-10T00:00:00Z','2026-10-10T00:01:00Z')],clock,null,[]).sessions,[]);
 // Canonical whole seconds remain accepted by study's precision rules.
 const {sessionMinutes}=await import(moduleURL(path.join(root,'lib/study.ts')));assert.deepEqual(sessionMinutes(actual.sessions),actual.sessions);
 sqlite.prepare('INSERT INTO study_protocols(id,user_id,question,rules_json,baseline_rule,created_at) VALUES(?,?,?,?,?,?)').run('study-fixture',owners[0],'fixture','{}','Fixture baseline','fixture');
 const addDay=(number,date,total)=>sqlite.prepare('INSERT INTO study_days(id,protocol_id,day_number,seoul_date,sessions_json,total_minutes,created_at) VALUES(?,?,?,?,?,?,?)').run('day-fixture-'+number,'study-fixture',number,date,JSON.stringify([total]),total,'fixture');
 addDay(1,'2026-10-06',12.5);assert.equal((await get(owners[0])).data.change_suggestion,null);
 addDay(2,'2026-10-08',25);const suggestion=(await get(owners[0])).data;assert.equal(suggestion.can_record,false);assert(suggestion.change_suggestion.reason.includes('2026-10-06 12.5분'));assert(suggestion.change_suggestion.reason.includes('2026-10-08 25분'));assert.equal(suggestion.baseline_suggestion,'Fixture baseline');
 assert.equal(sqlite.prepare('SELECT changed_at FROM study_protocols').get().changed_at,null);assert.equal(sqlite.prepare('SELECT COUNT(*) AS n FROM study_days').get().n,2); // GET never records or applies suggestions
 assert.equal((await get(owners[1])).data.change_suggestion,null);
 sqlite.prepare('UPDATE study_protocols SET changed_rule=?,changed_at=? WHERE id=?').run('Fixture changed',new Date(clock-1000).toISOString(),'study-fixture');assert.equal((await get(owners[0])).data.change_suggestion,null);assert.equal((await get(owners[0])).data.can_record,true);
 addDay(3,'2026-10-09',1);assert.equal((await get(owners[0])).data.can_record,false);
 assert.equal(studyActivity([pair('2026-10-09T00:00:00Z','2026-10-09T00:01:00Z')],clock,{baseline_rule:'fixture',changed_at:new Date(clock).toISOString()},[{seoul_date:'2026-10-07'},{seoul_date:'2026-10-08'}]).can_record,false);
 sqlite.prepare('DELETE FROM executions WHERE task_id=?').run(owners[0]);
 // Older valid entries outside latest 1000 are omitted, with the limit always disclosed.
 execution(owners[0],'2026-10-09T00:00:00Z','2026-10-09T00:01:00Z',1,'2000-01-01T00:00:00Z');
 for(let i=0;i<1000;i++)execution(owners[0],'invalid','invalid');
 const limited=(await get(owners[0])).data;assert.equal(limited.seconds,0);assert.deepEqual(limited.sessions,[]);assert.equal(limited.can_record,false);assert(limited.notes.some(note=>note.includes('1000')));
 const separated=Array.from({length:101},(_,i)=>pair(new Date(Date.parse('2026-10-09T00:00:00Z')+i*2000).toISOString(),new Date(Date.parse('2026-10-09T00:00:00Z')+i*2000+1000).toISOString()));assert.equal(studyActivity(separated,clock,null,[]).can_record,false);
 console.log('PASS: activity drafting, authenticated owner/admin isolation, offset formats, Seoul midnight splitting, overlap merge, factual timestamps over cached minutes, malformed/reversed/future exclusion, missing [] rather than zero usage, two-day factual suggestions without mutation, today eligibility and bounded scan. Synthetic in-memory fixtures only.');
}finally{Date.now=originalNow;sqlite.close();delete globalThis.activityTestDatabase;}
