"use client";
import {useEffect,useState} from "react";
import {ArrowRight,BookOpen,ChartNoAxesColumnIncreasing,LockKeyhole,Mail,MessageCircle,Play,Target} from "lucide-react";
import {Button} from "@/components/ui/button";
import {Input} from "@/components/ui/input";
import {SpatialScene} from "@/components/spatial-scene";
import {TiltSurface} from "@/components/tilt-surface";
export type AccountUser={id:string;email:string;role:string;username?:string|null;display_name?:string};
export function AuthPanel({onLogin}:{onLogin:(user:AccountUser)=>void}){
 const [mode,setMode]=useState<'login'|'signup'|'recovery'>('login'),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),[message,setMessage]=useState('');
 const [social,setSocial]=useState<{google:boolean;kakao:boolean}|null>(null);
 useEffect(()=>{let alive=true;if(new URLSearchParams(window.location.search).get('auth')==='recovery')queueMicrotask(()=>{if(alive)setMode('recovery');});fetch('/api/auth/social',{cache:'no-store'}).then(async r=>await r.json() as {google?:boolean;kakao?:boolean}).then((d:{google?:boolean;kakao?:boolean})=>{if(alive)setSocial({google:d.google===true,kakao:d.kakao===true});}).catch(()=>{if(alive)setSocial({google:false,kakao:false});});if(new URLSearchParams(window.location.search).has('social_error'))queueMicrotask(()=>{if(alive)setError('소셜 로그인을 완료하지 못했습니다. 다시 시도하거나 이메일로 로그인하세요.');});return()=>{alive=false;};},[]);
 async function socialLogin(name:'google'|'kakao'){if(busy)return;setBusy(true);setPassword('');setError('');try{const response=await fetch('/api/auth/social',{method:'POST',signal:AbortSignal.timeout(15000),headers:{'Content-Type':'application/json'},body:JSON.stringify({provider:name})});const data=await response.json() as {url?:string;error?:string};if(!response.ok||!data.url)throw Error(data.error||'로그인을 시작하지 못했습니다.');window.location.assign(data.url);}catch(e){setError(e instanceof Error?e.message:'로그인을 시작하지 못했습니다.');setBusy(false);}}
 async function submit(e:React.FormEvent){e.preventDefault();if(busy)return;setBusy(true);setError('');setMessage('');try{const r=await fetch(mode==='recovery'?'/api/auth/recovery':'/api/auth',{method:'POST',signal:AbortSignal.timeout(15000),headers:{'Content-Type':'application/json'},body:JSON.stringify({action:mode==='recovery'?'request':mode,...(mode==='login'?{identifier:email.trim()}:{email:email.trim()}),...(mode==='recovery'?{}:{password})})});const d=await r.json() as {user?:AccountUser;error?:string;message?:string};if(!r.ok)throw Error(d.error||'요청을 처리하지 못했습니다.');setPassword('');if(mode==='login'&&d.user)onLogin(d.user);else {if(mode!=='recovery')setMode('login');setMessage(d.message||'가입 가능한 이메일이면 인증 안내가 발송됩니다. 메일의 링크로 인증한 뒤 로그인하세요.');}}catch(e){setError(e instanceof Error&&e.name!=='TimeoutError'&&e.message!=='Failed to fetch'?e.message:'연결을 확인하고 다시 시도해주세요.');}finally{setBusy(false);}}
 return <main className="auth-page"><SpatialScene/><div className="auth-layout">
  <section className="auth-intro" aria-label="플랜두씨 소개">
   <div className="auth-brand"><span className="auth-brand-icon"><BookOpen size={24} aria-hidden="true"/></span><strong>플랜두씨</strong><span className="auth-brand-caption">PLAN · DO · SEE</span></div>
   <div className="auth-intro-copy"><p className="auth-eyebrow">나를 위한 작은 실행의 기록</p><h1>계획에서 실행으로.<br/>기록에서 <span>다음으로.</span></h1><p className="auth-intro-description">나만의 속도로, 오늘을 쌓아가세요.</p></div>
   <ol className="auth-steps"><li><span className="auth-step-icon"><Target size={23} aria-hidden="true"/></span><div><span className="auth-step-label">PLAN</span><h2>계획</h2></div></li><li><span className="auth-step-icon"><Play size={23} aria-hidden="true"/></span><div><span className="auth-step-label">DO</span><h2>실행</h2></div></li><li><span className="auth-step-icon"><ChartNoAxesColumnIncreasing size={23} aria-hidden="true"/></span><div><span className="auth-step-label">SEE</span><h2>회고</h2></div></li></ol>
  </section>
  <TiltSurface className="auth-card" maxTilt={3}><section aria-label="계정 로그인">
   <div className="auth-card-heading"><span className="auth-card-kicker">YOUR OWN DIARY</span><h2>{mode==='login'?'로그인':mode==='signup'?'회원가입':'비밀번호 찾기'}</h2><p>{mode==='login'?'나의 계획과 기록을 이어가세요.':mode==='signup'?'본인 이메일로 나만의 다이어리를 시작하세요.':'가입한 이메일로 재설정 링크를 요청하세요.'}</p></div>
   <form onSubmit={submit} className={`auth-form auth-form-${mode}`} aria-busy={busy}><div className="auth-entry-grid"><div className="auth-input-stack">
    <label className="auth-field" htmlFor="auth-email">{mode==='login'?'이메일 또는 아이디':'이메일'}<span className="auth-input-wrap"><Mail size={19} aria-hidden="true"/><Input id="auth-email" type={mode==='login'?'text':'email'} name={mode==='login'?'identifier':'email'} placeholder={mode==='login'?'이메일 주소 또는 설정한 아이디':'본인 이메일 주소'} autoComplete="username" autoCapitalize="none" spellCheck={false} value={email} onChange={e=>setEmail(e.target.value)} required maxLength={254}/></span></label>
    {mode!=='recovery'&&<label className="auth-field" htmlFor="auth-password">비밀번호<span className="auth-input-wrap"><LockKeyhole size={19} aria-hidden="true"/><Input id="auth-password" type="password" name="password" placeholder={mode==='login'?'비밀번호를 입력해주세요':'8자 이상으로 설정해주세요'} autoComplete={mode==='login'?'current-password':'new-password'} value={password} onChange={e=>setPassword(e.target.value)} required minLength={mode==='signup'?8:undefined} maxLength={128} aria-describedby={mode==='signup'?'auth-password-hint':undefined}/></span>{mode==='signup'&&<small id="auth-password-hint">이 앱 전용 비밀번호를 8자 이상으로 설정해주세요. 아이디는 이메일 인증 후 프로필 설정에서 만들 수 있어요.</small>}</label>}
    </div>
    <Button type="submit" disabled={busy} className="auth-submit">{busy?'처리 중…':mode==='login'?'로그인':mode==='signup'?'회원가입':'메일 보내기'}{!busy&&<ArrowRight size={18} aria-hidden="true"/>}</Button>
   </div>{error&&<p className="error" role="alert">{error}</p>}{message&&<p className="success" role="status">{message}</p>}</form>
   {mode==='login'&&<Button type="button" variant="ghost" disabled={busy} className="auth-switch" onClick={()=>{setMode('recovery');setPassword('');setError('');setMessage('');}}>비밀번호를 잊으셨나요?</Button>}
   {mode!=='recovery'&&<><div className="auth-social-divider"><span>또는 간편하게 시작하기</span></div>
   <div className="auth-social-buttons">
    <Button type="button" className="auth-social-google" disabled={busy||!social?.google} onClick={()=>void socialLogin('google')}><span>Google로 로그인</span>{social&&!social.google&&<small>연결 준비 중</small>}</Button>
    <Button type="button" className="auth-social-kakao" disabled={busy||!social?.kakao} onClick={()=>void socialLogin('kakao')}><MessageCircle size={20} fill="currentColor" aria-hidden="true"/><span>카카오로 로그인</span>{social&&!social.kakao&&<small>연결 준비 중</small>}</Button>
   </div>
   </>}<Button type="button" variant="ghost" disabled={busy} className="auth-switch" onClick={()=>{setMode(mode==='login'?'signup':'login');setPassword('');setError('');setMessage('');}}>{mode==='login'?<>처음이신가요? <strong>회원가입</strong></>:<>이미 가입하셨나요? <strong>로그인</strong></>}</Button>
   <p className="auth-privacy"><LockKeyhole size={16} aria-hidden="true"/><span>계획과 기록은 본인 계정에서만 확인할 수 있어요. 관리자는 가입 요청 이메일·시각·처리 결과를 확인할 수 있으며 비밀번호는 기록하지 않습니다.</span></p>
  </section></TiltSurface>
 </div></main>;
}
