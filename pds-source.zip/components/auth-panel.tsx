"use client";
import {useEffect,useState} from "react";
import {ArrowRight,BookOpen,Check,LockKeyhole} from "lucide-react";
import {Button} from "@/components/ui/button";
import {Input} from "@/components/ui/input";
import {TiltSurface} from "@/components/tilt-surface";
export type AccountUser={id:string;email:string;role:string};
export function AuthPanel({onLogin}:{onLogin:(user:AccountUser)=>void}){
 const [mode,setMode]=useState<'login'|'signup'>('login'),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),[message,setMessage]=useState('');
 const [social,setSocial]=useState<{google:boolean;kakao:boolean}|null>(null);
 useEffect(()=>{let alive=true;fetch('/api/auth/social',{cache:'no-store'}).then(r=>r.json()).then((d:any)=>{if(alive)setSocial({google:d.google===true,kakao:d.kakao===true});}).catch(()=>{if(alive)setSocial({google:false,kakao:false});});if(new URLSearchParams(window.location.search).has('social_error'))setError('소셜 로그인을 완료하지 못했습니다. 다시 시도하거나 이메일로 로그인하세요.');return()=>{alive=false;};},[]);
 async function socialLogin(name:'google'|'kakao'){if(busy)return;setBusy(true);setPassword('');setError('');try{const response=await fetch('/api/auth/social',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({provider:name})});const data:any=await response.json();if(!response.ok)throw Error(data.error||'로그인을 시작하지 못했습니다.');window.location.assign(data.url);}catch(e){setError(e instanceof Error?e.message:'로그인을 시작하지 못했습니다.');setBusy(false);}}
 async function submit(e:React.FormEvent){e.preventDefault();if(busy)return;setBusy(true);setError('');setMessage('');try{const r=await fetch('/api/auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:mode,email:email.trim(),password})});const d:any=await r.json();if(!r.ok)throw Error(d.error||'요청을 처리하지 못했습니다.');setPassword('');if(mode==='login'&&d.user)onLogin(d.user);else {setMode('login');setMessage(d.message||'가입 가능한 이메일이면 인증 안내가 발송됩니다. 메일의 링크로 인증한 뒤 로그인하세요.');}}catch(e){setError(e instanceof Error?e.message:'요청을 처리하지 못했습니다.');}finally{setBusy(false);}}
 return <main className="auth-page"><div className="auth-layout">
  <section className="auth-intro" aria-label="플랜두씨 소개">
   <div className="auth-brand"><span className="auth-brand-icon"><BookOpen size={24} aria-hidden="true"/></span><strong>플랜두씨</strong><span className="auth-brand-caption">PLAN · DO · SEE</span></div>
   <div className="auth-intro-copy"><p className="auth-eyebrow">나를 위한 작은 실행의 기록</p><h1>계획에서 실행으로.<br/>기록에서 <span>다음으로.</span></h1><p className="auth-intro-description">하고 싶은 일을 정하고, 오늘의 실행을 남기고,<br className="auth-desktop-break"/> 돌아보며 나만의 속도를 찾아가세요.</p></div>
   <ol className="auth-steps"><li><span className="auth-step-number">01</span><div><span className="auth-step-label">PLAN</span><h2>방향을 정해요</h2><p>목표와 성공 기준을 세우고 할 일을 정리해요.</p></div></li><li><span className="auth-step-number">02</span><div><span className="auth-step-label">DO</span><h2>한 걸음씩 실행해요</h2><p>실행한 일과 시간을 나의 기록으로 남겨요.</p></div></li><li><span className="auth-step-number">03</span><div><span className="auth-step-label">SEE</span><h2>돌아보고 이어가요</h2><p>기록을 확인하고 다음 계획을 다듬어요.</p></div></li></ol>
   <p className="auth-intro-footer"><Check size={15} aria-hidden="true"/> 계획과 실행, 회고를 한곳에서.</p>
  </section>
  <TiltSurface className="auth-card" maxTilt={3}><section aria-label="계정 로그인">
   <div className="auth-card-heading"><span className="auth-card-kicker">YOUR OWN DIARY</span><h2>{mode==='login'?'로그인':'회원가입'}</h2><p>{mode==='login'?'나의 계획과 기록을 이어가세요.':'본인 이메일로 나만의 다이어리를 시작하세요.'}</p></div>
   <form onSubmit={submit} className={`auth-form auth-form-${mode}`} aria-busy={busy}><div className="auth-entry-grid"><div className="auth-input-stack">
    <label className="auth-field" htmlFor="auth-email">이메일<Input id="auth-email" type="email" name="email" placeholder="본인 이메일 주소" autoComplete="username" value={email} onChange={e=>setEmail(e.target.value)} required maxLength={254}/></label>
    <label className="auth-field" htmlFor="auth-password">비밀번호<Input id="auth-password" type="password" name="password" placeholder={mode==='login'?'비밀번호를 입력해주세요':'12자 이상으로 설정해주세요'} autoComplete={mode==='login'?'current-password':'new-password'} value={password} onChange={e=>setPassword(e.target.value)} required minLength={mode==='signup'?12:undefined} maxLength={128} aria-describedby={mode==='signup'?'auth-password-hint':undefined}/>{mode==='signup'&&<small id="auth-password-hint">이 앱 전용 비밀번호를 12자 이상으로 설정해주세요.</small>}</label>
    </div>
    <Button type="submit" disabled={busy} className="auth-submit">{busy?'처리 중…':mode==='login'?'로그인':'회원가입'}{!busy&&<ArrowRight size={18} aria-hidden="true"/>}</Button>
   </div>{error&&<p className="error" role="alert">{error}</p>}{message&&<p className="success" role="status">{message}</p>}</form>
   <div className="auth-social-divider"><span>또는 간편하게 시작하기</span></div>
   <div className="auth-social-buttons">
    <Button type="button" className="auth-social-google" disabled={busy||!social?.google} onClick={()=>void socialLogin('google')}>Google로 로그인{social&&!social.google&&<small>연결 준비 중</small>}</Button>
    <Button type="button" className="auth-social-kakao" disabled={busy||!social?.kakao} onClick={()=>void socialLogin('kakao')}>카카오로 로그인{social&&!social.kakao&&<small>연결 준비 중</small>}</Button>
   </div>
   <Button type="button" variant="ghost" disabled={busy} className="auth-switch" onClick={()=>{setMode(mode==='login'?'signup':'login');setPassword('');setError('');setMessage('');}}>{mode==='login'?<>처음이신가요? <strong>회원가입</strong></>:<>이미 가입하셨나요? <strong>로그인</strong></>}</Button>
   <p className="auth-privacy"><LockKeyhole size={16} aria-hidden="true"/><span>계획과 기록은 본인 계정에서만 확인할 수 있어요. 관리자는 가입 요청 이메일·시각·처리 결과를 확인할 수 있으며 비밀번호는 기록하지 않습니다.</span></p>
  </section></TiltSurface>
 </div></main>;
}
