"use client";

import { useEffect, useRef } from "react";

/** Decorative scene; pointer depth is optional and never interrupts writing. */
export function SpatialScene() {
  const sceneRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const scene = sceneRef.current;
    const page = scene?.closest<HTMLElement>(".auth-page");
    if (!scene || !page) return;

    const finePointer = window.matchMedia("(min-width: 701px) and (hover: hover) and (pointer: fine)");
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    let frame = 0;
    let visible = true;
    let pointerX = 0;
    let pointerY = 0;

    const isEditing = () => document.activeElement instanceof Element
      && page.contains(document.activeElement)
      && document.activeElement.matches("input, textarea, select, [contenteditable='true']");
    const eligible = () => finePointer.matches && !reducedMotion.matches
      && visible && !document.hidden && !isEditing();
    const reset = () => {
      window.cancelAnimationFrame(frame);
      frame = 0;
      scene.style.removeProperty("--scene-x");
      scene.style.removeProperty("--scene-y");
      scene.removeAttribute("data-scene-moving");
    };
    const render = () => {
      frame = 0;
      if (!eligible()) return reset();
      const bounds = page.getBoundingClientRect();
      if (!bounds.width || !bounds.height) return reset();
      const x = Math.max(-1, Math.min(1, ((pointerX - bounds.left) / bounds.width) * 2 - 1));
      const y = Math.max(-1, Math.min(1, ((pointerY - bounds.top) / bounds.height) * 2 - 1));
      scene.style.setProperty("--scene-x", `${(x * 8).toFixed(2)}px`);
      scene.style.setProperty("--scene-y", `${(y * 8).toFixed(2)}px`);
      scene.setAttribute("data-scene-moving", "");
    };
    const move = (event: PointerEvent) => {
      if (event.pointerType !== "mouse" || !eligible()) return reset();
      pointerX = event.clientX;
      pointerY = event.clientY;
      if (!frame) frame = window.requestAnimationFrame(render);
    };
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (!visible) reset();
    });
    observer.observe(page);
    page.addEventListener("pointermove", move, { passive: true });
    page.addEventListener("pointerleave", reset);
    page.addEventListener("pointercancel", reset);
    page.addEventListener("focusin", reset);
    page.addEventListener("focusout", reset);
    document.addEventListener("visibilitychange", reset);
    window.addEventListener("blur", reset);
    window.addEventListener("resize", reset, { passive: true });
    window.addEventListener("scroll", reset, { passive: true, capture: true });
    finePointer.addEventListener("change", reset);
    reducedMotion.addEventListener("change", reset);

    return () => {
      reset();
      observer.disconnect();
      page.removeEventListener("pointermove", move);
      page.removeEventListener("pointerleave", reset);
      page.removeEventListener("pointercancel", reset);
      page.removeEventListener("focusin", reset);
      page.removeEventListener("focusout", reset);
      document.removeEventListener("visibilitychange", reset);
      window.removeEventListener("blur", reset);
      window.removeEventListener("resize", reset);
      window.removeEventListener("scroll", reset, true);
      finePointer.removeEventListener("change", reset);
      reducedMotion.removeEventListener("change", reset);
    };
  }, []);

  return (
    <div ref={sceneRef} className="spatial-scene" aria-hidden="true"
      style={{ position: "absolute", inset: 0, zIndex: 0, overflow: "hidden", pointerEvents: "none" }}>
      {/* A bitmap scene keeps the first render independent of browser motion APIs. */}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/spatial/aurora-scene.png" alt="" draggable={false}
        style={{ position: "absolute", inset: -10, width: "calc(100% + 20px)", height: "calc(100% + 20px)", maxWidth: "none", objectFit: "cover" }} />
    </div>
  );
}
