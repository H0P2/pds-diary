"use client";

import { useEffect, useRef } from "react";

/** Decorative scene; pointer depth is optional and never interrupts writing. */
export function SpatialScene() {
  const sceneRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const scene = sceneRef.current;
    const page = scene?.closest<HTMLElement>(".auth-page");
    if (!scene || !page) return;

    const finePointer = window.matchMedia("(min-width: 701px) and (hover: hover) and (pointer: fine)");
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    let frame = 0;
    let visible = true;
    let pointerX = 0;
    let pointerY = 0;
    let pointerActive = false;
    let windowFocused = true;

    const isEditing = () => document.activeElement instanceof Element
      && page.contains(document.activeElement)
      && document.activeElement.matches("input, textarea, select, [contenteditable='true']");
    const eligible = () => !reducedMotion.matches
      && visible && !document.hidden && windowFocused && !isEditing();
    const reset = () => {
      window.cancelAnimationFrame(frame);
      frame = 0;
      scene.style.removeProperty("--scene-x");
      scene.style.removeProperty("--scene-y");
      scene.style.removeProperty("--scene-scroll-y");
      scene.style.removeProperty("--scene-scale");
      scene.style.removeProperty("--scene-rotate-x");
      scene.removeAttribute("data-scene-moving");
    };
    const render = () => {
      frame = 0;
      if (!eligible()) return reset();
      const bounds = page.getBoundingClientRect();
      if (!bounds.width || !bounds.height) return reset();
      const pointerEligible = pointerActive && finePointer.matches;
      const x = pointerEligible ? Math.max(-1, Math.min(1, ((pointerX - bounds.left) / bounds.width) * 2 - 1)) : 0;
      const y = pointerEligible ? Math.max(-1, Math.min(1, ((pointerY - bounds.top) / bounds.height) * 2 - 1)) : 0;
      const pageTop = bounds.top + window.scrollY;
      const scrollRange = Math.max(1, bounds.height - window.innerHeight);
      const progress = Math.max(0, Math.min(1, (window.scrollY - pageTop) / scrollRange));
      scene.style.setProperty("--scene-x", `${(x * 8).toFixed(2)}px`);
      scene.style.setProperty("--scene-y", `${(y * 8).toFixed(2)}px`);
      scene.style.setProperty("--scene-scroll-y", `${(-progress * 24).toFixed(2)}px`);
      scene.style.setProperty("--scene-scale", (1 + progress * 0.025).toFixed(4));
      scene.style.setProperty("--scene-rotate-x", `${(progress * 1.5).toFixed(2)}deg`);
      scene.setAttribute("data-scene-moving", "");
    };
    const schedule = () => {
      if (!eligible()) return reset();
      if (!frame) frame = window.requestAnimationFrame(render);
    };
    // Focusout fires before activeElement settles on the next control.
    const afterFocus = () => {
      if (!frame) frame = window.requestAnimationFrame(render);
    };
    const clearPointer = () => {
      pointerActive = false;
      schedule();
    };
    const refresh = () => {
      pointerActive = false;
      reset();
      schedule();
    };
    const blur = () => {
      windowFocused = false;
      pointerActive = false;
      reset();
    };
    const focus = () => {
      windowFocused = true;
      schedule();
    };
    const move = (event: PointerEvent) => {
      if (event.pointerType !== "mouse" || !finePointer.matches) return clearPointer();
      pointerActive = true;
      pointerX = event.clientX;
      pointerY = event.clientY;
      schedule();
    };
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      schedule();
    });
    observer.observe(page);
    page.addEventListener("pointermove", move, { passive: true });
    page.addEventListener("pointerleave", clearPointer);
    page.addEventListener("pointercancel", clearPointer);
    page.addEventListener("focusin", refresh);
    page.addEventListener("focusout", afterFocus);
    document.addEventListener("visibilitychange", refresh);
    window.addEventListener("blur", blur);
    window.addEventListener("focus", focus);
    window.addEventListener("resize", refresh, { passive: true });
    window.addEventListener("scroll", schedule, { passive: true });
    finePointer.addEventListener("change", refresh);
    reducedMotion.addEventListener("change", refresh);

    return () => {
      reset();
      observer.disconnect();
      page.removeEventListener("pointermove", move);
      page.removeEventListener("pointerleave", clearPointer);
      page.removeEventListener("pointercancel", clearPointer);
      page.removeEventListener("focusin", refresh);
      page.removeEventListener("focusout", afterFocus);
      document.removeEventListener("visibilitychange", refresh);
      window.removeEventListener("blur", blur);
      window.removeEventListener("focus", focus);
      window.removeEventListener("resize", refresh);
      window.removeEventListener("scroll", schedule);
      finePointer.removeEventListener("change", refresh);
      reducedMotion.removeEventListener("change", refresh);
    };
  }, []);

  return (
    <div ref={sceneRef} className="spatial-scene" aria-hidden="true"
      style={{ position: "absolute", inset: 0, zIndex: 0, overflow: "hidden", pointerEvents: "none" }}>
      {/* A bitmap scene keeps the first render independent of browser motion APIs. */}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/spatial/aurora-scene.png" alt="" draggable={false}
        style={{ position: "absolute", inset: -40, width: "calc(100% + 80px)", height: "calc(100% + 80px)", maxWidth: "none", objectFit: "cover" }} />
    </div>
  );
}
