"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

type Profile = { username: string | null; display_name: string; bio: string };
type ProfileResponse = { profile?: Profile; error?: string };

export function ProfileSettings({ onSessionEnd }: { onSessionEnd: () => void }) {
  const sessionEnd = useRef(onSessionEnd);
  const live = useRef(false);
  const [profile, setProfile] = useState<Profile>({ username: "", display_name: "", bio: "" });
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [attempt, setAttempt] = useState(0);

  useEffect(() => { sessionEnd.current = onSessionEnd; }, [onSessionEnd]);
  useEffect(() => {
    live.current = true;
    const controller = new AbortController();
    fetch("/api/profile", { cache: "no-store", signal: AbortSignal.any([controller.signal, AbortSignal.timeout(15000)]) })
      .then(async response => {
        const value = await response.json() as ProfileResponse;
        if (controller.signal.aborted) return;
        if (response.status === 401) { sessionEnd.current(); return; }
        if (!response.ok) throw Error(value.error || "프로필을 불러오지 못했습니다.");
        if (!value.profile) throw Error("프로필 응답을 확인하지 못했습니다.");
        setProfile({ username: value.profile.username || "", display_name: value.profile.display_name || "", bio: value.profile.bio || "" });
      })
      .catch(reason => { if (!controller.signal.aborted) setError(reason instanceof Error ? reason.message : "프로필을 불러오지 못했습니다."); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => { live.current = false; controller.abort(); };
  }, [attempt]);

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (loading || busy) return;
    const next = { username: (profile.username || "").trim().toLowerCase(), display_name: profile.display_name.trim(), bio: profile.bio.trim() };
    setError("");
    setNotice("");
    if (!/^[a-z0-9_]{3,20}$/.test(next.username)) { setError("아이디는 영문 소문자, 숫자, 밑줄로 3~20자 입력해주세요."); return; }
    if (Array.from(next.display_name).length < 1 || Array.from(next.display_name).length > 30) { setError("공개 이름은 1~30자로 입력해주세요."); return; }
    if (Array.from(next.bio).length > 200) { setError("소개는 200자 이내로 입력해주세요."); return; }
    setBusy(true);
    try {
      const response = await fetch("/api/profile", { method: "POST", signal: AbortSignal.timeout(15000), headers: { "Content-Type": "application/json" }, body: JSON.stringify(next) });
      const value = await response.json() as ProfileResponse;
      if (!live.current) return;
      if (response.status === 401) { sessionEnd.current(); return; }
      if (!response.ok) throw Error(value.error || "프로필을 저장하지 못했습니다.");
      if (!value.profile) throw Error("프로필 응답을 확인하지 못했습니다.");
      setProfile(value.profile);
      setNotice("내 프로필을 저장했습니다.");
    } catch (reason) {
      if (live.current) setError(reason instanceof Error ? reason.message : "프로필을 저장하지 못했습니다.");
    } finally { if (live.current) setBusy(false); }
  }

  return <section className="panel profile-settings" aria-labelledby="profile-title">
    <h2 id="profile-title">공개 프로필</h2>
    <p className="muted">커뮤니티에 표시할 아이디와 이름을 설정하세요. 이메일은 공개 프로필에 표시하지 않습니다.</p>
    {loading && <p role="status">프로필을 불러오는 중입니다.</p>}
    {error && <div className="error" role="alert"><span>{error}</span><Button type="button" variant="outline" disabled={loading || busy} onClick={() => { setLoading(true); setError(""); setNotice(""); setAttempt(value => value + 1); }}>다시 불러오기</Button></div>}
    {notice && <p className="success" role="status">{notice}</p>}
    <form onSubmit={save}>
      <div className="form-grid">
        <label className="field">아이디<Input name="username" autoComplete="username" autoCapitalize="none" spellCheck={false} value={profile.username || ""} onChange={event => setProfile({ ...profile, username: event.target.value.toLowerCase() })} required pattern="[a-z0-9_]{3,20}" minLength={3} maxLength={20} disabled={loading || busy} aria-describedby="profile-username-help"/><small id="profile-username-help" className="muted">영문 소문자·숫자·밑줄, 3~20자</small></label>
        <label className="field">공개 이름<Input name="display_name" autoComplete="nickname" value={profile.display_name} onChange={event => setProfile({ ...profile, display_name: event.target.value })} required disabled={loading || busy} aria-describedby="profile-name-help"/><small id="profile-name-help" className="muted">커뮤니티에 표시할 이름, 1~30자</small></label>
      </div>
      <label className="field">소개 <span className="profile-optional">선택</span><Textarea name="bio" value={profile.bio} onChange={event => setProfile({ ...profile, bio: event.target.value })} disabled={loading || busy} aria-describedby="profile-bio-help"/><small id="profile-bio-help" className="muted">{Array.from(profile.bio).length}/200자</small></label>
      <Button disabled={loading || busy}>{busy ? "저장 중…" : "프로필 저장"}</Button>
    </form>
  </section>;
}
