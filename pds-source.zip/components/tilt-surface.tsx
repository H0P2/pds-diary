"use client";

import { useEffect, useRef, type CSSProperties, type ReactNode } from "react";

type TiltSurfaceProps = {
  children: ReactNode;
  className?: string;
  style?: CSSProperties;
  maxTilt?: number;
};

/** A flat, semantic card until an eligible pointer interacts with it. */
export function TiltSurface({ children, className, style, maxTilt = 3 }: TiltSurfaceProps) {
  const surfaceRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const surface = surfaceRef.current;
    if (!surface) return;

    const finePointer = window.matchMedia("(min-width: 701px) and (hover: hover) and (pointer: fine)");
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    const limit = Number.isFinite(maxTilt) ? Math.min(3, Math.max(0, maxTilt)) : 3;
    let frame = 0;
    let bounds: DOMRect | null = null;
    let pointerX = 0;
    let pointerY = 0;
    let listening = false;

    const reset = () => {
      window.cancelAnimationFrame(frame);
      frame = 0;
      bounds = null;
      surface.removeAttribute("data-tilting");
      surface.style.removeProperty("--tilt-x");
      surface.style.removeProperty("--tilt-y");
    };
    const canTilt = () => finePointer.matches && !reducedMotion.matches && limit > 0;
    const isFocused = () => surface.contains(document.activeElement);
    const renderTilt = () => {
      frame = 0;
      if (!canTilt() || isFocused() || !bounds || !bounds.width || !bounds.height) {
        reset();
        return;
      }
      const x = Math.max(-1, Math.min(1, ((pointerX - bounds.left) / bounds.width) * 2 - 1));
      const y = Math.max(-1, Math.min(1, ((pointerY - bounds.top) / bounds.height) * 2 - 1));
      surface.style.setProperty("--tilt-x", `${(-y * limit).toFixed(2)}deg`);
      surface.style.setProperty("--tilt-y", `${(x * limit).toFixed(2)}deg`);
      surface.setAttribute("data-tilting", "");
    };
    const move = (event: PointerEvent) => {
      if (event.pointerType !== "mouse" || !canTilt() || isFocused()) {
        reset();
        return;
      }
      bounds ??= surface.getBoundingClientRect();
      pointerX = event.clientX;
      pointerY = event.clientY;
      if (!frame) frame = window.requestAnimationFrame(renderTilt);
    };
    const detach = () => {
      reset();
      if (listening) {
        surface.removeEventListener("pointermove", move);
        surface.removeEventListener("pointerleave", reset);
        surface.removeEventListener("pointercancel", reset);
        surface.removeEventListener("focusin", reset);
        surface.removeEventListener("focusout", reset);
        window.removeEventListener("blur", reset);
        window.removeEventListener("resize", reset);
        window.removeEventListener("scroll", reset, true);
        listening = false;
      }
    };
    const updateEligibility = () => {
      detach();
      if (canTilt()) {
        surface.addEventListener("pointermove", move, { passive: true });
        surface.addEventListener("pointerleave", reset);
        surface.addEventListener("pointercancel", reset);
        surface.addEventListener("focusin", reset);
        surface.addEventListener("focusout", reset);
        window.addEventListener("blur", reset);
        window.addEventListener("resize", reset, { passive: true });
        window.addEventListener("scroll", reset, { passive: true, capture: true });
        listening = true;
      }
    };

    finePointer.addEventListener("change", updateEligibility);
    reducedMotion.addEventListener("change", updateEligibility);
    updateEligibility();
    return () => {
      finePointer.removeEventListener("change", updateEligibility);
      reducedMotion.removeEventListener("change", updateEligibility);
      detach();
    };
  }, [maxTilt]);

  return <div ref={surfaceRef} className={["tilt-surface", className].filter(Boolean).join(" ")} style={style}>{children}</div>;
}
