'use client';
import {useEffect,useState} from 'react';

type PlannedItem={title:string;start:string};
type PlannedDay={date:string;weekday:string;items:PlannedItem[]};
const plannedDays:PlannedDay[]=[
 {date:'2026-10-10',weekday:'토',items:[{title:'기상·운동',start:'05:00'},{title:'결혼식',start:'13:00'}]},
 {date:'2026-10-11',weekday:'일',items:[{title:'기상·운동',start:'05:00'},{title:'공부',start:'11:00'}]},
 {date:'2026-10-12',weekday:'월',items:[{title:'기상·운동',start:'05:00'},{title:'학원',start:'09:00'},{title:'운동·자격증 공부',start:'19:00'}]},
 {date:'2026-10-13',weekday:'화',items:[{title:'기상·운동',start:'05:00'},{title:'학원',start:'09:00'},{title:'운동·자격증 공부',start:'19:00'}]},
 {date:'2026-10-14',weekday:'수',items:[{title:'기상·운동',start:'05:00'},{title:'학원',start:'09:00'},{title:'운동·자격증 공부',start:'19:00'}]},
];
const releaseAt=(date:string)=>Date.parse(date+'T21:30:00+09:00');
const seoulClock=new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',dateStyle:'medium',timeStyle:'short'});

export function EveningPlanDraft({onPrepare}:{onPrepare:(title:string,date:string,start:string)=>void}){
 const [now,setNow]=useState<number|null>(null);
 useEffect(()=>{
  let live=true;
  const catchUp=()=>{if(live&&document.visibilityState==='visible')setNow(Date.now());};
  queueMicrotask(catchUp);
  const timer=window.setInterval(catchUp,60_000);
  document.addEventListener('visibilitychange',catchUp);
  window.addEventListener('focus',catchUp);
  return()=>{live=false;window.clearInterval(timer);document.removeEventListener('visibilitychange',catchUp);window.removeEventListener('focus',catchUp);};
 },[]);
 const ready=now===null?[]:plannedDays.filter(day=>now>=releaseAt(day.date));
 const next=now===null?null:plannedDays.find(day=>now<releaseAt(day.date));
 return <section className="evening-plan-draft" aria-labelledby="evening-plan-draft-title">
  <header className="evening-plan-draft-heading">
   <div><p className="evening-plan-draft-eyebrow">EVENING CHECK-IN · 서울 시간</p><h2 id="evening-plan-draft-title">저녁에 확인하는 계획 초안</h2></div>
   <span className="evening-plan-draft-count">확인 대기 {ready.length}/5일</span>
  </header>
  <p className="evening-plan-draft-description">2026년 10월 10일~14일의 예정 일정입니다. 각 날짜의 서울 시간 21:30 이후 확인 대기 초안으로 표시합니다.</p>
  <p className="evening-plan-draft-evidence"><strong>계획 초안 · 실제 실행의 증거가 아닙니다.</strong> 예정 시작만 표시하며 종료 시각은 미정입니다. 실제 실행이나 완료 기록은 직접 입력해야 합니다.</p>
  <p className="evening-plan-draft-status" role="status">{now===null?'서울 시간을 확인하는 중…':next?<>다음 초안: <time dateTime={next.date+'T21:30:00+09:00'}>{next.date.slice(5).replace('-','월 ')}일 21:30</time> 이후 표시됩니다.</>:'5일분 초안이 모두 표시되어 있습니다. 이후 새 날짜의 초안은 추가하지 않으며, 지난 초안은 계속 확인할 수 있습니다.'}</p>
  <div className="evening-plan-draft-days">
   {plannedDays.map(day=>{
    const released=now!==null&&now>=releaseAt(day.date);
    return <details className={'evening-plan-draft-day'+(released?' is-ready':' is-scheduled')} key={day.date} open={released}>
     <summary><time dateTime={day.date}>{Number(day.date.slice(5,7))}월 {Number(day.date.slice(8))}일 ({day.weekday})</time><span className="evening-plan-draft-badge">{released?'확인 대기 초안':'예정 안내 · 21:30 이후 확인'}</span></summary>
     <ul className="evening-plan-draft-items">{day.items.map(item=><li key={item.title} className="evening-plan-draft-item"><div><h3>{item.title}</h3><p><span>예정 시작 <time dateTime={day.date+'T'+item.start+':00+09:00'}>{item.start}</time></span><span>종료 미정</span></p></div>{released?<button type="button" className="evening-plan-draft-prepare" onClick={()=>onPrepare(item.title,day.date,item.start)} aria-label={Number(day.date.slice(8))+'일 '+item.title+' 실제 실행 입력하기'}>실제 실행 입력하기</button>:<span className="evening-plan-draft-wait">아직 확인 대기 전</span>}</li>)}</ul>
     {released&&<p className="evening-plan-draft-input-note">입력 화면의 예정 시각은 참고 정보입니다. 실제 시작·종료 시각은 본인이 확인해 입력하세요.</p>}
    </details>;
   })}
  </div>
  {now!==null&&<p className="evening-plan-draft-clock">마지막 확인 <time dateTime={new Date(now).toISOString()}>{seoulClock.format(now)}</time> · 화면이 열려 있으면 1분마다 확인합니다.</p>}
 </section>;
}
export default EveningPlanDraft;
