"use client";
import { useEffect, useRef } from "react";
import { createOperationalVerifier } from "@/lib/operational-verification";
type ModelContext = { registerTool: (tool: unknown, options: { signal: AbortSignal }) => unknown };
export function OperationalVerificationTools({ userId, onSessionEnd }: { userId: string; onSessionEnd: () => void }) {
  const endSession = useRef(onSessionEnd);
  useEffect(() => { endSession.current = onSessionEnd; }, [onSessionEnd]);
  useEffect(() => {
    if (!userId) return;
    const context = (document as Document & { modelContext?: ModelContext }).modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    const tool = createOperationalVerifier(userId, () => endSession.current(), lifecycle);
    try { Promise.resolve(context.registerTool(tool, { signal: lifecycle.signal })).catch(() => {}); } catch { /* Ordinary UI stays available. */ }
    return () => lifecycle.abort();
  }, [userId]);
  return null;
}
