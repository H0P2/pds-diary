"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import { createOperationalVerifier, type OperationalVerificationInput } from "@/lib/operational-verification";

export function OperationalVerificationPanel({ userId }: { userId: string }) {
  const verifier = useRef<ReturnType<typeof createOperationalVerifier> | null>(null);
  const [busy, setBusy] = useState(false);
  const [ended, setEnded] = useState(false);
  const [error, setError] = useState("");
  const [results, setResults] = useState<{ mode: string; result: unknown }[]>([]);
  const [foreign, setForeign] = useState({ owner_id: "", plan_id: "", task_id: "" });
  useEffect(() => {
    const lifecycle = new AbortController();
    verifier.current = createOperationalVerifier(userId, () => setEnded(true), lifecycle);
    return () => { lifecycle.abort(); verifier.current = null; };
  }, [userId]);
  async function run(input: OperationalVerificationInput) {
    if (busy || ended || !verifier.current) return;
    setBusy(true); setError("");
    try {
      const result = await verifier.current.execute(input);
      setResults(previous => [{ mode: input.mode, result }, ...previous]);
    } catch (reason) { setError(reason instanceof Error ? reason.message : "검증을 진행하지 못했습니다."); }
    finally { setBusy(false); }
  }
  function inspectForeign(event: FormEvent<HTMLFormElement>) { event.preventDefault(); void run({ mode: "foreign", ...foreign }); }
  async function checkLogout() {
    if (busy || ended) return;
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/verification", { method: "POST", credentials: "same-origin", cache: "no-store", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "logout_check" }), signal: AbortSignal.timeout(15000) });
      const result = await response.json() as { error?: string; before_status?: number };
      if (response.status === 401) setEnded(true);
      if (!response.ok) throw Error(result.error || "로그아웃 검증을 완료하지 못했습니다.");
      setResults(previous => [{ mode: "logout_check", result }, ...previous]);
      if (result.before_status === 200) setEnded(true);
    } catch (reason) { setError(reason instanceof Error ? reason.message : "로그아웃 검증을 완료하지 못했습니다."); }
    finally { setBusy(false); }
  }
  const button = "min-h-11 rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-800 disabled:opacity-50";
  const field = "min-h-11 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-sm text-slate-900";
  return <main className="min-h-screen bg-slate-50 px-4 py-8 text-slate-900">
    <div className="mx-auto max-w-4xl space-y-6">
      {/* Full navigation is required by the deployed runtime in external browsers. */}
      {/* eslint-disable-next-line @next/next/no-html-link-for-pages */}
      <header className="space-y-3"><a href="/" className="text-sm text-blue-700 underline">다이어리로 돌아가기</a><h1 className="text-2xl font-semibold">실제 운영 접근 검증</h1><p className="text-sm leading-7 text-slate-600">현재 로그인 계정의 서버 응답을 확인합니다. 계획·할 일은 ‘실사용 아님’ 검증용으로만 준비하며, 실행·완료·5일 사용 기록을 만들지 않습니다. 계정 삭제는 실행하지 않습니다.</p></header>
      {error && <p role="alert" className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-800">{error}</p>}
      {ended && <p role="alert">로그인이 끝났거나 계정이 바뀌었습니다. 다이어리에서 다시 로그인하세요.</p>}
      <section className="space-y-4 rounded-xl border border-slate-200 bg-white p-5"><h2 className="text-lg font-semibold">1. 본인 자료와 전체 내보내기</h2><p className="text-sm text-slate-600">건수·자료 비교값·본인 계정 ID만 표시합니다. 상대 탭의 검사 전후에 이 확인을 다시 실행해 건수와 pds_content_digest가 같은지 비교하세요.</p><div className="flex flex-wrap gap-3"><button className={button} disabled={busy || ended} onClick={() => void run({ mode: "read" })}>본인 자료 확인</button><button className={button} disabled={busy || ended} onClick={() => void run({ mode: "fixture" })}>검증용 계획·할 일 준비</button></div><p className="text-xs text-slate-500">준비 버튼은 같은 검증용 계획과 활성 할 일이 있으면 재사용합니다. 실제 서버에 저장되는 검증 자료이며 실사용 증거가 아닙니다.</p></section>
      <section className="space-y-4 rounded-xl border border-slate-200 bg-white p-5"><h2 className="text-lg font-semibold">2. 다른 계정 자료 접근 차단</h2><p className="text-sm text-slate-600">다른 브라우저에서 로그인한 계정의 확인 결과와 검증용 ID를 입력하세요. 본인 계정 ID는 차단하며, 계획·할 일 조회가 모두 404일 때만 수정·보관 거절을 확인합니다.</p><form className="grid gap-4" onSubmit={inspectForeign}>{([['owner_id','상대 계정 ID · verified_user_id'],['plan_id','상대 검증용 계획 ID · plan_id'],['task_id','상대 검증용 할 일 ID · task_id']] as const).map(([key,label])=><label key={key} className="grid gap-2 text-sm">{label}<input className={field} value={foreign[key]} onChange={event=>setForeign({...foreign,[key]:event.target.value.trim()})} required pattern="[A-Za-z0-9_-]{1,100}" maxLength={100} autoComplete="off" disabled={busy || ended}/></label>)}<button className={button+" justify-self-start"} disabled={busy || ended}>상대 자료 접근 차단 검사</button></form></section>
      <section className="space-y-4 rounded-xl border border-slate-200 bg-white p-5"><h2 className="text-lg font-semibold">3. 로그아웃 전후 확인</h2><p className="text-sm leading-7 text-slate-600">현재 계정에서 실제로 로그아웃합니다. 두 계정의 자료 검사를 마친 뒤 실행하세요. 서버 내부에서 현재 세션을 담은 동일한 GET 요청 하나로 로그아웃 전 성공과 후 거절을 확인합니다. 쿠키 원문은 화면이나 결과에 표시하지 않으며, 외부 브라우저에서 쿠키를 다시 전송한 검사는 아닙니다.</p><button className={button} disabled={busy || ended} onClick={() => void checkLogout()}>로그아웃 전후 확인</button><p className="text-xs text-slate-500">완료 후 검사를 계속하려면 다이어리에서 직접 다시 로그인하세요.</p></section>
      {busy && <p role="status">서버 응답을 확인하는 중입니다.</p>}
      <section className="space-y-4" aria-label="검증 결과"><h2 className="text-lg font-semibold">검증 결과 · 최신순</h2>{!results.length&&<p className="text-sm text-slate-500">아직 검사를 실행하지 않았습니다.</p>}{results.map((entry,index)=><article key={index} className="rounded-xl border border-slate-200 bg-white p-5"><h3 className="mb-3 font-semibold">{entry.mode==='read'?'본인 자료 확인':entry.mode==='fixture'?'검증용 자료 준비':entry.mode==='logout_check'?'서버 내부 동일 요청 · 로그아웃 전후 확인':'상대 자료 접근 차단'} · 결과 {results.length-index}</h3><pre className="whitespace-pre-wrap break-all rounded-lg bg-slate-50 p-4 font-mono text-xs leading-6">{JSON.stringify(entry.result,null,2)}</pre></article>)}</section>
    </div>
  </main>;
}
