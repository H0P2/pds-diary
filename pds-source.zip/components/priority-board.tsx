"use client";
import {useState,type DragEvent} from 'react';

const transferType='application/x-pds-task-id';
const priorities=[{value:1,label:'최우선'},{value:2,label:'보통'},{value:3,label:'낮음'}];
type Task={id:string;title:string;priority:number;deleted_at?:string|null;[key:string]:unknown};
type Props={tasks:Task[];busy:boolean;onPriorityChange:(task:Task,priority:number)=>void};

export function PriorityBoard({tasks,busy,onPriorityChange}:Props){
 const [dragging,setDragging]=useState<string|null>(null),[over,setOver]=useState<number|null>(null);
 const visible=tasks.filter(task=>!task.deleted_at);
 function change(task:Task,priority:number){
  if(busy||task.priority===priority||!priorities.some(item=>item.value===priority))return;
  onPriorityChange(task,priority);
 }
 function start(event:DragEvent<HTMLElement>,task:Task){
  if(busy){event.preventDefault();return;}
  event.dataTransfer.setData(transferType,task.id);
  event.dataTransfer.effectAllowed='move';setDragging(task.id);
 }
 function allow(event:DragEvent<HTMLElement>,priority:number){
  if(busy||!event.dataTransfer.types.includes(transferType))return;
  event.preventDefault();event.dataTransfer.dropEffect='move';setOver(priority);
 }
 function drop(event:DragEvent<HTMLElement>,priority:number){
  event.preventDefault();setDragging(null);setOver(null);
  if(busy||!event.dataTransfer.types.includes(transferType))return;
  const id=event.dataTransfer.getData(transferType);
  const task=visible.find(item=>item.id===id);
  if(task)change(task,priority);
 }
 return <section className="priority-board" aria-labelledby="priority-board-title" aria-busy={busy}>
  <header className="priority-board-heading"><h2 id="priority-board-title">우선순위 보드</h2><p className="muted">할 일을 다른 영역으로 옮겨 등급을 변경하세요. 목록 순서는 바뀌지 않아요. 선택 메뉴로도 변경할 수 있어요.</p></header>
  <div className="priority-board-columns">
   {priorities.map(({value,label})=>{
    const group=visible.filter(task=>(priorities.some(item=>item.value===task.priority)?task.priority:2)===value);
    return <section key={value} className={`priority-column priority-column-${value}${over===value&&!busy?' is-drop-target':''}`} aria-label={`${label} 할 일`} onDragOver={event=>allow(event,value)} onDragLeave={event=>{if(!event.currentTarget.contains(event.relatedTarget as Node|null))setOver(null);}} onDrop={event=>drop(event,value)}>
     <header className="priority-column-heading"><h3>{label}</h3><span>{group.length}개</span></header>
     <ul className="priority-task-list">{group.map(task=><li key={task.id} className={`priority-task${dragging===task.id?' is-dragging':''}`} draggable={!busy} onDragStart={event=>start(event,task)} onDragEnd={()=>{setDragging(null);setOver(null);}}>
      <strong>{task.title}</strong>
      <label className="priority-task-control"><span>우선순위 변경</span><select aria-label={`${task.title} 우선순위 변경`} value={priorities.some(item=>item.value===task.priority)?task.priority:2} disabled={busy} onChange={event=>change(task,Number(event.target.value))}>{priorities.map(item=><option key={item.value} value={item.value}>{item.label}</option>)}</select></label>
     </li>)}</ul>
     {!group.length&&<p className="priority-empty muted">이 등급의 할 일이 없어요.</p>}
    </section>;
   })}
  </div>
 </section>;
}
