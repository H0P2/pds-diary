"use client";
import {useState} from 'react';
import {Input} from '@/components/ui/input';
import {Select,SelectContent,SelectItem,SelectTrigger,SelectValue} from '@/components/ui/select';
import {durationUnits,preferredUnit} from '@/lib/duration';
export function DurationField({value,onChange}:{value:number;onChange:(value:number)=>void}) {
  const [unit,setUnit]=useState<string>(()=>preferredUnit(Number(value)).value);
  const factor=durationUnits.find(u=>u.value===unit)!.minutes;
  const quantity=Math.round((Number(value)||0)/factor*1000000)/1000000;
  return <div className="field duration-field"><span>예상 소요 시간</span><div className="duration-input"><Input aria-label="예상 소요 시간 값" type="number" min="0" step="any" value={quantity} onChange={e=>onChange(Number(e.target.value)*factor)} required/><Select value={unit} onValueChange={next=>{const nextFactor=durationUnits.find(u=>u.value===next)!.minutes;setUnit(next);onChange(quantity*nextFactor)}}><SelectTrigger aria-label="시간 단위"><SelectValue/></SelectTrigger><SelectContent>{durationUnits.map(u=><SelectItem key={u.value} value={u.value}>{u.label}</SelectItem>)}</SelectContent></Select></div><small className="muted">0은 미정 · 1달은 30일 기준 · 초 단위까지 저장</small></div>;
}
