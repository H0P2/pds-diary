'use client';

import {useCallback, useEffect, useId, useRef, useState} from 'react';

type ActivityDraft = {
 today: string;
 source_count: number;
 seconds: number;
 minutes: number;
 sessions: number[];
 notes: string[];
 can_record: boolean;
 baseline_suggestion: string;
 change_suggestion: {rule: string; reason: string} | null;
};

const planDates = ['2026-10-10', '2026-10-11', '2026-10-12', '2026-10-13', '2026-10-14'];
const planDetails = [
 {activities: ['05:00 기상 · 운동 (운동 종료 시각 미정)', '13:00 결혼식 (종료 시각 미정)'], suggestion: '결혼식 전후에는 이동과 휴식 여유를 먼저 확인하세요. 추가 공부는 실제로 여유가 있을 때 선택하세요.'},
 {activities: ['05:00 기상 · 운동 (운동 종료 시각 미정)', '11:00~20:00 공부'], suggestion: '공부 중 휴식과 식사 구간을 먼저 정하세요. 계획된 9시간 전체를 실제 집중 시간으로 계산하지 마세요.'},
 ...Array.from({length: 3}, () => ({activities: ['05:00 기상 · 운동 (운동 종료 시각 미정)', '09:00~18:00 학원', '19:00부터 운동 · 자격증 공부 (종료 시각 미정)'], suggestion: '학원 후 이동·식사·휴식 여유를 확인한 뒤, 운동과 자격증 공부 중 오늘의 우선순위를 직접 정하세요. 실제 여유에 따라 순서와 분량을 조절하세요.'})),
];
function dayForDate(date: string) {
 const offset = Math.floor((Date.parse(`${date}T00:00:00+09:00`) - Date.parse('2026-10-10T00:00:00+09:00')) / 86_400_000);
 return Number.isFinite(offset) ? Math.max(1, Math.min(5, offset + 1)) : 1;
}
function currentSeoulDate() {
 const parts = new Intl.DateTimeFormat('en-US', {timeZone: 'Asia/Seoul', year: 'numeric', month: '2-digit', day: '2-digit'}).formatToParts(new Date());
 return ['year', 'month', 'day'].map(type => parts.find(part => part.type === type)?.value).join('-');
}

export function StudyActivityAssistant({onUseSessions, onSessionEnd}: {
 onUseSessions: (sessions: number[]) => void;
 onSessionEnd?: () => void;
}) {
 const titleId = useId();
 const sessionEnd = useRef(onSessionEnd);
 const request = useRef<AbortController | null>(null);
 const [draft, setDraft] = useState<ActivityDraft | null>(null);
 const [busy, setBusy] = useState(false);
 const [error, setError] = useState('');
 const [notice, setNotice] = useState('');
 const [automatic, setAutomatic] = useState(false);
 const [selectedDay, setSelectedDay] = useState(() => dayForDate(currentSeoulDate()));
 const manualDay = useRef(false);
 useEffect(() => {sessionEnd.current = onSessionEnd;}, [onSessionEnd]);

 const refresh = useCallback(async () => {
  if (request.current) return;
  const controller = new AbortController();
  request.current = controller;
  setBusy(true);
  setError('');
  setNotice('');
  try {
   const response = await fetch('/api/study/activity', {cache: 'no-store', signal: controller.signal});
   if (response.status === 401) {
    setDraft(null);
    setAutomatic(false);
    sessionEnd.current?.();
    throw new Error('로그인이 만료되었습니다. 다시 로그인해 주세요.');
   }
   const value = await response.json() as ActivityDraft & {error?: string};
   if (!response.ok) throw new Error(value.error || '실제 작업 시간을 불러오지 못했습니다.');
   setDraft(value);
   if (!manualDay.current) setSelectedDay(dayForDate(value.today));
  } catch (cause) {
   if (!controller.signal.aborted) {
    setDraft(null);
    setError(cause instanceof Error ? cause.message : '실제 작업 시간을 불러오지 못했습니다.');
   }
  } finally {
   if (request.current === controller) request.current = null;
   if (!controller.signal.aborted) setBusy(false);
  }
 }, []);

 useEffect(() => {
  const timer = window.setTimeout(() => {void refresh();}, 0);
  return () => {window.clearTimeout(timer); request.current?.abort(); request.current = null;};
 }, [refresh]);

 useEffect(() => {
  if (!automatic) return;
  const timer = window.setInterval(() => {
   if (document.visibilityState === 'visible') void refresh();
  }, 60_000);
  return () => window.clearInterval(timer);
 }, [automatic, refresh]);

 const sessions = draft?.sessions.filter(value => Number.isFinite(value) && value > 0) || [];
 const canUse = Boolean(draft?.can_record && draft.source_count > 0 && sessions.length > 0 && !busy);
 const secondary = 'min-h-11 rounded-lg border border-white/30 px-4 py-2 text-sm font-semibold text-white hover:bg-white/10 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-lime-300 disabled:opacity-50';

 return <section aria-labelledby={titleId} aria-busy={busy} className="space-y-4 rounded-xl bg-[#242424] p-5 text-white">
  <header className="flex flex-wrap items-start justify-between gap-3">
   <div><p className="mb-1 text-xs font-semibold tracking-wide text-lime-300">실제 활동으로 준비하는 기록 초안</p><h3 id={titleId} className="text-lg font-bold">오늘의 실제 작업 시간</h3></div>
   <button type="button" className={secondary} disabled={busy} onClick={() => void refresh()}>{busy ? '불러오는 중…' : '새로고침'}</button>
  </header>
  <p className="text-sm leading-relaxed text-white/80">내 실제 실행 기록의 겹치는 구간을 합쳐 계산합니다. 자동 조회는 사람의 사용이나 실제 5일 사용 증거로 계산하지 않습니다. 로그인 후 자동 조회만으로는 실제 5일 사용이 완료되지 않습니다.</p>
  {error && <p role="alert" className="rounded-lg border border-red-300/40 bg-red-950/40 p-3 text-sm text-red-100">{error}</p>}
  {draft && <>
   <dl className="grid grid-cols-2 gap-3 rounded-lg bg-white/5 p-4">
    <div><dt className="text-xs text-white/70">서울 날짜</dt><dd className="mt-1 font-semibold">{draft.today}</dd></div>
    <div><dt className="text-xs text-white/70">합쳐진 실제 작업 시간</dt><dd className="mt-1 font-semibold text-lime-300">{draft.seconds.toLocaleString('ko-KR')}초 <span className="text-xs font-normal text-white/80">({draft.minutes.toLocaleString('ko-KR', {maximumFractionDigits: 2})}분)</span></dd></div>
   </dl>
   <p className="text-sm text-white/80">실제 실행 기록 {draft.source_count}개 · 겹침을 제외한 작업 구간 {sessions.length}개</p>
   {draft.notes.length > 0 && <ul className="list-disc space-y-1 pl-5 text-sm text-white/80">{draft.notes.map((note, index) => <li key={index}>{note}</li>)}</ul>}
   {draft.baseline_suggestion && <div className="rounded-lg border border-white/15 p-3 text-sm"><p className="mb-1 font-semibold">기존 작업 시작 규칙 제안</p><p className="whitespace-pre-wrap text-white/80">{draft.baseline_suggestion}</p></div>}
   {draft.change_suggestion && <div className="space-y-2 rounded-lg border border-lime-300/40 p-3 text-sm"><p className="font-semibold text-lime-300">1·2일차 이후 변경 제안 · 읽기 전용</p><p className="whitespace-pre-wrap">{draft.change_suggestion.rule}</p><p className="whitespace-pre-wrap text-white/80">이유: {draft.change_suggestion.reason}</p><p className="text-xs text-white/70">기록을 검토한 뒤 변경 규칙과 이유를 직접 입력하세요. 제안은 자동 저장되지 않습니다.</p></div>}
  </>}
  <label className="flex cursor-pointer items-start gap-3 text-sm"><input type="checkbox" className="mt-1 h-4 w-4 accent-lime-300" checked={automatic} onChange={event => setAutomatic(event.target.checked)}/><span>이 화면이 보일 때만 60초마다 자동 조회<span className="mt-1 block text-xs text-white/70">화면을 숨기면 조회를 건너뜁니다. 작업 실행이나 하루 기록 확정은 하지 않습니다.</span></span></label>
  <button type="button" disabled={!canUse} className="min-h-11 rounded-lg bg-lime-300 px-4 py-3 text-sm font-semibold text-slate-950 hover:bg-lime-200 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-lime-300 disabled:opacity-50" onClick={() => {
   if (!canUse) return;
   onUseSessions([...sessions]);
   setNotice('실제 작업 시간을 입력란에 가져왔습니다. 확인한 뒤 오늘 기록을 직접 확정하세요.');
  }}>실제 작업 시간을 입력란에 가져오기</button>
  {!busy && draft && !canUse && <p className="text-xs text-white/70">{draft.source_count === 0 || sessions.length === 0 ? '가져올 실제 작업 시간이 없습니다.' : '현재는 하루 기록 입력을 진행할 수 없습니다.'}</p>}
  <p className="text-xs leading-relaxed text-white/70">가져오기는 입력란만 채웁니다. 하루 기록 확정, 규칙 변경, 손계산 대조는 직접 진행하세요.</p>
  {notice && <p role="status" className="text-sm text-lime-200">{notice}</p>}
  <div className="space-y-3 rounded-lg border border-white/20 p-4">
   <div className="flex flex-wrap items-center justify-between gap-3"><h4 className="font-semibold">내 5일 계획 · 읽기 전용</h4><select aria-label="5일 계획의 일차 선택" value={selectedDay} onChange={event => {manualDay.current = true; setSelectedDay(Number(event.target.value));}} className="min-h-11 rounded-lg border border-white/30 bg-[#242424] px-3 text-sm focus-visible:outline-2 focus-visible:outline-lime-300">{planDates.map((date, index) => <option key={date} value={index + 1}>{index + 1}일차 · {date}</option>)}</select></div>
   <p className="text-xs text-white/70">고정 시작일 2026-10-10 (서울) · 5일차 2026-10-14</p>
   <p className="text-sm font-semibold text-lime-300">{selectedDay}일차 · {planDates[selectedDay - 1]}</p>
   <ul className="list-disc space-y-2 pl-5 text-sm">{planDetails[selectedDay - 1].activities.map(activity => <li key={activity}>{activity}</li>)}</ul>
   <p className="text-sm leading-relaxed text-white/80"><span className="font-semibold text-white">휴식·우선순위 제안: </span>{planDetails[selectedDay - 1].suggestion}</p>
   <p className="text-xs leading-relaxed text-white/70">예정 일정이며 완료 기록이 아닙니다. 종료 시각이 없는 활동의 시간을 추정하지 않습니다. 일차 선택이나 날짜 경과로 실제 사용·완료 기록을 생성하지 않습니다.</p>
  </div>
 </section>;
}
