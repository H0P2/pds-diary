# Studio option 3 — design QA

Final result: passed

## Reference and evidence
- Selected reference: ../design-team/studio/concept.png (1487 × 1058).
- Matched desktop viewport: 1440 × 1024, reference resized proportionally for comparison.
- Comparison evidence: ../design-team/studio/comparison-v2.jpg; focused rows: focused-rows-v2.jpg.
- Final implementation capture: ../design-team/studio/desktop-final.jpg (1440 × 1024).
- Mobile capture: ../design-team/studio/mobile-final.jpg (390 × 844).
- Reference and implementation were inspected together at the same desktop scale, with an additional row-detail comparison.

## Visual verification
- Dark 292px sidebar, 96px top navigation, white main canvas, lime selected marker and primary action match the selected direction.
- Title hierarchy, compact plan summary, gray notice, list separators, 76px desktop task rows, status pills, outline icons and restrained surfaces checked.
- Initial P2 typography/density differences were corrected in v2: larger desktop title-row labels, navigation, list heading and summary text; desktop secondary metadata hidden.
- Final desktop capture rechecked after mobile touch-target improvements. Remaining P3 differences: system Korean font shapes, small spacing variations, added sort explanation required by the app.
- Intentional content differences: existing plan success criterion, record ordering, estimates and priorities are preserved. Illustrative mockup data and mockup annotation are not copied into real records.
- Plan edit, task add/edit dialogs, Do and See views use the same neutral surfaces and lime actions.
- Mobile changes sidebar into a compact header with plan navigation; controls wrap and task metadata remains readable. Document width equals viewport width (390px), with no horizontal overflow.
- Mobile task menus and checkbox hit areas expanded to 44px. Visible labels, focus indication, semantic tabs and accessible input labels retained. Reduced-motion preference respected.

## Interaction verification
- Plan edit opens with existing values; dismissed without saving.
- Task search narrows to matching records and restores the list when cleared.
- Add-task dialog opens with all required fields; dismissed without saving.
- Mobile task menu opens and task edit shows the existing record; dismissed without saving.
- Plan / Do / See tabs navigate successfully; See evidence expands to the five actual tasks.
- Actual execution record count remains zero; no execution history fabricated.
- Browser error/warning log checked: empty.
- TypeScript check passed; production build passed. Build prints an existing Node punycode deprecation warning.

## Delivery state
Local preview remains running at http://127.0.0.1:5173/ . Public site unchanged; assignment submission held at user request. API and database schema unchanged by this design pass.

## Follow-up: flexible durations and actual two-week plan
- User-requested period and highest priority added to the plan summary; desktop task due dates now visible.
- Duration selectors offer months/weeks/hours/minutes/seconds; fixed 30-day month rule is stated beside inputs. Execution inputs include seconds.
- Browser interaction verified all five options and 45-second input without saving a fabricated task estimate.
- Actual browser width during follow-up was 564px despite requested overrides; verified document width 564px and inspected the full current screenshot at ../review/two-week-current.jpg. Do not treat this capture as a 1440px screenshot.
- API precision and aggregate checks passed against isolated SQLite; no test records written to the user's database. Build and TypeScript checks passed. Browser error log empty.
- Calendar dates and real saved task data inspected through the server read tool. Final result: passed for the requested change and observed responsive width.
